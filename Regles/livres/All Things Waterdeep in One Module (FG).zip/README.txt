Version: 2019.1.4

Thank you for purchasing the Waterdeep module. Within this zip file you will find five files:
1. DD Waterdeep Dragon Heist.xml
2. README.txt
3. Waterdeep.mod
4. Waterdeep Decal.ext

To get started first located your Fantasy Grounds application directory. If you are not sure where to find this directory review the Fantasy grounds wiki https://www.fantasygrounds.com/wiki/index.php/File_Locations

Installing the Waterdeep Module
1. Copy the Waterdeep.mod file to the modules directory in the Fantasy Grounds application directory.

Installing the Waterdeep Decals
1. Copy the Waterdeep Decal.ext to the extensions directory in the Fantasy Grounds application directory.

Installing the Waterdeep Family Crests
1. Copy the Waterdeep Noble Family Crests.mod to the modules directory in the Fantasy Grounds application directory.

Setting Up the Waterdeep Pins for the Waterdeep Dragon Heist Maps
There are extra steps that need to be taken to make the location pins show up on the Waterdeep Dragon Heist maps. There are three scenarios that you need to pick from. Make sure all of these steps are taken when Fantasy Grounds is not running.

Note: The process to support pins in the Waterdeep Dragon Heist module's maps is easier if the campaign is a newly created campaign or the DM has made no edits to the Waterdeep Dragon Heist module. When possible I recommend adding the pins right after creating a new campaign that will use the Waterdeep Dragon Heist Fantasy Grounds Module.

Note: The xml file that is used must be named DD Waterdeep Dragon Heist.xml in order for Fantasy grounds to find the file. Replace any underscores with spaces if the file name has underscores.

Step 1: Start by accessing the campaign directory for the campaign you want the location pins to show up on the Dragon Heist maps within the Fantasy Grounds application directory.

Step 2: The next step you need to take depends on answer to the following questions.  Is there a moduledb directory in the campaign directory?
A. If there is no moduledb directory in the campaign directory,  follow the directions for A
B. If there is a moduledb directory in the campaign directory, but NO DD Waterdeep Dragon Heist.xml file in that folder, follow the directions for B:
C. If there is a moduledb directory in the campaign directory, and a DD Waterdeep Dragon Heist.xml file in that folder, follow the directions for C:

A: There is no moduledb directory in the campaign directory:
1. Create a moduledb folder
2. Copy the DD Waterdeep Dragon Heist.xml file you downloaded from the dms guild into the moduledb folder.
3. Load up Fantasy Grounds and your campaign.
4. Click your images or Maps Button (this is different based on the theme)
5. Select the Maps - DD Waterdeep Dragon Heist Group
6. Double click on the Waterdeep-E-DM map and you should now see pins on the map.
7. Click on a pin and Fantasy grounds will ask you to load the Waterdeep module.
8. Click on the check mark to load the Waterdeep module.

B: There is a moduledb directory in the campaign directory, but NO DD Waterdeep Dragon Heist.xml file in that folder:
1. Copy the DD Waterdeep Dragon Heist.xml file you downloaded from the dms guild into the moduledb folder.
2. Load up Fantasy Grounds and your campaign.
3. Click your images or Maps Button (this is different based on the theme)
4. Select the Maps - DD Waterdeep Dragon Heist Group
5. Double click on the Waterdeep-E-DM map and you should now see pins on the map.
6. Click on a pin and Fantasy grounds will ask you to load the Waterdeep module.
7. Click on the check mark to load the Waterdeep module.

C: There is a moduledb directory in the campaign directory, and a DD Waterdeep Dragon Heist.xml file in that folder:
This takes some knowledge of xml format to be the most successful:
1. Copy the DD Waterdeep Dragon Heist.xml file in the moduledb directory to DD Waterdeep Dragon Heist_OLD.xml.
2. Rename the DD Waterdeep Dragon Heist.xml file you downloaded from the dms guild to DD Waterdeep Dragon Heist_NEW.xml.
3. Copy the text inside the <root> tag of the DD Waterdeep Dragon Heist_NEW.xml file into the root tag of the DD Waterdeep Dragon Heist.xml file in the moduledb folder.
NOTE: Make sure that if an <encounter> tag already exists or an <image> tag exists in the DD Waterdeep Dragon Heist.xml file in your moduledb directory that you are placing the XML from DD Waterdeep Dragon Heist_NEW.xml that is in the same tags in those tags in the DD Waterdeep Dragon Heist.xml file in the moduledb folder.
4. Load up Fantasy Grounds and your campaign.
5. Click your images or Maps Button (this is different based on the theme)
6. Select the Maps - DD Waterdeep Dragon Heist Group
7. Double click on the Waterdeep-E-DM map and you should now see pins on the map.
8. Click on a pin and Fantasy grounds will ask you to load the Waterdeep module.
9. Click on the check mark to load the Waterdeep module.

If you have problems review the FAQ below, if the solutions don't help please join the Discord channel at https://discord.gg/eP7RaZe or post a comment in the DMs guild page for the product https://www.dmsguild.com/product/262266/Waterdeep-5e-Fantasy-Grounds-Module-All-things-Waterdeep-in-one-module

Frequently Asked questions

Why are the location pins not showing in the Waterdeep Dragon Heist maps?
There are a few reasons that the pins may not show in the Waterdeep Dragon Heist map.
1. The file in the moduledb directory is incorrectly named. It must be DD Waterdeep Dragon Heist.xml. If the file is not named that rename it to DD Waterdeep Dragon Heist.xml and reload Fantasy Grounds.
2. You have disabled pins in the waterdeep map you are reviewing. Right click on the map. Click on the layer button. Click the enable pins button.

Why do I not see any new information in Fantasy Grounds after I add the mod file to my module directory?
The most likely reason is that you have not loaded the Waterdeep module in Fantasy Grounds. To load the module first Start Fantasy Grounds. Load a 5E ruleset based campaign. Click on the library button in the button bar on the right. Click the module button in the bottom left of the new window. Scroll until you find the Waterdeep module. Click the load button.

Why can't I click on the pins on the DD Waterdeep Dragon's Heist map?
One possible reason here is that you have the 5e Combat Enhancer extension installed and you are on the wrong layer of the map. 
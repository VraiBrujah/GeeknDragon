# Module Dolibarr "Presta Sync" : Connecteur Prestashop pour Dolibarr
PrestaSync, le connecteur e-commerce entre **Dolibarr & Prestashop**
--------------------------------------------------------------------

**PrestaSync** est un module de synchronisation entre **Prestashop** et **Dolibarr**, conçu pour faciliter la gestion des produits, commandes, clients et stocks entre ces deux plateformes.

[![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/Screen-fiche-site-002.png)](/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/Screen-fiche-site-002.png)

Automatise la saisie de vos commandes **Prestashop** vers **Dolibarr !**
------------------------------------------------------------------------

Import des commandes
--------------------

*   Importez les **commandes** provenant de différents sites Prestashop, y compris en multisite.
*   L'import d'une commande importe aussi le **client** et les **adresses** associées.
*   **Vous gardez la maîtrise :** importer en **automatique** sur statut Prestashop ou par action manuelle avec les actions en masse.
*   **Changez le statut** d'une commande prestashop **depuis Dolibarr**

![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/Screen%20action%20en%20masse%20commandes.png)

La gestion de **large catalogue produits en gardant la maîtrise** dans l'ERP
----------------------------------------------------------------------------

Il s'agit là de la philosophie du module PrestaSync

Import des produits **Prestashop** vers **Dolibarr**
----------------------------------------------------

*   Importer les produits provenant de plusieurs sites Prestashop, même en mode multisite.
*   Inclure les images des produits et les prix d'achats fournisseurs pour une gestion complète et centralisée.
*   [Dans le cas de produits avec déclinaisons, les produits créés sur Dolibarr restent des produits simples sans déclinaisons. Voir si après](#explain-no-product-import)

![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/Screen%20action%20en%20masse%20produit%20-%20confirm%20update.png)

![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/Screen-action-en-masse-produit-002.png)

Gestion des déclinaisons
------------------------

Pour les produits Prestashop avec **déclinaisons**, l'interface Dolibarr offre une **saisie rapide et ergonomique** des références, prix et poids des déclinaisons directement dans Dolibarr.  
Cela pallie les lacunes ergonomiques de la gestion des déclinaisons dans les fiches produits Prestashop.

### Des outils pour vous aidez avec les déclinaisons :

*   Une modification instantanée et en direct des références, prix et poids des déclinaisons côté Prestashop.
*   Un calcul automatique des impacts de prix et de poids des déclinaisons en fonction des valeurs réelles saisies (prix réels et poids réels).

Tailler pour de grands catalogues produits
------------------------------------------

Le module **Prestasync** se distingue par ses performances pour gérer efficacement de vastes catalogues produits.

Grâce à son système de mise à jour en masse et automatique, il permet de synchroniser rapidement les prix et les stocks de votre boutique Prestashop avec les données issues de Dolibarr.

Chaque mise à jour s’appuie sur un fichier généré automatiquement par Dolibarr, garantissant une intégrité et une fluidité optimale du processus.

Pour donner une idée de ses performances : sur des configurations standards, le module permet de traiter jusqu’à **13 000 références en moins d’une minute** côté Prestashop (temps mesuré sur les serveurs THERSANE). Cette rapidité dépend bien entendu des ressources de votre serveur, mais elle montre à quel point **Prestasync** est conçu pour répondre aux besoins des entreprises avec de grands catalogues.

Pourquoi les prix et stocks produits ne sont pas mis à jour en direct ?
-----------------------------------------------------------------------

Le choix de ne pas effectuer de mise à jour en temps réel des prix et stocks depuis Dolibarr repose sur des raisons techniques et stratégiques pour garantir de bonnes performances :

**Gestion de la charge serveur :**

Le module Prestasync peut être utilisé pour connecter une instance Dolibarr à plusieurs, voire des dizaines ou centaines, de sites e-commerce. Une mise à jour instantanée à chaque modification de stock ou de prix côté Dolibarr générerait une énorme quantité d’appels API. Cela risquerait de surcharger non seulement le serveur Dolibarr, mais également les serveurs Prestashop des boutiques connectées, particulièrement lors de mises à jour massives.

**Prévention des erreurs temporaires :**

En temporisant les mises à jour à des plages horaires définies, les éventuelles erreurs de saisie côté Dolibarr (par exemple une mauvaise entrée de stock ou de prix) n’ont pas d’impact immédiat sur tous les sites e-commerce. Cela offre le temps de corriger ces erreurs avant leur propagation, garantissant ainsi la cohérence des données synchronisées.

**Répartition intelligente de la charge :**

La synchronisation différée permet de répartir la charge des mises à jour entre les différents sites e-commerce connectés. Ainsi, chaque serveur Prestashop peut traiter les mises à jour à son rythme, tout en évitant une sollicitation excessive du serveur Dolibarr, particulièrement critique pour les entreprises avec des catalogues volumineux.

En résumé, ce système de synchronisation planifiée garantit à la fois des performances optimales et une meilleure fiabilité des données, tout en évitant les désagréments liés aux erreurs ou aux pics de charge.

Création et mise à jour des produits sur **Prestashop** depuis **Dolibarr**
---------------------------------------------------------------------------

La création de produits sur Prestashop à partir de Dolibarr **n'est actuellement pas prise en charge**. Seules les mises à jour de **stocks, de prix et de poids sont possibles dans ce sens**.

Ce choix repose sur une réalité fonctionnelle : **la gestion des produits et de leurs déclinaisons diffère considérablement entre Dolibarr, Prestashop et même entre plusieurs boutiques Prestashop connectées**. (Rien n’empêche, par exemple, une boutique Prestashop de gérer ses produits par déclinaisons alors qu'une autre boutique gère les mêmes produits sans déclinaison).  
Ces différences rendent complexe l'harmonisation des attributs et des caractéristiques d'un système ou site à l'autre. L'objectif n'étant pas de saturer Dolibarr avec des données de synchronisation inutiles, **cette limitation s'impose naturellement.**

Tenter d’unifier ces logiques obligerait à faire des compromis qui pourraient nuire à l’intégrité des données ou aux spécificités de chaque plateforme. Nous avons donc opté pour une approche plus cohérente : laisser chaque logiciel gérer les produits à sa manière tout en nous concentrant sur l’essentiel, à savoir la synchronisation fiable et rapide des informations clés comme les stocks, les prix et les poids.

**Ce choix s'appuie également sur des retours d'expérience issus de solutions testées avant la création de PrestaSync, qui ont provoqués des synchronisations automatiques indésirables, effaçant sans discernement des heures de travail acharné.** Un logiciel doit être un allié qui facilite notre travail et non un obstacle qui le complique.

Par expérience, si vous comptez créer en masse des produits côté Prestashop, il est préférable d'opter pour des imports par fichier CSV qui, en regardant de près, vous permettent de maîtriser les données associées, par exemple : catégories, tags, caractéristiques ou attributs...

**Télécharger le module** : PrestaSync
--------------------------------------

Module disponible sur le Dolistore, la plaforme de vente officiel de Dolibarr

Restez informé des Mises à jours
--------------------------------

Ne manquez aucune amélioration ou nouveauté pour vos modules.  
Inscrivez-vous à notre newsletter et recevez directement dans votre boîte mail les dernières actualités, information de mises à jour et conseils pour optimiser vos outils.

Pourquoi le module n'est-il pas vendu directement sur la e-boutique THERSANE ?
------------------------------------------------------------------------------

Chez THERSANE, nous avons choisi de proposer nos modules via le Dolistore pour contribuer activement au projet Dolibarr. En effet, chaque vente réalisée sur le Dolistore permet de reverser une commission à l'association Dolibarr. Cette contribution aide à financer le développement et la maintenance du logiciel, soutenant ainsi l'ensemble de la communauté qui en bénéficie.

En passant par le Dolistore, non seulement vous obtenez un module de qualité, mais vous soutenez également le projet open source qui fait la force de Dolibarr.

Merci de votre confiance et de votre engagement aux côtés de THERSANE et de la communauté Dolibarr !

Installation via un fichier ZIP et l'interface graphique
--------------------------------------------------------

1.  Si le module est fourni sous forme de fichier ZIP prêt à être déployé (nommé module\_xxx-version.zip, par exemple lorsqu'il est téléchargé depuis une marketplace comme Dolistore), procédez comme suit :

*   Allez dans le menu **Accueil > Configuration > Modules > Déployer un module externe.**
*   Téléchargez le fichier ZIP du module depuis votre ordinateur.

3.  **Note importante :** Si un message d'erreur vous indique qu'il n'y a pas de répertoire "custom", vérifiez que votre installation de Dolibarr est correctement configurée et que le répertoire est accessible.
4.  Vous devriez maintenant voir le module que vous venez de télécharger dans la liste. Cliquez sur **"Activer"** pour commencer à utiliser le module.
5.  Si le module le nécessite, configurez le, et activer les droits à vos groupes d'utilisateurs et/ou utilisateurs.

**Configuration du module** : PrestaSync
----------------------------------------

Et paramétrages Prestashop

### Note importante sur l'activation des webServices de Prestashop

Attention l'activation des webServices ne fonctionnent pas toujours lors de l'activation de ces derniers. Il est possible qu'il soit nécessaire d'ajouter la lignes suivantes à votre fichier .**htaccess** de votre site Prestashop juste apres **RewriteEngine on.**

**RewriteCond %{HTTP:Authorization} ^(.\*)**  
**RewriteRule . - \[E=HTTP\_AUTHORIZATION:%1\]**

#### Attention au mode maintenance !

Si vous n'arrivez pas à vous connecter depuis Dolibarr il est possible que **le mode maintenance** du site vous en empêche, pensez à **ajouter toutes les ip du serveur de votre Dolbarr**.

Pensez à installer la version Prestashop du module sur votre Prestashop.
------------------------------------------------------------------------

Le module **Prestasync se compose de deux modules portant le même nom** : **un pour Dolibarr** et **un pour Prestashop**.

Bien que le module Prestashop ne soit pas indispensable, il permet la mise à jour des prix et des stocks, ainsi que le déclenchement automatique coté prestashop des commandes lors du changement de statut côté Prestashop.

**⚠ Rappel important :** Avant d'installer ou de mettre à jour un module, nous vous recommandons vivement de le tester d'abord dans un environnement d'essai. Cela permet d'éviter les perturbations potentielles de votre boutique en ligne.

Configuration du module PrestaSync coté Prestashop
--------------------------------------------------

### Configuration de la mise à jour en masse des prix et stock

Pour activer la mise à jour en masse des prix et stock dans prestashop ils vous faut :

1.  Activer la tâche planifié d'export des prix et stock coté Dolibarr _(Export des prix et stock produits)_Cette tâche enregistre un fichier dans les documents de Dolibarr   
    _**/prestasync/export-stock.csv**_
2.  Configurer un accès FTP vers le dossier document de votre Dolibarr
3.  Saisir les données d'accès FTP dans la configuration du module coté Prestashop _(voir point 3 image)  
    __Astuce: bien que le fichier généré par Dolibarr soit_ _export-stock.csv il est possible d'utiliser un autre fichier, ainsi il vous est possible de créer un autre fichier avec vos modifications de stocks ou tarifs._
4.  Activer la mise à jour des prix en masse. _(voir point 1 image)_
5.  Ajouter une tâche planifié qui appel l'URL fourni sous le bouton d'activation de la mise à jours des prix en masse. _(voir point 2 image)_

[![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/prestasync-pres-config%20002.png)](/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/prestasync-pres-config%20002.png)

### Configuration du WebHook

1\. Pour configurer le webhook saisir simplement l'url fournie par le module Prestasync coté de Dolibarr. (Voir points 1 et 2 sur l'image)

2\. Ajouter une tâche planifiée (cron) qui appel l'URL (Point 3) toutes les minutes.

[![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/prestasync-pres-config%20003.png)](/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/prestasync-pres-config%20003.png)

The shop card

[![](https://www.thersane.fr/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/screen-08.png)](/img/cms/pages-et-cms/Modules-Dolibarr/PrestaSync/screen-08.png)

Prestashop admin module setup

Other external modules are available on [Dolistore.com](https://www.dolistore.com).

## Translations

Translations can be completed manually by editing files into directories *langs*.

<!--
This module contains also a sample configuration for Transifex, under the hidden directory [.tx](.tx), so it is possible to manage translation using this service.

For more informations, see the [translator's documentation](https://wiki.dolibarr.org/index.php/Translator_documentation).

There is a [Transifex project](https://transifex.com/projects/p/dolibarr-module-template) for this module.
-->

<!--

## Installation

### From the ZIP file and GUI interface

If the module is a ready to deploy zip file, so with a name module_xxx-version.zip (like when downloading it from a market place like [Dolistore](https://www.dolistore.com)),
go into menu ```Home - Setup - Modules - Deploy external module``` and upload the zip file.

Note: If this screen tell you that there is no "custom" directory, check that your setup is correct:

- In your Dolibarr installation directory, edit the ```htdocs/conf/conf.php``` file and check that following lines are not commented:

    ```php
    //$dolibarr_main_url_root_alt ...
    //$dolibarr_main_document_root_alt ...
    ```

- Uncomment them if necessary (delete the leading ```//```) and assign a sensible value according to your Dolibarr installation

    For example :

    - UNIX:
        ```php
        $dolibarr_main_url_root_alt = '/custom';
        $dolibarr_main_document_root_alt = '/var/www/Dolibarr/htdocs/custom';
        ```

    - Windows:
        ```php
        $dolibarr_main_url_root_alt = '/custom';
        $dolibarr_main_document_root_alt = 'C:/My Web Sites/Dolibarr/htdocs/custom';
        ```

### From a GIT repository

Clone the repository in ```$dolibarr_main_document_root_alt/prestasync```

```sh
cd ....../custom
git clone git@github.com:gitlogin/prestasync.git prestasync
```

### <a name="final_steps"></a>Final steps

From your browser:

  - Log into Dolibarr as a super-administrator
  - Go to "Setup" -> "Modules"
  - You should now be able to find and enable the module

-->

## Licenses

### Main code

GPLv3 or (at your option) any later version. See file COPYING for more information.

### Documentation

All texts and readmes are licensed under GFDL.

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *   	\file       presta_list.php
 *		\ingroup    prestasync
 *		\brief      List page for presta
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB', '1');				// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER', '1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC', '1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN', '1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION', '1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION', '1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK', '1');				// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL', '1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK', '1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU', '1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML', '1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX', '1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN", '1');					// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK', '1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT', 'auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule');	// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN', 1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP', 'none');				// Disable all Content Security Policies
//if (! defined('CSRFCHECK_WITH_TOKEN'))     define('CSRFCHECK_WITH_TOKEN', '1');		// Force use of CSRF protection with tokens even for GET
//if (! defined('NOBROWSERNOTIF'))     		 define('NOBROWSERNOTIF', '1');				// Disable browser notification
//if (! defined('NOSESSION'))                define('NOSESSION', '1');					// On CLI mode, no need to use web sessions

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';

// load prestasync libraries
require_once __DIR__.'/class/presta.class.php';
require_once __DIR__.'/lib/prestasync_presta.lib.php';
require_once __DIR__ .'/class/prestaOrder.class.php';
require_once __DIR__ . '/core/modules/modPrestasync.class.php';

// for other modules
//dol_include_once('/othermodule/class/otherobject.class.php');

// Load translation files required by the page
$langs->loadLangs(array("prestasync@prestasync", "other"));

$id = GETPOST('id', 'int');
$ref = GETPOST('ref', 'alpha');

$action     = GETPOST('action', 'aZ09') ?GETPOST('action', 'aZ09') : 'view'; // The action 'add', 'create', 'edit', 'update', 'view', ...
$massaction = GETPOST('massaction', 'alpha'); // The bulk action (combo box choice into lists)
$show_files = GETPOST('show_files', 'int'); // Show files area generated by bulk actions ?
$confirm    = GETPOST('confirm', 'alpha'); // Result of a confirmation
$cancel     = GETPOST('cancel', 'alpha'); // We click on a Cancel button
$toselect   = GETPOST('toselect', 'array'); // Array of ids of elements selected into a list
$contextpage = GETPOST('contextpage', 'aZ') ? GETPOST('contextpage', 'aZ') : str_replace('_', '', basename(dirname(__FILE__)).basename(__FILE__, '.php')); // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha'); // Go back to a dedicated page
$optioncss  = GETPOST('optioncss', 'aZ'); // Option for the css output (always '' except when 'print')
$mode       = GETPOST('mode', 'aZ');

// Load variable for pagination
$limit = GETPOST('limit', 'int') ? GETPOST('limit', 'int') : $conf->liste_limit;
$sortfield = GETPOST('sortfield', 'aZ09comma');
if(empty($sortfield)){
	$sortfield = 'id';
}
$sortorder = GETPOST('sortorder', 'aZ09comma');
$page = GETPOSTISSET('pageplusone') ? (GETPOST('pageplusone') - 1) : GETPOST("page", 'int');
if (empty($page) || $page < 0 || GETPOST('button_search', 'alpha') || GETPOST('button_removefilter', 'alpha')) {
	// If $page is not defined, or '' or -1 or if we click on clear filters
	$page = 0;
}
$offset = $limit * $page;
$pageprev = $page - 1;
$pagenext = $page + 1;

// Initialize technical objects
$object = new Presta($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->prestasync->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('prestalist')); // Note that conf->hooks_modules contains array

// Load object
$prestaShopIsLoaded = false;
if (($id > 0 || (!empty($ref) && !in_array($action, array('create', 'createtask', 'add')))) && (empty($cancel) || $id > 0)) {
	if (($id > 0 && is_numeric($id)) || !empty($ref)) {	// To discard case when id is list of ids like '1,2,3...'
		$ret = $object->fetch($id, (empty($ref)? '' : $ref));
		if ($ret > 0) {
			$object->fetch_thirdparty();
			$id = $object->id;
			$prestaShopIsLoaded = true;
		} else {
			if (empty($object->error) && !count($object->errors)) {
				if ($ret < 0) {	// if $ret == 0, it means not found.
					setEventMessages('Fetch on object (type '.get_class($object).') return an error without filling $object->error nor $object->errors', null, 'errors');
				}
			} else {
				setEventMessages($object->error, $object->errors, 'errors');
			}
			$action = '';
		}
	}
}

if(!$prestaShopIsLoaded){
	accessforbidden();
}


if ($id > 0 || !empty($ref)) {
	$upload_dir = $conf->prestasync->multidir_output[!empty($object->entity) ? $object->entity : $conf->entity]."/".$object->id;
}



$arrayfields = array(
	'id' 			=> array('type'=>'integer', 'label'=>'PrestaId', 'checked'=>0, 'enabled'=>0, 'position'=>1, 'enableSortLink' => 1),
	'reference' 	=> array('type'=>'text', 'searchable'=> 1, 'label'=>'PrestaRef', 'checked'=>1, 'enabled'=>1, 'position'=>2, 'enableSortLink' => 1),
	'id_customer' 	=> array('type'=>'text', 'label'=>'Customer', 'checked'=>1, 'enabled'=>1, 'position'=>10),
	'id_address_invoice' => array('type'=>'text', 'label'=>'AdressInvoice', 'checked'=>1, 'enabled'=>1, 'position'=>20),
	'id_address_delivery' => array('type'=>'text', 'label'=>'AdressDelivery', 'checked'=>1, 'enabled'=>1, 'position'=>20),
	'total_paid' 	=> array('type'=>'price', 'label'=>'TotalPaid', 'checked'=>1, 'enabled'=>1, 'position'=>30, 'enableSortLink' => 1),
	'payment'		=> array('type'=>'text', 'label'=>'Payement', 'checked'=>1, 'enabled'=>1, 'position'=>40, 'enableSortLink' => 1),
	'date_add' 		=> array('type'=>'datetime', 'searchable'=> 1, 'label'=>'Date', 'checked'=>1, 'enabled'=>1, 'position'=>999, 'enableSortLink' => 1),
	'current_state' => array('type'=>'integer', 'searchable'=> 1, 'label'=>'Status', 'checked'=>1, 'enabled'=>1, 'notnull'=>0, 'position'=>99998, 'enableSortLink' => 1),
	'sync_status' 	=> array('type'=>'integer', 'searchable'=> 0, 'label'=>'SyncStatus', 'checked'=>1, 'enabled'=>1, 'notnull'=>0, 'position'=>99999, 'enableSortLink' => 0, 'csslist' => 'linecolsyncstate'),
	'dol_ref' 	=> array('type'=>'text', 'searchable'=> 0, 'label'=>'psyncDolibarrRef', 'checked'=>1, 'enabled'=>1, 'notnull'=>0, 'position'=>999999, 'enableSortLink' => 0, 'csslist' => 'linecoldolref nowraponall'),
);

$search = array();
foreach ($arrayfields as $key => $val) {
	if (GETPOST('search_'.$key, 'alpha') !== '') {
		$search[$key] = GETPOST('search_'.$key, 'alpha');
	}
	if (preg_match('/^(date|timestamp|datetime)/', $val['type'])) {
		$search[$key.'_dtstart'] = dol_mktime(0, 0, 0, GETPOST('search_'.$key.'_dtstartmonth', 'int'), GETPOST('search_'.$key.'_dtstartday', 'int'), GETPOST('search_'.$key.'_dtstartyear', 'int'));
		$search[$key.'_dtend'] = dol_mktime(23, 59, 59, GETPOST('search_'.$key.'_dtendmonth', 'int'), GETPOST('search_'.$key.'_dtendday', 'int'), GETPOST('search_'.$key.'_dtendyear', 'int'));
	}
}


$arrayfields = dol_sort_array($arrayfields, 'position');


// There is several ways to check permission.
// Set $enablepermissioncheck to 1 to enable a minimum low level of checks
$enablepermissioncheck = 1;
$permissiontoread = $user->hasRight('prestasync', 'presta', 'read');
$permissiontoadd = $user->hasRight('order', 'write');
$permissiontodelete = $user->hasRight('order', 'delete');

// Security check (enable the most restrictive one)
if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) accessforbidden();
//$socid = 0; if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->status == $object::STATUS_DRAFT) ? 1 : 0);
//restrictedArea($user, $object->element, 0, $object->table_element, '', 'fk_soc', 'rowid', $isdraft);
if (empty($conf->prestasync->enabled)) accessforbidden('Module not enabled');
if (!$permissiontoread) accessforbidden();


/*
 * Actions
 */

if (GETPOST('cancel', 'alpha')) {
	$action = 'list';
	$massaction = '';
}
if (!GETPOST('confirmmassaction', 'alpha') && $massaction != 'presend' && $massaction != 'confirm_presend') {
	$massaction = '';
}

$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) {
	setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
}

if (empty($reshook)) {
	// Selection of new fields
	include DOL_DOCUMENT_ROOT.'/core/actions_changeselectedfields.inc.php';

	// Purge search criteria
	if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')) { // All tests are required to be compatible with all browsers
		foreach ($arrayfields as $key => $val) {
			$search[$key] = '';
			if (preg_match('/^(date|timestamp|datetime)/', $val['type'])) {
				$search[$key.'_dtstart'] = '';
				$search[$key.'_dtend'] = '';
			}
		}
		$toselect = array();
		$search_array_options = array();
	}
	if (GETPOST('button_removefilter_x', 'alpha') || GETPOST('button_removefilter.x', 'alpha') || GETPOST('button_removefilter', 'alpha')
		|| GETPOST('button_search_x', 'alpha') || GETPOST('button_search.x', 'alpha') || GETPOST('button_search', 'alpha')) {
		$massaction = ''; // Protection to avoid mass action if we force a new search during a mass action confirmation
	}

	// Mass actions
	$objectclass = 'Presta';
	$objectlabel = 'Presta';
	$uploaddir = $conf->prestasync->dir_output;
	include DOL_DOCUMENT_ROOT.'/core/actions_massactions.inc.php';



	if($massaction == 'startSync'){
		$prestaObjectBackup = $object;
		$synchronized = 0;
		foreach ($toselect as $prestaId){
			$prestaOrd = new PrestaOrder($object);
			if($prestaOrd->fetch($prestaId)){
				$prestaOrd->clearErrors();
				if($prestaOrd->syncToDolibarr($user)){
					$synchronized++;
				}
			}

			$syncErr = $prestaOrd->getErrors();
			if(!empty($syncErr)){
				setEventMessage($syncErr,	'errors');
			}

			if($prestaObjectBackup != $object){
				$object = $prestaObjectBackup; // to avoid wierd global override by shitty module
			}
		}

		if($synchronized>0){
			setEventMessage($langs->trans('XOrdersSyncronised',$synchronized));
		}
	}
}


// Here we set the option array for the Webservice
$resource = 'orders';
$filters = array();
$display = array('id', 'reference', 'total_paid', 'id_customer', 'id_cart', 'id_address_delivery', 'id_address_invoice', 'current_state', 'payment', 'date_add');
if(!empty($search)){

	foreach ($arrayfields as $key => $val) {
		if (preg_match('/^(date|timestamp|datetime)/', $val['type'])) {

			$dateFormat = 'Y-m-d H:i:s';

			if(!empty($search[$key.'_dtstart']) && !empty($search[$key.'_dtend'])){
				$filters[$key] = array(
					'operator' 	=> 'interval',
					'min' 	=> date($dateFormat, $search[$key.'_dtstart']),
					'max' 	=> date($dateFormat, $search[$key.'_dtend'])
				);
			}elseif(empty($search[$key.'_dtstart']) xor empty($search[$key.'_dtend'])){
				$filters[$key] = array(
					'operator' 	=> 'interval',
					'min' 	=> empty($search[$key.'_dtstart'])?date($dateFormat, $search[$key.'_dtstart']):date($dateFormat, 0),
					'max' 	=> $search[$key.'_dtend']?date($dateFormat, $search[$key.'_dtend']):date($dateFormat, time()),
				);
			}

		}elseif(strlen($search[$key]??'') > 0) {
			$operator = 'natural';

			if ($val['type'] == 'integer') {
				$operator = 'literal';
			}

			$filters[$key] = array(
				'operator' 	=> $operator,
				'search' 	=> $search[$key]
			);
		}
	}

}

$listLimit = 25;
if ($limit > 0 && $limit != $conf->liste_limit) {
	$listLimit = intval($limit);
}



$opt = array();

$opt['limit'] = $listLimit+1;
if(!empty($page)){
	$opt['limit'] = intval(($listLimit*intval($page))).','.($listLimit+1);
}

$resources = $object->getFromWebService($resource, $display ,array($sortfield => $sortorder), $filters, false, false, $opt);
if($resources === false){
	setEventMessage($object->errorsToString(), 'errors');
}
$num = is_array($resources)?count($resources):'';
$nbtotalofrecords = '';


$prestaOrderStatic = new PrestaOrder($object);
$prestaOrderStates = $object->getAllResources('order_states');
if(!empty($prestaOrderStates)){
	$arrayfields['current_state']['arrayofkeyval'] = array(
		'' => ''
	);
	foreach ($prestaOrderStates as $oSKey => $oSValue){
		$arrayfields['current_state']['arrayofkeyval'][$oSKey] = $prestaOrderStatic->getTradValue($oSValue->name);
	}
}

/*
 * Fetch others data
 */

// fetch customers
if($resources){
	$customersToFetch = array();
	foreach($resources as $resource){
		$customersToFetch[] = $resource->id_customer;
	}

	if($customersToFetch){
		require_once __DIR__ . '/class/prestaCustomer.class.php';
		$prestaCustomerStatic = new PrestaCustomer($object);
		$resourcesCustomers = $prestaCustomerStatic->fetchAll(array('id','lastname', 'firstname') ,array(), array('id' => $customersToFetch), false);
	}
}


// fetch customers address
$resources_address = array();
if($resources){
	$addressesToFetch = array();
	foreach($resources as $resource){
		$addressesToFetch[] = $resource->id_address_delivery;
		$addressesToFetch[] = $resource->id_address_invoice;
	}

	$addressesToFetch = array_unique($addressesToFetch);

	if($addressesToFetch){
		require_once __DIR__ . '/class/prestaAddress.class.php';
		$prestaAddresseStatic = new PrestaAddress($object);
		$resourcesAddresses = $prestaAddresseStatic->fetchAll(array('id','company','firstname','lastname','address1','address2','postcode','city') ,array(), array('id' => $addressesToFetch), false);
	}
}


// Auto create paiement mapping
$autoCreateMappingAllreadyDone = [];




/*
 * View
 */

$form = new Form($db);



//$help_url='EN:Customers_Orders|FR:Commandes_Clients|ES:Pedidos de clientes';
$help_url = modPrestasync::webPageHelp;
$title = $langs->trans('Presta').' - '.$langs->trans("PrestaOrders");
llxHeader('', $title, $help_url, '', 0, 0, '', [
	'prestasync/css/prestasync.css',
]);


if ($id > 0 || !empty($ref)) {

	$head = prestaPrepareHead($object);
	print dol_get_fiche_head($head, 'orders', $langs->trans("Presta"), 0, $object->picto);
	prestaBanner($object);
	print dol_get_fiche_end(0);

	$arrayofselected = is_array($toselect) ? $toselect : array();

	$param = '';
	if (!empty($id)) {
		$param .= '&id=' . intval($id);
	}
	if (!empty($ref)) {
		$param .= '&ref=' . urlencode($ref);
	}
	if (!empty($mode)) {
		$param .= '&mode='.urlencode($mode);
	}
	if (!empty($contextpage) && $contextpage != $_SERVER["PHP_SELF"]) {
		$param .= '&contextpage='.urlencode($contextpage);
	}
	if ($limit > 0 && $limit != $conf->liste_limit) {
		$param .= '&limit='.urlencode($limit);
	}
	foreach ($search as $key => $val) {
		if (is_array($search[$key])) {
			foreach ($search[$key] as $skey) {
				if ($skey != '') {
					$param .= '&search_'.$key.'[]='.urlencode($skey);
				}
			}
		} elseif (preg_match('/(_dtstart|_dtend)$/', $key) && !empty($val)) {
			$param .= '&search_'.$key.'month='.((int) GETPOST('search_'.$key.'month', 'int'));
			$param .= '&search_'.$key.'day='.((int) GETPOST('search_'.$key.'day', 'int'));
			$param .= '&search_'.$key.'year='.((int) GETPOST('search_'.$key.'year', 'int'));
		} elseif ($search[$key] != '') {
			$param .= '&search_'.$key.'='.urlencode($search[$key]);
		}
	}
	if ($optioncss != '') {
		$param .= '&optioncss='.urlencode($optioncss);
	}


	// List of mass actions available
	$arrayofmassactions = array(
		'startSync'=>img_picto('', 'object_prestasync.svg@prestasync', 'class="pictofixedwidth"').$langs->trans("SyncPrestaOrdersInDolibarr"),
		//'validate'=>img_picto('', 'check', 'class="pictofixedwidth"').$langs->trans("Validate"),
		//'generate_doc'=>img_picto('', 'pdf', 'class="pictofixedwidth"').$langs->trans("ReGeneratePDF"),
		//'builddoc'=>img_picto('', 'pdf', 'class="pictofixedwidth"').$langs->trans("PDFMerge"),
		//'presend'=>img_picto('', 'email', 'class="pictofixedwidth"').$langs->trans("SendByMail"),
	);
	if (!empty($permissiontodelete)) {
//		$arrayofmassactions['predelete'] = img_picto('', 'delete', 'class="pictofixedwidth"').$langs->trans("Delete");
	}
	if (GETPOST('nomassaction', 'int') || in_array($massaction, array('presend', 'predelete'))) {
		$arrayofmassactions = array();
	}
	$massactionbutton = $form->selectMassAction('', $arrayofmassactions);

	print '<form method="POST" id="searchFormList" action="'.$_SERVER["PHP_SELF"].'">'."\n";
	if ($optioncss != '') {
		print '<input type="hidden" name="optioncss" value="'.$optioncss.'">';
	}
	print '<input type="hidden" name="token" value="'.newToken().'">';
	print '<input type="hidden" name="formfilteraction" id="formfilteraction" value="list">';
	print '<input type="hidden" name="action" value="list">';
	print '<input type="hidden" name="id" value="'.$id.'">';
	print '<input type="hidden" name="ref" value="'.$ref.'">';
	print '<input type="hidden" name="sortfield" value="'.$sortfield.'">';
	print '<input type="hidden" name="sortorder" value="'.$sortorder.'">';
	print '<input type="hidden" name="page" value="'.$page.'">';
	print '<input type="hidden" name="contextpage" value="'.$contextpage.'">';
	print '<input type="hidden" name="mode" value="'.$mode.'">';


	$newcardbutton = '';
//	$newcardbutton .= dolGetButtonTitle($langs->trans('ViewList'), '', 'fa fa-bars imgforviewmode', $_SERVER["PHP_SELF"].'?mode=common'.preg_replace('/(&|\?)*mode=[^&]+/', '', $param), '', ((empty($mode) || $mode == 'common') ? 2 : 1), array('morecss'=>'reposition'));
//	$newcardbutton .= dolGetButtonTitle($langs->trans('ViewKanban'), '', 'fa fa-th-list imgforviewmode', $_SERVER["PHP_SELF"].'?mode=kanban'.preg_replace('/(&|\?)*mode=[^&]+/', '', $param), '', ($mode == 'kanban' ? 2 : 1), array('morecss'=>'reposition'));
//	$newcardbutton .= dolGetButtonTitleSeparator();
//	$newcardbutton .= dolGetButtonTitle($langs->trans('New'), '', 'fa fa-plus-circle', dol_buildpath('/prestasync/presta_card.php', 1).'?action=create&backtopage='.urlencode($_SERVER['PHP_SELF']), '', $permissiontoadd);

	print_barre_liste($title, $page, $_SERVER["PHP_SELF"], $param, $sortfield, $sortorder, $massactionbutton, $num, $nbtotalofrecords, 'object_'.$object->picto, 0, $newcardbutton, '', intval($limit), 0, 0, 1);



	$moreforfilter = '';


	$parameters = array();
	$reshook = $hookmanager->executeHooks('printFieldPreListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) {
		$moreforfilter .= $hookmanager->resPrint;
	} else {
		$moreforfilter = $hookmanager->resPrint;
	}

	if (!empty($moreforfilter)) {
		print '<div class="liste_titre liste_titre_bydiv centpercent">';
		print $moreforfilter;
		print '</div>';
	}

	$varpage = empty($contextpage) ? $_SERVER["PHP_SELF"] : $contextpage;
	$selectedfields = $form->multiSelectArrayWithCheckbox('selectedfields', $arrayfields, $varpage, getDolGlobalString('MAIN_CHECKBOX_LEFT_COLUMN', '')); // This also change content of $arrayfields
	$selectedfields .= (count($arrayofmassactions) ? $form->showCheckAddButtons('checkforselect', 1) : '');

	print '<div class="div-table-responsive">'; // You can use div-table-responsive-no-min if you dont need reserved height for your table
	print '<table class="tagtable nobottomiftotal liste'.($moreforfilter ? " listwithfilterbefore" : "").'">'."\n";


// Fields title search
// --------------------------------------------------------------------
	print '<tr class="liste_titre">';
// Action column
	if (!empty($conf->global->MAIN_CHECKBOX_LEFT_COLUMN)) {
		print '<td class="liste_titre maxwidthsearch">';
		$searchpicto = $form->showFilterButtons('left');
		print $searchpicto;
		print '</td>';
	}

	foreach ($arrayfields as $key => $val) {
		$searchkey = empty($search[$key]) ? '' : $search[$key];
		$cssforfield = (empty($val['csslist']) ? (empty($val['css']) ? '' : $val['css']) : $val['csslist']);
		if ($key == 'status') {
			$cssforfield .= ($cssforfield ? ' ' : '').'center';
		} elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) {
			$cssforfield .= ($cssforfield ? ' ' : '').'center';
		} elseif (in_array($val['type'], array('timestamp'))) {
			$cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
		} elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $key != 'rowid' && $val['label'] != 'TechnicalID' && empty($val['arrayofkeyval'])) {
			$cssforfield .= ($cssforfield ? ' ' : '').'right';
		}
		if (!empty($arrayfields[$key]['checked'])) {
			print '<td class="liste_titre'.($cssforfield ? ' '.$cssforfield : '').'">';

			if (!empty($arrayfields[$key]['searchable'])) {
				if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
					print $form->selectarray('search_' . $key, $val['arrayofkeyval'], (isset($search[$key]) ? $search[$key] : ''), $val['notnull'], 0, 0, '', 1, 0, 0, '', 'maxwidth100', 1);
				} elseif ((strpos($val['type'], 'integer:') === 0) || (strpos($val['type'], 'sellist:') === 0)) {
					print $object->showInputField($val, $key, (isset($search[$key]) ? $search[$key] : ''), '', '', 'search_', $cssforfield . ' maxwidth250', 1);
				} elseif (preg_match('/^(date|timestamp|datetime)/', $val['type'])) {
					print '<div class="nowrap">';
					print $form->selectDate($search[$key . '_dtstart'] ? $search[$key . '_dtstart'] : '', "search_" . $key . "_dtstart", 0, 0, 1, '', 1, 0, 0, '', '', '', '', 1, '', $langs->trans('From'));
					print '</div>';
					print '<div class="nowrap">';
					print $form->selectDate($search[$key . '_dtend'] ? $search[$key . '_dtend'] : '', "search_" . $key . "_dtend", 0, 0, 1, '', 1, 0, 0, '', '', '', '', 1, '', $langs->trans('to'));
					print '</div>';
				} elseif ($key == 'lang') {
					require_once DOL_DOCUMENT_ROOT . '/core/class/html.formadmin.class.php';
					$formadmin = new FormAdmin($db);
					print $formadmin->select_language($search[$key], 'search_lang', 0, null, 1, 0, 0, 'minwidth150 maxwidth200', 2);
				} else {
					print '<input type="text" class="flat maxwidth75" name="search_' . $key . '" value="' . dol_escape_htmltag(isset($search[$key]) ? $search[$key] : '') . '">';
				}
			}

			print '</td>';
		}
	}


	// Fields from hook
	$parameters = array('arrayfields'=>$arrayfields);
	$reshook = $hookmanager->executeHooks('printFieldListOption', $parameters, $object); // Note that $action and $object may have been modified by hook
	print $hookmanager->resPrint;
	/*if (!empty($arrayfields['anotherfield']['checked'])) {
		print '<td class="liste_titre"></td>';
	}*/


	// Action column
	if (empty($conf->global->MAIN_CHECKBOX_LEFT_COLUMN)) {
		print '<td class="liste_titre maxwidthsearch">';
		$searchpicto = $form->showFilterButtons();
		print $searchpicto;
		print '</td>';
	}
	print '</tr>'."\n";

	$totalarray = array();
	$totalarray['nbfield'] = 0;

	// Fields title label
	// --------------------------------------------------------------------
	print '<tr class="liste_titre">';
	if (!empty($conf->global->MAIN_CHECKBOX_LEFT_COLUMN)) {
		print getTitleFieldOfList(($mode != 'kanban' ? $selectedfields : ''), 0, $_SERVER["PHP_SELF"], '', '', '', '', $sortfield, $sortorder, 'center maxwidthsearch ')."\n";
	}
	foreach ($arrayfields as $key => $val) {
		$cssforfield = (empty($val['csslist']) ? (empty($val['css']) ? '' : $val['css']) : $val['csslist']);
		if ($key == 'status') {
			$cssforfield .= ($cssforfield ? ' ' : '').'center';
		} elseif (in_array($val['type'], array('date', 'datetime', 'timestamp'))) {
			$cssforfield .= ($cssforfield ? ' ' : '').'center';
		} elseif (in_array($val['type'], array('timestamp'))) {
			$cssforfield .= ($cssforfield ? ' ' : '').'nowrap';
		} elseif (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && $key != 'rowid' && $val['label'] != 'TechnicalID' && empty($val['arrayofkeyval'])) {
			$cssforfield .= ($cssforfield ? ' ' : '').'right';
		}
		$cssforfield = preg_replace('/small\s*/', '', $cssforfield);	// the 'small' css must not be used for the title label
		if (!empty($arrayfields[$key]['checked'])) {
			print getTitleFieldOfList($arrayfields[$key]['label'], 0, $_SERVER['PHP_SELF'], $key, '', $param, ($cssforfield ? 'class="'.$cssforfield.'"' : ''), $sortfield, $sortorder, ($cssforfield ? $cssforfield.' ' : ''), empty($arrayfields[$key]['enableSortLink']))."\n";
			$totalarray['nbfield']++;
		}
	}


	// Hook fields
	$parameters = array('arrayfields'=>$arrayfields, 'param'=>$param, 'sortfield'=>$sortfield, 'sortorder'=>$sortorder, 'totalarray'=>&$totalarray);
	$reshook = $hookmanager->executeHooks('printFieldListTitle', $parameters, $object); // Note that $action and $object may have been modified by hook
	print $hookmanager->resPrint;
	/*if (!empty($arrayfields['anotherfield']['checked'])) {
		print '<th class="liste_titre right">'.$langs->trans("AnotherField").'</th>';
		$totalarray['nbfield']++;
	}*/

	// Action column
	if (empty($conf->global->MAIN_CHECKBOX_LEFT_COLUMN)) {
		print getTitleFieldOfList(($mode != 'kanban' ? $selectedfields : ''), 0, $_SERVER["PHP_SELF"], '', '', '', '', $sortfield, $sortorder, 'center maxwidthsearch ')."\n";
	}
	$totalarray['nbfield']++;
	print '</tr>'."\n";




	// Loop on record
	// --------------------------------------------------------------------
	$i = 0;
	$savnbfield = $totalarray['nbfield'];
	$totalarray = array();
	$totalarray['nbfield'] = 0;
	$imaxinloop = ($limit ? min($num, $limit) : $num);
	if ($resources) {
		foreach ($resources as $obj) {

			// A cause de la gestion de la pagination dynamique il ne faut pas inclure les resultats apres la limite
			if($i >= $imaxinloop) {
				break;
			}

			$i++;

			if (empty($obj)) {
				break; // Should not happen
			}


			$prestaOrder = new PrestaOrder($object);
			$prestaOrder->populate($obj);
			$prestaOrder->getDolLinkInfo();

			// générate mapping
			if(!in_array($prestaOrder->payment, $autoCreateMappingAllreadyDone)){
				require_once __DIR__ . '/class/mappingpayment.class.php';
				$mappingPaiement = new MappingPayment($prestaOrder->presta->db);
				$mappingPaiement->autoCreateMapping($user, $object,$prestaOrder->payment);
				$autoCreateMappingAllreadyDone[$prestaOrder->payment] = $prestaOrder->payment;
			}

			// Show here line of result
			$j = 0;
			print '<tr data-rowid="' . $prestaOrder->id . '" class="oddeven">';
			// Action column
			if (!empty($conf->global->MAIN_CHECKBOX_LEFT_COLUMN)) {
				print '<td class="nowrap center">';
				if ($massactionbutton || $massaction) { // If we are in select mode (massactionbutton defined) or if we have already selected and sent an action ($massaction) defined
					$selected = 0;
					if (in_array($prestaOrder->id, $arrayofselected)) {
						$selected = 1;
					}
					print '<input id="cb' . $prestaOrder->id . '" class="flat checkforselect" type="checkbox" name="toselect[]" value="' . $prestaOrder->id . '"' . ($selected ? ' checked="checked"' : '') . '>';
				}
				print '</td>';
			}

			foreach ($arrayfields as $key => $val) {

				$cssforfield = (empty($val['csslist']) ? (empty($val['css']) ? '' : $val['css']) : $val['csslist']);
				if (in_array($val['type'], array('date', 'datetime', 'timestamp'))) {
					$cssforfield .= ($cssforfield ? ' ' : '') . 'center';
				} elseif ($key == 'status') {
					$cssforfield .= ($cssforfield ? ' ' : '') . 'center';
				}

				if (in_array($val['type'], array('timestamp'))) {
					$cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';
				} elseif ($key == 'ref') {
					$cssforfield .= ($cssforfield ? ' ' : '') . 'nowrap';
				}

				if (in_array($val['type'], array('double(24,8)', 'double(6,3)', 'integer', 'real', 'price')) && !in_array($key, array('rowid', 'status')) && empty($val['arrayofkeyval'])) {
					$cssforfield .= ($cssforfield ? ' ' : '') . 'right';
				}
				//if (in_array($key, array('fk_soc', 'fk_user', 'fk_warehouse'))) $cssforfield = 'tdoverflowmax100';

				if (!empty($arrayfields[$key]['checked'])) {
					print '<td' . ($cssforfield ? ' class="' . $cssforfield . '"' : '');
					if (preg_match('/tdoverflow/', $cssforfield)) {
						print ' title="' . dol_escape_htmltag($prestaOrder->$key) . '"';
					}
					print '>';

					if($key == 'sync_status'){
						print $prestaOrder->getStatusBadge(5);
					}
					else if ($key == 'dol_ref') {
						$prestaOrder->fetchDolibarrObject();
						if ($prestaOrder->doliObject) {
							print $prestaOrder->doliObject->getNomUrl(1);
						}
					}
					elseif($key == 'reference'){
						print '<a href="'.dol_buildpath('prestasync/presta_order.php',1).'?id='.$object->id.'&amp;presta_id='.$obj->id.'">'.$obj->$key.'</a>';
					}
					elseif($key == 'id_address_delivery' && isset($resourcesAddresses[$obj->$key]) ||  $key == 'id_address_invoice' && isset($resourcesAddresses[$obj->$key])){

						print '<small >';
						print $resourcesAddresses[$obj->$key]->getFullAddress();
						print '</small>';

					}elseif($key == 'id_customer' && isset($resourcesCustomers[$obj->id_customer])){
						print ucfirst($resourcesCustomers[$obj->id_customer]->firstname).' '.strtoupper($resourcesCustomers[$obj->id_customer]->lastname);
					}elseif($key == 'current_state' && isset($prestaOrderStates[$obj->current_state])){
						$curOrderStatus = $prestaOrderStates[$obj->current_state];
						$moreStyle = '';
						if(!colorIsLight($curOrderStatus->color)){
							$moreStyle = 'color:#fff;';
						}
						print '<span class="badge" style="background-color:'.$curOrderStatus->color.';'.$moreStyle.'" >' .  $prestaOrderStatic->getTradValue($prestaOrderStates[intval($obj->current_state)]->name) . '</span>';
					}else{

						if($arrayfields[$key]['type'] == 'price'){
							print price(price2num($obj->$key));
						}
						else{
							print $obj->$key;
						}
					}

					print '</td>';
					if (!$i) {
						$totalarray['nbfield']++;
					}
					if (!empty($val['isameasure']) && $val['isameasure'] == 1) {
						if (!$i) {
							$totalarray['pos'][$totalarray['nbfield']] = $key;
						}
						if (!isset($totalarray['val'])) {
							$totalarray['val'] = array();
						}
						if (!isset($totalarray['val'][$key])) {
							$totalarray['val'][$key] = 0;
						}
						$totalarray['val'][$key] += $prestaOrder->$key;
					}
				}
			}
			// Extra fields
			include DOL_DOCUMENT_ROOT . '/core/tpl/extrafields_list_print_fields.tpl.php';
			// Fields from hook
			$parameters = array('arrayfields' => $arrayfields, 'object' => $object, 'obj' => $obj, 'i' => $i, 'totalarray' => &$totalarray, 'prestaOrder' => $prestaOrder);
			$reshook = $hookmanager->executeHooks('printFieldListValue', $parameters, $object); // Note that $action and $object may have been modified by hook
			print $hookmanager->resPrint;
			/*if (!empty($arrayfields['anotherfield']['checked'])) {
				print '<td class="right">'.$obj->anotherfield.'</td>';
			}*/
			// Action column
			if (empty($conf->global->MAIN_CHECKBOX_LEFT_COLUMN)) {
				print '<td class="nowrap center">';
				if ($massactionbutton || $massaction) { // If we are in select mode (massactionbutton defined) or if we have already selected and sent an action ($massaction) defined
					$selected = 0;
					if (in_array($prestaOrder->id, $arrayofselected)) {
						$selected = 1;
					}
					print '<input id="cb' . $prestaOrder->id . '" class="flat checkforselect" type="checkbox" name="toselect[]" value="' . $prestaOrder->id . '"' . ($selected ? ' checked="checked"' : '') . '>';
				}
				print '</td>';
			}
			if (!$i) {
				$totalarray['nbfield']++;
			}

			print '</tr>' . "\n";
		}
	}


	// Show total line
	include DOL_DOCUMENT_ROOT.'/core/tpl/list_print_total.tpl.php';

	// If no record found
	if (!$resources) {
		$colspan = 1;
		foreach ($arrayfields as $key => $val) {
			if (!empty($val['checked'])) {
				$colspan++;
			}
		}

		print '<tr><td colspan="'.$colspan.'"><span class="opacitymedium">';
		if($resources === false){
			print $object->error;
		}else{
			print $langs->trans("NoRecordFound");
		}
		print '</span></td></tr>';
	}


	$parameters = array('arrayfields'=>$arrayfields);
	$reshook = $hookmanager->executeHooks('printFieldListFooter', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	print $hookmanager->resPrint;

	print '</table>'."\n";
	print '</div>'."\n";

	print '</form>'."\n";
}


// End of page
llxFooter();
$db->close();

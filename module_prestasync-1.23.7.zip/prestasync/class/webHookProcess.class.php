<?php
/* Copyright (C) 2024 John BOTELLA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

namespace prestasync;

require_once __DIR__ . '/jsonWebHookResponse.class.php';
require_once __DIR__ . '/presta.class.php';

class WebHookProcess
{

	/**
	 * @var JsonWebHookResponse
	 */
	public $response;

	/**
	 * @var DoliDB        Database handler (result of a new DoliDB)
	 */
	public $db;

	/**
	 * @var \Presta
	 */
	public $presta;

	/**
	 *    Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
		$this->response = new JsonWebHookResponse();
	}

	public function processWebHook($webHookToken, $id)
	{
		global $user;

		if (!$webHookToken || !$id) {
			http_response_code(400);
			return false;
		}

		$this->presta = new \Presta($this->db);
		if ($this->presta->fetch($id) <= 0) {
			http_response_code(404);
			return false;
		}

		if ($this->presta->generateWebHookToken() !== $webHookToken) {
			return false;
		}

		$prestasyncUser = getDolGlobalInt('PRESTASYNC_USER');
		if (!$prestasyncUser || $prestasyncUser < 1) {
			http_response_code(500);
			$this->response->msg = 'invalid user in setup';
			return false;
		}

		if (!class_exists('User')) {
			require_once DOL_DOCUMENT_ROOT . '/user/class/user.class.php';
		}

		// Note : $user is over-written because in somme process Dolibarr use global $user var and it's trigger fatal error
		$user = $webHookUser = new \User($this->db);
		if ($webHookUser->fetch($prestasyncUser) <= 0) {
			http_response_code(500);
			$this->response->msg = 'invalid user in setup';
			return false;
		}

		$webHookUser->loadRights();

		$input = file_get_contents('php://input');
		if (empty($input) || (function_exists('json_validate') && !json_validate($input))) {
			$this->response->msg = 'invalid JSon code 01';
			http_response_code(400);
			return false;
		}

		$data = json_decode($input);
		if (json_last_error() !== JSON_ERROR_NONE) {
			$this->response->msg = 'invalid JSon code 02';
			http_response_code(400);
			return false;
		}

		if (empty($data->event)) {
			$this->response->msg = 'invalid event';
			http_response_code(400);
			return false;
		}

		if (empty($data->resource)) {
			$this->response->msg = 'invalid resource';
			http_response_code(400);
			return false;
		}

		$methodName = 'webHookEvent_' . $data->event;
		if (is_callable([
							$this,
							$methodName,
						])) {
			return call_user_func([$this, $methodName], $webHookUser, $data);
		}

		return false;
	}

	/**
	 * @param \User     $webHookUser
	 * @param \stdClass $inputData
	 *
	 * @return bool
	 */
	function webHookEvent_orderStatusUpdate(\User $webHookUser, \stdClass $inputData)
	{
		global $langs;

		if (empty($inputData->data->id_order)) {
			$this->response->msg = 'invalid order id';
			http_response_code(400);
			return false;
		}

//		$data->newOrderStatus->id
//		$data->newOrderStatus->paid
//		$data->newOrderStatus->shipped

		$needFetchOrder = false;
		$statusToSyncList = $this->presta->getOrderStatusToSync();
		if (in_array($inputData->data->newOrderStatus->id, $statusToSyncList)) {
			$needFetchOrder = true;
		}

		$statusDeliveredList = $this->presta->getOrderStatusDelivred();
		if (in_array($inputData->data->newOrderStatus->id, $statusDeliveredList)) {
			$needFetchOrder = true;
		}

		if ($needFetchOrder) {
			require_once __DIR__ . '/prestaOrder.class.php';
			$prestaOrder = new \PrestaOrder($this->presta);
			$res = $prestaOrder->fetch($inputData->data->id_order);
			if (!$res) {
				http_response_code(404);
				$this->response->msg = 'Order not found';
				return false;
			}

			// Check if order exist in Dolibarr
			$dolibarrOrderExist = $prestaOrder->fetchDolibarrObject();

			// IMPORT ORDER IN DOLIBARR
			// If status need to create order and order not exist
			if (!$dolibarrOrderExist && in_array($inputData->data->newOrderStatus->id, $statusToSyncList)) {
				$prestaOrder->clearErrors();
				if ($prestaOrder->syncToDolibarr($webHookUser) && !$prestaOrder->getErrors()) {
					$this->response->msg = $langs->trans('OrderImportedSuccessfully');
					$this->response->result = 1;

					// Now need to re-fetch for other action in process steps
					$dolibarrOrderExist = $prestaOrder->fetchDolibarrObject();
				}

				$err = $prestaOrder->getErrors();
				if (!empty($err)) {
					$this->response->msg = $err;
					$this->response->result = -1;
					http_response_code(500);
					return false;
				}
			}

			// CLASS ORDER CLOSED on delivered
			// If order exist in Dolibarr and need update dolibarr order status
			if ($this->response->result >= 0 && $dolibarrOrderExist && in_array($inputData->data->newOrderStatus->id, $statusDeliveredList)) {
				if (in_array($prestaOrder->doliObject->status, [\Commande::STATUS_VALIDATED, \Commande::STATUS_SHIPMENTONPROCESS])) {
					if ($prestaOrder->doliObject->setStatut(\Commande::STATUS_CLOSED) <= 0) {
						http_response_code(500);
						$this->response->msg = 'Fail set order status to close';
						$this->response->result = -1;
						return false;
					} else {
						$this->response->msg = 'Status update';
						$this->response->result = 1;
					}
				} else {
					$this->response->msg = 'Skipped due to status';
					$this->response->result = 0;
				}
			}
		}

		return true; // nothing to do all is ok
	}

}

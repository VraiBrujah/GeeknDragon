<?php
/* Copyright (C) 2015   Jean-François Ferry     <jfefe@aternatik.fr>
 * Copyright (C) 2020   Thibault FOUCART		<support@ptibogxiv.net>
 * Copyright (C) 2023	Joachim Kueter			<git-jk@bloxera.com>
 * Copyright (C) 2024		Frédéric France			<frederic.france@free.fr>
 * Copyright (C) 2024		MDW							<mdeweerd@users.noreply.github.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

use Luracast\Restler\RestException;

require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture-rec.class.php';
require_once __DIR__ . '/presta.class.php';
require_once __DIR__ . '/prestaCustomer.class.php';
require_once __DIR__ . '/prestaOrder.class.php';

/**
 * API class for invoices
 *
 * @access protected
 * @class  DolibarrApiAccess {@requires user,external}
 */
class Prestasync extends DolibarrApi
{
	/**
	 * @var array $FIELDS Mandatory fields, checked when create and update object
	 */
	public static $FIELDS = [
		'socid',
	];

	/**
	 * @var Facture $invoice {@type Facture}
	 */
	private $invoice;

	/**
	 * Constructor
	 */
	public function __construct()
	{
		global $db;
		$this->db = $db;
		$this->invoice = new Facture($this->db);
	}

	/**
	 * Get properties of an invoice object
	 * Return an array with invoice information
	 *
	 * @param int    $id           ID of order
	 * @param string $ref          Ref of object
	 * @param string $ref_ext      External reference of object
	 * @param int    $contact_list 0: Returned array of contacts/addresses contains all properties, 1: Return array contains just id, -1: Do not return contacts/adddesses
	 *
	 * @return    Object                        Object with cleaned properties
	 * @throws    RestException
	 */
	private function _fetch($id, $ref = '', $ref_ext = '', $contact_list = 1)
	{
		if (!DolibarrApiAccess::$user->hasRight('facture', 'lire')) {
			throw new RestException(403);
		}

		$result = $this->invoice->fetch($id, $ref, $ref_ext);
		if (!$result) {
			throw new RestException(404, 'Invoice not found');
		}

		// Get payment details
		$this->invoice->totalpaid = $this->invoice->getSommePaiement();
		$this->invoice->totalcreditnotes = $this->invoice->getSumCreditNotesUsed();
		$this->invoice->totaldeposits = $this->invoice->getSumDepositsUsed();
		$this->invoice->remaintopay = price2num($this->invoice->total_ttc - $this->invoice->totalpaid - $this->invoice->totalcreditnotes - $this->invoice->totaldeposits, 'MT');

		if (!DolibarrApi::_checkAccessToResource('facture', $this->invoice->id)) {
			throw new RestException(403, 'Access not allowed for login ' . DolibarrApiAccess::$user->login);
		}

		// Add external contacts ids
		if ($contact_list > -1) {
			$tmparray = $this->invoice->liste_contact(-1, 'external', $contact_list);
			if (is_array($tmparray)) {
				$this->invoice->contacts_ids = $tmparray;
			}
		}

		$this->invoice->fetchObjectLinked();

		// Add online_payment_url, copied from order
		require_once DOL_DOCUMENT_ROOT . '/core/lib/payments.lib.php';
		$this->invoice->online_payment_url = getOnlinePaymentUrl(0, 'invoice', $this->invoice->ref);

		return $this->_cleanObjectDatas($this->invoice);
	}

	/**
	 * List invoices
	 * Get a list of invoices
	 *
	 * @param string $prestashop_ref     prestashop ref
	 * @param int    $prestashop_user_id prestashop user id
	 * @param int    $presta_order_id prestashop order id
	 * @param string $sortfield          Sort field
	 * @param string $sortorder          Sort order
	 * @param int    $limit              Limit for list
	 * @param int    $page               Page number
	 * @param string $sqlfilters         Other criteria to filter answers separated by a comma. Syntax example "(t.ref:like:'SO-%') and (t.date_creation:<:'20160101')"
	 * @param string $properties         Restrict the data returned to these properties. Ignored if empty. Comma separated list of properties names
	 *
	 * @return array                      Array of invoice objects
	 * @url GET    {prestashop_ref}/invoices/{prestashop_user_id}
	 * @throws RestException 404 Not found
	 * @throws RestException 503 Error
	 */
	public function index($prestashop_ref, $prestashop_user_id, $presta_order_id = 0, $sortfield = "t.rowid", $sortorder = 'ASC', $limit = 100, $page = 0, $sqlfilters = '', $properties = '')
	{
		if (!DolibarrApiAccess::$user->hasRight('facture', 'lire')) {
			throw new RestException(403);
		}

		$presta = new Presta($this->db);
		if ($presta->fetch(null, $prestashop_ref) <= 0) {
			throw new RestException(404, 'Error fail loading Prestashop -> ' . $prestashop_ref);
		}

		$prestaCustomer = new PrestaCustomer($presta);
		$prestaCustomer->id = (int) $prestashop_user_id;
		if (!$prestaCustomer->getDolLinkInfo()) {
			throw new RestException(404, 'Error fail find Prestashop customer -> ' . $prestashop_user_id);
		}

		if (empty($prestaCustomer->doliElementId)) {
			throw new RestException(500, 'Error fail find Prestashop thirdparty sur prestashop customer : ' . $prestashop_user_id);
		}

		$thirdparty_ids = $prestaCustomer->doliElementId;
		$invoicesIds = [];

		if($presta_order_id > 0){
			$prestaOrder= new PrestaOrder($presta);

			$prestaOrder->id = (int) $presta_order_id;
			if (!$prestaOrder->getDolLinkInfo()) {
				throw new RestException(404, 'Error fail find Prestashop order -> ' . $presta_order_id);
			}

			$prestaOrder->fetchDolibarrObject();
			if(empty($prestaOrder->doliObject)){
				throw new RestException(500, 'Error fail load Prestashop order -> ' . $presta_order_id);
			}

			$prestaOrder->doliObject->fetchObjectLinked();
			if(empty($prestaOrder->doliObject->linkedObjectsIds) || empty($prestaOrder->doliObject->linkedObjectsIds['facture'])){
				throw new RestException(404, 'Error fail find Prestashop order -> ' . $presta_order_id);
			}

			$invoicesIds = array_merge($invoicesIds, $prestaOrder->doliObject->linkedObjectsIds['facture']);
		}


		$obj_ret = [];

		// case of external user, $thirdparty_ids param is ignored and replaced by user's socid
		$socids = DolibarrApiAccess::$user->socid ? DolibarrApiAccess::$user->socid : $thirdparty_ids;

		// If the internal user must only see his customers, force searching by him
		$search_sale = 0;
		if (!DolibarrApiAccess::$user->hasRight('societe', 'client', 'voir') && !$socids) {
			$search_sale = DolibarrApiAccess::$user->id;
		}

		$sql = "SELECT t.rowid";
		$sql .= " FROM " . MAIN_DB_PREFIX . "facture AS t";
		$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "facture_extrafields AS ef ON (ef.fk_object = t.rowid)"; // Modification VMR Global Solutions to include extrafields as search parameters in the API GET call, so we will be able to filter on extrafields
		$sql .= ' WHERE t.entity IN (' . getEntity('invoice') . ')';
		$sql .= " AND t.fk_soc IN (" . $this->db->sanitize($socids) . ")";

		// Search on sale representative
		if ($search_sale && $search_sale != '-1') {
			if ($search_sale == -2) {
				$sql .= " AND NOT EXISTS (SELECT sc.fk_soc FROM " . MAIN_DB_PREFIX . "societe_commerciaux as sc WHERE sc.fk_soc = t.fk_soc)";
			} elseif ($search_sale > 0) {
				$sql .= " AND EXISTS (SELECT sc.fk_soc FROM " . MAIN_DB_PREFIX . "societe_commerciaux as sc WHERE sc.fk_soc = t.fk_soc AND sc.fk_user = " . ((int) $search_sale) . ")";
			}
		}

		if(!empty($invoicesIds)){
			$invoicesIds = array_map('intval', $invoicesIds);
			$sql .= ' AND t.rowid IN ('.implode(',', $invoicesIds).')';
		}

		// Filter by status
		$sql .= " AND t.fk_statut IN (1,2)";

		// Add sql filters
		if ($sqlfilters) {
			$errormessage = '';
			$sql .= forgeSQLFromUniversalSearchCriteria($sqlfilters, $errormessage);
			if ($errormessage) {
				throw new RestException(400, 'Error when validating parameter sqlfilters -> ' . $errormessage);
			}
		}

		$sql .= $this->db->order($sortfield, $sortorder);
		if ($limit) {
			if ($page < 0) {
				$page = 0;
			}
			$offset = $limit * $page;

			$sql .= $this->db->plimit($limit + 1, $offset);
		}

		$result = $this->db->query($sql);
		if ($result) {
			$i = 0;
			$num = $this->db->num_rows($result);
			$min = min($num, ($limit <= 0 ? $num : $limit));
			while ($i < $min) {
				$obj = $this->db->fetch_object($result);
				$invoice_static = new Facture($this->db);
				if ($invoice_static->fetch($obj->rowid)) {
					// Get payment details
					$invoice_static->totalpaid = $invoice_static->getSommePaiement();
					$invoice_static->totalcreditnotes = $invoice_static->getSumCreditNotesUsed();
					$invoice_static->totaldeposits = $invoice_static->getSumDepositsUsed();
					$invoice_static->remaintopay = price2num($invoice_static->total_ttc - $invoice_static->totalpaid - $invoice_static->totalcreditnotes - $invoice_static->totaldeposits, 'MT');

					// Add external contacts ids
					$tmparray = $invoice_static->liste_contact(-1, 'external', 1);
					if (is_array($tmparray)) {
						$invoice_static->contacts_ids = $tmparray;
					}
					// Add online_payment_url, copied from order
					require_once DOL_DOCUMENT_ROOT . '/core/lib/payments.lib.php';
					$invoice_static->online_payment_url = getOnlinePaymentUrl(0, 'invoice', $invoice_static->ref);

					$obj_ret[] = $this->_filterObjectProperties($this->_cleanObjectDatas($invoice_static), $properties);
				}
				$i++;
			}
		} else {
			throw new RestException(503, 'Error when retrieve invoice list : ' . $this->db->lasterror());
		}

		return $obj_ret;
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore

	/**
	 * Clean sensible object datas
	 *
	 * @param Object $object Object to clean
	 *
	 * @return  Object              Object with cleaned properties
	 */
	protected function _cleanObjectDatas($object)
	{
		// phpcs:enable
		$object = parent::_cleanObjectDatas($object);

		unset($object->note);
		unset($object->address);
		unset($object->barcode_type);
		unset($object->barcode_type_code);
		unset($object->barcode_type_label);
		unset($object->barcode_type_coder);
		unset($object->canvas);

		return $object;
	}

	/**
	 * Validate fields before create or update object
	 *
	 * @param array|null $data Datas to validate
	 *
	 * @return    array
	 * @throws RestException
	 */
	private function _validate($data)
	{
		$invoice = [];
		foreach (Invoices::$FIELDS as $field) {
			if (!isset($data[$field])) {
				throw new RestException(400, "$field field missing");
			}
			$invoice[$field] = $data[$field];
		}
		return $invoice;
	}



	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore

	/**
	 * Clean sensible object datas
	 *
	 * @param Object $object Object to clean
	 *
	 * @return  Object              Object with cleaned properties
	 */
	protected function _cleanTemplateObjectDatas($object)
	{
		// phpcs:enable
		$object = parent::_cleanObjectDatas($object);

		unset($object->note);
		unset($object->address);
		unset($object->barcode_type);
		unset($object->barcode_type_code);
		unset($object->barcode_type_label);
		unset($object->barcode_type_coder);
		unset($object->canvas);

		return $object;
	}

	/**
	 * Download invoice PDF
	 *
	 * @param string $prestashop_ref     prestashop ref
	 * @param int    $prestashop_user_id prestashop user id
	 * @param int    $invoice_id         dolibarr invoice id
	 *
	 * @return array                      Array of invoice objects
	 * @url GET    {prestashop_ref}/invoices/{prestashop_user_id}/download/{invoice_id}
	 * @throws    RestException
	 */
	public function downloadInvoicePDF($prestashop_ref, $prestashop_user_id, $invoice_id)
	{
		global $conf;
		$modulepart = 'invoice';
		require_once __DIR__ . '/prestaOrder.class.php';
		require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
		require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';

		if (!DolibarrApiAccess::$user->hasRight('facture', 'lire')) {
			throw new RestException(403);
		}

		$presta = new Presta($this->db);
		if ($presta->fetch(null, $prestashop_ref) <= 0) {
			throw new RestException(404, 'Error fail loading Prestashop -> ' . $prestashop_ref);
		}

		$prestaCustomer = new PrestaCustomer($presta);
		$prestaCustomer->id = (int) $prestashop_user_id;
		if (!$prestaCustomer->getDolLinkInfo()) {
			throw new RestException(404, 'Error fail find Prestashop customer -> ' . $prestashop_user_id);
		}

		if (empty($prestaCustomer->doliElementId)) {
			throw new RestException(500, 'Error fail find Prestashop thirdparty sur prestashop customer : ' . $prestashop_user_id);
		}

		$thirdparty_ids = $prestaCustomer->doliElementId;
		if (empty($thirdparty_ids)) {
			throw new RestException(403);
		}

		if (!DolibarrApiAccess::$user->hasRight('facture', 'lire')) {
			throw new RestException(403);
		}

		$invoice = new Facture($this->db);
		$result = $invoice->fetch($invoice_id);
		if (!$result) {
			throw new RestException(404, 'Invoice not found');
		}

		if ($invoice->socid != $thirdparty_ids) {
			throw new RestException(403);
		}

		$sortfield = 'name';
		$sortorder = 'desc';
		$upload_dir = $conf->invoice->dir_output . "/" . get_exdir(0, 0, 0, 1, $invoice, 'invoice');

		$objectType = 'invoice';
		if (!empty($invoice->id) && !empty($invoice->table_element)) {
			$objectType = $invoice->table_element;
		}

		$filearray = dol_dir_list($upload_dir, 'files', 0, '', '(\.meta|_preview.*\.png)$', $sortfield, (strtolower($sortorder) == 'desc' ? SORT_DESC : SORT_ASC), 1);
		if (empty($filearray)) {
			throw new RestException(404, 'Search for modulepart Invoice with Id ' . $invoice->id . (!empty($invoice->ref) ? ' or Ref ' . $invoice->ref : '') . ' does not return any document.');
		} else {
			if (($invoice->id) > 0) {
				require_once DOL_DOCUMENT_ROOT . '/ecm/class/ecmfiles.class.php';
				$ecmfile = new EcmFiles($this->db);
				$result = $ecmfile->fetchAll('', '', 0, 0, ['t.src_object_type' => $objectType, 't.src_object_id' => $invoice->id]);
				if ($result < 0) {
					throw new RestException(503, 'Error when retrieve ecm list : ' . $this->db->lasterror());
				} elseif (is_array($ecmfile->lines) && count($ecmfile->lines) > 0) {
					$count = count($filearray);
					for ($i = 0; $i < $count; $i++) {
						foreach ($ecmfile->lines as $line) {
							if ($filearray[$i]['name'] == $line->filename) {
								$filearray[$i] = array_merge($filearray[$i], (array) $line);
							}
						}
					}
				}
			}
		}

		if (empty($filearray)) {
			throw new RestException(404, 'File not found');
		}

		$original_file = false;
		foreach ($filearray as $file) {
			if (basename($file['path']) . '/' . $file['relativename'] === dol_sanitizeFileName($invoice->ref) . '/' . dol_sanitizeFileName($invoice->ref) . '.pdf') {
				$original_file = basename($file['path']) . '/' . $file['relativename'];
			}
		}

		if (empty($original_file)) {
			throw new RestException(404, 'File not found');
		}

		//--- Finds and returns the document
		$entity = $invoice->entity;

		$relativefile = $original_file;

		$check_access = dol_check_secure_access_document($modulepart, $relativefile, $entity, DolibarrApiAccess::$user, '', 'read');
		$accessallowed = $check_access['accessallowed'];
		$sqlprotectagainstexternals = $check_access['sqlprotectagainstexternals'];
		$original_file = $check_access['original_file'];

		if (preg_match('/\.\./', $original_file) || preg_match('/[<>|]/', $original_file)) {
			throw new RestException(403);
		}
		if (!$accessallowed) {
			throw new RestException(403);
		}

		$filename = basename($original_file);
		$original_file_osencoded = dol_osencode($original_file); // New file name encoded in OS encoding charset

		if (!file_exists($original_file_osencoded)) {
			dol_syslog("Try to download not found file " . $original_file_osencoded, LOG_WARNING);
			throw new RestException(404, 'File not found');
		}

		$file_content = file_get_contents($original_file_osencoded);
		return ['filename' => $filename, 'content-type' => dol_mimetype($filename), 'filesize' => filesize($original_file), 'content' => base64_encode($file_content), 'encoding' => 'base64'];
	}
}

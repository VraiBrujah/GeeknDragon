<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaCountries extends PrestaCommonObject
{
	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'countries';

	/**
	 * the Dolibarr linked object
	 * linked to disctionnary llx_c_country
	 *
	 * @var stdClass $doliObject ;
	 */
	public $doliObject;

	public $fields = [
		'id' => [],
		'id_zone' => [],
		'id_currency' => [],
		'call_prefix' => [],
		'iso_code' => [],
		'active' => [],
		'contains_states' => [],
		'need_identification_number' => [],
		'need_zip_code' => [],
		'zip_code_format' => [],
		'display_tax_label' => [],
		'name' => [],
	];

	public $id;
	public $id_zone;
	public $id_currency;
	public $call_prefix;
	public $iso_code;
	public $active;
	public $contains_states;
	public $need_identification_number;
	public $need_zip_code;
	public $zip_code_format;
	public $display_tax_label;
	public $name;

	public function getDolibarrCountry($id = 0, $code_iso = false)
	{
		if (empty($id) && empty($code_iso)) {
			return false;
		}

		$sql = 'SELECT rowid id, code_iso, code, label FROM ' . $this->presta->db->prefix() . 'c_country WHERE ';
		if (!empty($id)) {
			$sql .= ' rowid = ' . intval($id) . ' ';
		} else {
			if (strlen($code_iso) < 3) {
				$sql .= ' code = \'' . $this->presta->db->escape($code_iso) . '\' ';
			} else {
				$sql .= ' code_iso = \'' . $this->presta->db->escape($code_iso) . '\' ';
			}
		}

		return $this->presta->db->getRow($sql);
	}

}

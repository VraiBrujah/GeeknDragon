<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaError.trait.php';

class PrestaImage
{
	use PrestaErrors;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'images';

	/**
	 * @param Presta $presta
	 */
	public function __construct(Presta $presta)
	{
		global $langs;
		$langs->load('prestasync@prestasync');
		$this->presta = $presta;
	}

	/**
	 * @return void|string
	 * TODO ADD CACHE MANAGEMENT
	 */
	public function getProductImage($productId, $imageId)
	{
//		$url = $this->presta->shop_url.'/api/'.$this->resource.'/products/'.intval($productId).'/'.intval($imageId);
//var_dump($url);
//		header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
//		header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
//		header('Content-type:'); // not sure why this work
//
//		$ch = curl_init();
//		curl_setopt($ch, CURLOPT_URL, $url);
//		curl_setopt($ch, CURLOPT_USERPWD, $this->presta->api_key.':');
//		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
//		curl_exec($ch);
//		curl_close($ch);

//var_dump($this->resource.'/products/'.intval($productId).'/'.intval($imageId));

		$out = $this->presta->getFileFromWebService($this->resource . '/products/' . intval($productId) . '/' . intval($imageId));
		if ($out === false) {
			if (!empty($this->presta->errors)) {
				$this->setError($this->presta->errorsToString());
			} else {
				$this->setError('Fail loading image');
			}
			return false;
		}

		return $out;
	}
	/**
	 * @return void|string
	 * TODO ADD CACHE MANAGEMENT
	 */
	public function getCustomizationImage($customizationId, $imageId, $cartId)
	{

		$out = $this->presta->getFileFromWebService($this->resource . '/customizations/' . intval($cartId) . '/' . intval($customizationId) . '/' . intval($imageId) . '/');
		if ($out === false) {
			if (!empty($this->presta->errors)) {
				$this->setError($this->presta->errorsToString());
			} else {
				$this->setError('Fail loading image');
			}
			return false;
		}

		return $out;
	}

	static public function outputImage($raw, $noCache = true)
	{
		$mime = static::getMimeFromFileString($raw);
		header("Content-Type: " . $mime);
		if ($noCache) {
			header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
		} else {
			header("Cache-Control: max-age=86400"); // HTTP/1.1
		}

		header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
		echo $raw;
	}

	/**
	 * @param $raw file string
	 *
	 * @return string
	 */
	static public function getMimeFromFileString($raw, $cleanMime = true)
	{
		$finfo = new finfo(FILEINFO_MIME);
		$mimeRaw = $finfo->buffer($raw);
		if ($cleanMime) {
			$mime = explode(';', $mimeRaw, 2);
			return reset($mime);
		}

		return $mimeRaw;
	}

	/**
	 * @param $mime
	 *
	 * @return false|string
	 */
	static public function getExtentionFromMime($mime)
	{
		$list = [
			'image/bmp' => 'bmp',
			'image/cdr' => 'cdr',
			'image/gif' => 'gif',
			'image/jp2' => 'jp2',
			'image/jpeg' => 'jpeg',
			'image/jpm' => 'jp2',
			'image/jpx' => 'jp2',
			'image/ms-bmp' => 'bmp',
			'image/pjpeg' => 'jpeg',
			'image/png' => 'png',
			'image/svg+xml' => 'svg',
			'image/tiff' => 'tiff',
			'image/vnd.adobe.photoshop' => 'psd',
			'image/vnd.microsoft.icon' => 'ico',
			'image/webp' => 'webp',
			'image/x-bitmap' => 'bmp',
			'image/x-bmp' => 'bmp',
			'image/x-cdr' => 'cdr',
			'image/x-ico' => 'ico',
			'image/x-icon' => 'ico',
			'image/x-ms-bmp' => 'bmp',
			'image/x-png' => 'png',
			'image/x-win-bitmap' => 'bmp',
			'image/x-windows-bmp' => 'bmp',
			'image/x-xbitmap' => 'bmp',
		];

		if (!isset($list[$mime])) {
			return false;
		}

		return $list[$mime];
	}

	static public function webpToJpg($webpFilePath, $destJpgFileDest, $quality = 90)
	{
		// Charge le fichier WebP
		$im = imagecreatefromwebp($webpFilePath);
		if (!$im) {
			return false;
		}

		// On la convertit en un fichier jpeg avec une qualité à 100%
		if (!imagejpeg($im, $destJpgFileDest, $quality)) {
			return false;
		}

		imagedestroy($im);

		return true;
	}

	/**
	 * @param Product $product
	 *
	 * @return false|string
	 */
	public function getImageProductDir(Product $product)
	{
		global $conf;
		if (isModEnabled('product')) {
			return $conf->product->multidir_output[$product->entity] . '/' . get_exdir(0, 0, 0, 1, $product, 'product');
		} elseif (isModEnabled('service')) {
			return $conf->service->multidir_output[$product->entity] . '/' . get_exdir(0, 0, 0, 1, $product, 'product');
		} else {
			$this->setError('Module for product for service not enabled');
			return false;
		}
	}

	/**
	 * @param Commande $order
	 *
	 * @return false|string
	 */
	public function getImageOrderDir(Commande $order)
	{
		global $conf;
		if (isModEnabled('order')) {
			return $conf->order->multidir_output[$order->entity] . '/' . get_exdir(0, 0, 0, 1, $order, 'order');
		} else {
			$this->setError('Module for Order not enabled');
			return false;
		}
	}

	/**
	 * @param Propal $propal
	 *
	 * @return false|string
	 */
	public function getImagePropalDir(Propal $propal)
	{
		global $conf;
		if (isModEnabled('propal')) {
			return $conf->propal->multidir_output[$propal->entity] . '/' . get_exdir(0, 0, 0, 1, $propal, 'propal');
		} else {
			$this->setError('Module for Propal not enabled');
			return false;
		}
	}

	/**
	 * @param Product $product
	 * @param         $prestaProductId
	 * @param         $prestaIdImage
	 *
	 * @return bool
	 * TODO ADD CACHE MANAGEMENT FOR IMAGE
	 */
	public function importImageDolProduct(Product $product, $prestaProductId, $prestaIdImage, $forceReplaceImage = false)
	{
		global $conf;

		$this->clearErrors();

		$upload_dir = $this->getImageProductDir($product);
		if ($upload_dir === false) {
			return false;
		}

		$raw = $this->getProductImage($prestaProductId, $prestaIdImage);
		if (empty($raw)) {
			$this->setError('Empty file recieved');
			return false;
		}

		$mime = static::getMimeFromFileString($raw);
		$ext = static::getExtentionFromMime($mime);

		if ($ext === false) {
			$this->setError('Image [' . $ext . '] extention not supported');
		}

		$photoFileNameNoExt = 'photo-' . $prestaProductId . '-' . $prestaIdImage;
		$photoFileName = $photoFileNameNoExt . '.' . $ext;
		$finalFilePath = $upload_dir . '/' . $photoFileName;

		if (!file_exists($upload_dir) && 0 > dol_mkdir($upload_dir)) {
			$this->setError('Creating folder [' . $upload_dir . '] fail ');
			return false;
		}

		if (file_exists($finalFilePath)) {
			if (!$forceReplaceImage) {
				return true;
			}

			unlink($finalFilePath);
		}

		if (file_put_contents($finalFilePath, $raw) === false) {
			$this->setError('File save error for [' . $finalFilePath . ']');
			return false;
		}

		if ($mime == 'image/webp') {
			if (PrestaImage::webpToJpg($finalFilePath, $upload_dir . $photoFileNameNoExt . '.jpg')) {
				$this->setError('Webp to jpg image convertion fail for [' . $finalFilePath . ']');
				return false;
			}
		}

		if (is_file($finalFilePath)) {
			// create thumb image
			$product->addThumbs($finalFilePath);
		}

		return true;
	}

	/**
	 * @param Commande            $order
	 * @param OrderLine           $orderLine
	 * @param PrestaCustomization $customization
	 * @param stdClass            $customizedDataImageFields
	 *
	 * @return bool
	 */
	public function getImportImageCustomizationDolOrderLineFileBaseName(Commande $order, OrderLine $orderLine, PrestaCustomization $customization, $customizedDataImageFields)
	{
		$photoFileNameNoExt = $order->ref.'_line'.(int)$orderLine->id.'_c' . (int)$customization->id . '_f' . (int)$customizedDataImageFields->id_customization_field;
		if(!empty($orderLine->product_ref)){
			$photoFileNameNoExt.= '_'.$orderLine->product_ref;
		}
		return dol_sanitizeFileName($photoFileNameNoExt);
	}


	/**
	 * @param Propal              $propal
	 * @param PropaleLigne        $propaleLigne
	 * @param PrestaCustomization $customization
	 * @param stdClass            $customizedDataImageFields
	 *
	 * @return bool
	 */
	public function getImportImageCustomizationDolPropalLineFileBaseName(Propal $propal, PropaleLigne $propaleLigne, PrestaCustomization $customization, $customizedDataImageFields)
	{
		$photoFileNameNoExt = $propal->ref.'_line'.(int)$propaleLigne->id.'_c' . (int)$customization->id . '_f' . (int)$customizedDataImageFields->id_customization_field;
		if(!empty($propaleLigne->product_ref)){
			$photoFileNameNoExt.= '_'.$propaleLigne->product_ref;
		}
		return dol_sanitizeFileName($photoFileNameNoExt);
	}

	/**
	 * @param Commande            $order
	 * @param OrderLine           $orderLine
	 * @param PrestaCustomization $customization
	 * @param stdClass            $customizedDataImageFields
	 * @param bool                $forceReplaceImage
	 *
	 * @return bool
	 */
	public function importImageCustomizationDolOrderLine(Commande $order, OrderLine $orderLine, PrestaCustomization $customization, $customizedDataImageFields , $forceReplaceImage = false)
	{

		$this->clearErrors();

		$upload_dir = $this->getImageOrderDir($order);
		if ($upload_dir === false) {
			return false;
		}

		$raw = $this->getCustomizationImage($customization->id, $customizedDataImageFields->id_customization_field, $customization->id_cart);
		if (empty($raw)) {
			$this->setError('Empty file recieved');
			return false;
		}

		$mime = static::getMimeFromFileString($raw);
		$ext = static::getExtentionFromMime($mime);

		if ($ext === false) {
			$this->setError('Error getting image from shop');
			return false;
		}

		$photoFileNameNoExt = $this->getImportImageCustomizationDolOrderLineFileBaseName($order, $orderLine, $customization, $customizedDataImageFields);
		$photoFileName = $photoFileNameNoExt . '.' . $ext;
		$finalFilePath = $upload_dir . '/' . $photoFileName;

		if (!file_exists($upload_dir) && 0 > dol_mkdir($upload_dir)) {
			$this->setError('Creating folder [' . $upload_dir . '] fail ');
			return false;
		}

		if (file_exists($finalFilePath)) {
			if (!$forceReplaceImage) {
				return true;
			}

			unlink($finalFilePath);
		}

		if (file_put_contents($finalFilePath, $raw) === false) {
			$this->setError('File save error for [' . $finalFilePath . ']');
			return false;
		}

		if ($mime == 'image/webp') {
			if (PrestaImage::webpToJpg($finalFilePath, $upload_dir . $photoFileNameNoExt . '.jpg')) {
				$this->setError('Webp to jpg image convertion fail for [' . $finalFilePath . ']');
				return false;
			}
		}

		if (is_file($finalFilePath)) {
			// create thumb image
			$orderLine->addThumbs($finalFilePath);
		}

		return $photoFileName;
	}

	/**
	 * @param Propal              $propal
	 * @param PropaleLigne        $propaleLigne
	 * @param PrestaCustomization $customization
	 * @param stdClass            $customizedDataImageFields
	 * @param bool                $forceReplaceImage
	 *
	 * @return bool
	 */
	public function importImageCustomizationDolPropalLine(Propal $propal, PropaleLigne $propaleLigne, PrestaCustomization $customization, $customizedDataImageFields , $forceReplaceImage = false)
	{

		$this->clearErrors();

		$upload_dir = $this->getImagePropalDir($propal);
		if ($upload_dir === false) {
			return false;
		}

		$raw = $this->getCustomizationImage($customization->id, $customizedDataImageFields->id_customization_field, $customization->id_cart);
		if (empty($raw)) {
			$this->setError('Empty file recieved');
			return false;
		}

		$mime = static::getMimeFromFileString($raw);
		$ext = static::getExtentionFromMime($mime);

		if ($ext === false) {
			$this->setError('Error getting image from shop');
			return false;
		}

		$photoFileNameNoExt = $this->getImportImageCustomizationDolPropalLineFileBaseName($propal, $propaleLigne, $customization, $customizedDataImageFields);
		$photoFileName = $photoFileNameNoExt . '.' . $ext;
		$finalFilePath = $upload_dir . '/' . $photoFileName;

		if (!file_exists($upload_dir) && 0 > dol_mkdir($upload_dir)) {
			$this->setError('Creating folder [' . $upload_dir . '] fail ');
			return false;
		}

		if (file_exists($finalFilePath)) {
			if (!$forceReplaceImage) {
				return true;
			}

			unlink($finalFilePath);
		}

		if (file_put_contents($finalFilePath, $raw) === false) {
			$this->setError('File save error for [' . $finalFilePath . ']');
			return false;
		}

		if ($mime == 'image/webp') {
			if (PrestaImage::webpToJpg($finalFilePath, $upload_dir . $photoFileNameNoExt . '.jpg')) {
				$this->setError('Webp to jpg image convertion fail for [' . $finalFilePath . ']');
				return false;
			}
		}

		if (is_file($finalFilePath)) {
			// create thumb image
			$propaleLigne->addThumbs($finalFilePath);
		}

		return $photoFileName;
	}
}

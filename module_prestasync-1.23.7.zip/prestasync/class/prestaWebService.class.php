<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * This class is used to create API interface with Prestashop between versions
 * by giving more resiliance to Dolibarr and Prestashop changes...
 */

require_once __DIR__ . '/../vendor/autoload.php';

class PrestaWebservice extends PrestaShopWebservice
{

	public function getPrestaVersion(){
		if(!empty($this->version)){
			return $this->version;
		}
	}

	/**
	 * Retrieve (GET) a resource
	 * <p>Unique parameter must take : <br><br>
	 * 'url' => Full URL for a GET request of Webservice (ex: http://mystore.com/api/customers/1/)<br>
	 * OR<br>
	 * 'resource' => Resource name,<br>
	 * 'id' => ID of a resource you want to get<br><br>
	 * </p>
	 * <code>
	 * <?php
	 * require_once './PrestaShopWebservice.php';
	 * try
	 * {
	 * $ws = new PrestaShopWebservice('http://mystore.com/', 'ZQ88PRJX5VWQHCWE4EE7SQ7HPNX00RAJ', false);
	 * $xml = $ws->get(array('resource' => 'orders', 'id' => 1));
	 *    // Here in $xml, a SimpleXMLElement object you can parse
	 * foreach ($xml->children()->children() as $attName => $attValue)
	 *    echo $attName.' = '.$attValue.'<br>';
	 * }
	 * catch (PrestaShopWebserviceException $ex)
	 * {
	 *    echo 'Error : '.$ex->getMessage();
	 * }
	 * ?>
	 * </code>
	 *
	 * @param array $options Array representing resource to get.
	 *
	 * @return    SimpleXMLElement|boolean    status_code, response
	 * @throw PrestaShopWebserviceException
	 */
	public function getJson($options)
	{
		$options['output_format'] = 'JSON';

		if (isset($options['resource'])) {
			$url = $this->url . '/api/' . $options['resource'];
			$url_params = [];
			if (isset($options['id'])) {
				$url .= '/' . $options['id'];
			}

			// @CHANGE LDR
			//$params = array('filter', 'display', 'sort', 'limit', 'id_shop', 'id_group_shop');
			$params = ['filter', 'display', 'sort', 'limit', 'id_shop', 'id_group_shop', 'date', 'output_format'];
			foreach ($params as $p) {
				foreach ($options as $k => $o) {
					if (strpos($k, $p) !== false) {
						$url_params[$k] = $options[$k];
					}
				}
			}
			if (count($url_params) > 0) {
				$url .= '?' . http_build_query($url_params);
			}
		} else {
			throw new PrestaShopWebserviceException('Bad parameters given ');
		}

		$request = $this->executeRequest($url, [CURLOPT_CUSTOMREQUEST => 'GET']);
		$this->checkStatusCodeJson($request); // check the response validity

		return json_decode($request['response']);
	}

	/**
	 * Take the status code and throw an exception if the server didn't return 200 or 201 code
	 * <p>Unique parameter must take : <br><br>
	 * 'status_code' => Status code of an HTTP return<br>
	 * 'response' => CURL response
	 * </p>
	 *
	 * @param array $request Response elements of CURL request
	 *
	 * @throws PrestaShopWebserviceException if HTTP status code is not 200 or 201
	 */
	protected function checkStatusCodeJson($request)
	{
		$this->checkStatusCodeRequest($request);

		$response = json_decode($request['response']);
		if ($response && json_last_error() !== JSON_ERROR_NONE) {
			switch (json_last_error()) {
				case JSON_ERROR_NONE:
					$error_message = ' - No errors';
					break;
				case JSON_ERROR_DEPTH:
					$error_message = ' - Maximum stack depth exceeded';
					break;
				case JSON_ERROR_STATE_MISMATCH:
					$error_message = ' - Underflow or the modes mismatch';
					break;
				case JSON_ERROR_CTRL_CHAR:
					$error_message = ' - Unexpected control character found';
					break;
				case JSON_ERROR_SYNTAX:
					$error_message = ' - Syntax error, malformed JSON';
					break;
				case JSON_ERROR_UTF8:
					$error_message = ' - Malformed UTF-8 characters, possibly incorrectly encoded';
					break;
				default:
					$error_message = ' - Unknown error';
					break;
			}
		}

		if (!empty($error_message)) {
			$error_label = 'XWS : This call to PrestaShop Web Services failed and returned an HTTP status of %d. That means: %s.';
			throw new PrestaShopWebserviceException(sprintf($error_label, $request['status_code'], $error_message));
		}
	}

	/**
	 * Take the status code and throw an exception if the server didn't return 200 or 201 code
	 * <p>Unique parameter must take : <br><br>
	 * 'status_code' => Status code of an HTTP return<br>
	 * 'response' => CURL response
	 * </p>
	 *
	 * @param array $request Response elements of CURL request
	 *
	 * @throws PrestaShopWebserviceException if HTTP status code is not 200 or 201
	 */
	protected function checkStatusCodeRequest($request)
	{
		$error_message = '';
		switch ($request['status_code']) {
			case 200:
			case 201:
				break;
			case 204:
				$error_message = 'No content';
				break;
			case 400:
				$error_message = 'Bad Request';
				break;
			case 401:
				$error_message = 'Unauthorized';
				break;
			case 404:
				$error_message = 'Not Found';
				break;
			case 405:
				$error_message = 'Method Not Allowed';
				break;
			case 500:
				$error_message = 'Internal Server Error';
				break;
			default:
				throw new PrestaShopWebserviceException(
					'This call to PrestaShop Web Services returned an unexpected HTTP status of:' . $request['status_code']
				);
		}

		$response = json_decode($request['response']);
		if ($response && json_last_error() === JSON_ERROR_NONE && isset($response->errors) && is_array($response->errors)) {
			foreach ($response->errors as $erro){
				if(!empty($erro->message)) {
					$error_message.= ' - '.$erro->message;
				}
			}
		}

		if (!empty($error_message)) {
			$error_label = 'XBF : This call to PrestaShop Web Services failed and returned an HTTP status of %d. That means: %s.';
			throw new PrestaShopWebserviceException(sprintf($error_label, $request['status_code'], $error_message));
		}
	}

	/**
	 * Retrieve (GET) a resource
	 * $options    Array representing resource to get.
	 *
	 * @return    SimpleXMLElement|boolean    status_code, response
	 * @throw PrestaShopWebserviceException
	 */
	public function getFile($options)
	{
		if (isset($options['resource'])) {
			$url = $this->url . '/api/' . $options['resource'];
			if (isset($options['id'])) {
				$url .= '/' . $options['id'];
			}
		} else {
			throw new PrestaShopWebserviceException('Bad parameters given ');
		}

		$request = $this->executeRequest($url, [CURLOPT_CUSTOMREQUEST => 'GET']);
		$headers = $this->extractHeaderParamFromString($request['header']);

		$this->checkStatusCodeRequest($request); // check the response validity
		return $request['response'];
	}

	public function extractHeaderParamFromString($string)
	{
		$array = preg_split("/\r\n|\n|\r/", $string);
		if (!is_array($array)) {
			return false;
		}

		$headers = [];
		foreach ($array as $line) {
			$split = explode(':', $line, 2);
			if (count($split) > 1) {
				$headers[trim($split[0])] = trim($split[1]);
			}
		}

		return $headers;
	}
}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaProductCustomizationField extends PrestaCommonObject
{

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'product_customization_fields';

	public $fields = [
		'id' => [],
		'id_product' => [],
		'type' => [],
		'required' => [],
		'is_module' => [],
		'is_deleted' => [],
		'name' => [
			'langs' => true,
		],
		'associations' => [],
	];

	public $id;
	public $id_product;
	public $type;
	public $required;
	public $is_module;
	public $is_deleted;
	public $name;

	public $associations;

	public function fetchAllFromProductId($id_product, $useCache = true)
	{
		return $this->fetchAll([], [], ['id_product' => $id_product], 0, 0, [], $useCache, 300);
	}

	/**
	 * @param array $fields
	 * @param array $sort
	 * @param array $filters
	 *                    [
	 *                    'operator' => the query operator : or | interval | begin | end | contains | literal
	 *                    'search' => the value to search
	 *                    ]
	 * @param int   $limit
	 * @param int   $page
	 * @param array $opt
	 * @param bool  $useCache
	 * @param int   $cacheExpire
	 *
	 * @return static[]|false
	 */
	public function fetchAll($fields = [], $sort = [], $filters = [], $limit = 0, $page = 0, $opt = [], $useCache = true, $cacheExpire = 600)
	{
		if (!empty($fields) && $fields != 'full' && !in_array('id', $fields)) {
			$fields[] = 'id';
		}

		$resources = $this->presta->getFromWebService($this->resource, $fields, $sort, $filters, $limit, $page, $opt, $useCache, $cacheExpire);
		if (!$resources) {
			$this->setError($this->presta->error);
			return false;
		}

		$out = [];

		foreach ($resources->customization_fields as $resource) {
			$obj = new static($this->presta);
			$obj->populate($resource);
			$out[$obj->id] = $obj;
		}
		return $out;
	}
}

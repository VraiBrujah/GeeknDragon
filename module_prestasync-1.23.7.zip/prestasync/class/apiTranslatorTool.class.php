<?php
namespace prestasync;

class ApiTranslatorTool
{

	/**
	 * @param $string
	 *
	 * @return false|int
	 */
	public static function isLangCodeName($string)
	{
		return preg_match('/^[a-z]{1,2}[_\-][A-Z]{1,2}$/', $string);
	}

	/**
	 * @param $langCode
	 * @param int<0,1>	$notitlealt	No title alt
	 *
	 * @return mixed|string
	 */
	public static function getFlag($langCode, $notitlealt = 0)
	{
		return picto_from_langcode(self::prestaToDolLangCode($langCode), 'class="saturatemedium"',$notitlealt);
	}

	/**
	 * @param $langCode
	 *
	 * @return mixed|string
	 */
	public static function prestaToDolLangCode($langCode)
	{
		return str_replace('-', '_', $langCode);
	}



	/**
	 * @param $langCode
	 *
	 * @return mixed|string
	 */
	public static function getCountryCode($langCode)
	{
		if (!static::isLangCodeName($langCode)) {
			return false;
		}

		$langCodeArr = explode('_',self::prestaToDolLangCode($langCode));
		return strtolower(end($langCodeArr));
	}

	/**
	 * @param $langCode
	 *
	 * @return mixed|string
	 */
	public static function getLangCode($langCode)
	{
		if (!static::isLangCodeName($langCode)) {
			return false;
		}

		$langCodeArr = explode('_', self::prestaToDolLangCode($langCode));
		return strtolower(reset($langCodeArr));
	}
}

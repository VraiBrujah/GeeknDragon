<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaTax extends PrestaCommonObject
{
	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'taxes';

	public $fields = [
		'id' => [],
		'rate' => [],
		'active' => [],
		'deleted' => [],
		'name' => [],
	];

	public $id;
	public $rate;
	public $active;
	public $deleted;
	public $name;

	/**
	 * @param $id_tax_rules_group
	 * @param $id_country
	 * @param $id_state
	 * @param $cache
	 *
	 * @return bool
	 */
	public function fetchTaxFromRuleGroup($id_tax_rules_group, $id_country, $id_state = 0, $cache = true)
	{
		require_once __DIR__ . '/prestaTaxRule.class.php';

		$prestaTaxRule = new PrestaTaxRule($this->presta);
		$prestaTaxRules = $prestaTaxRule->fetchAll([], [], ['id_tax_rules_group' => $id_tax_rules_group, 'id_state' => $id_state, 'id_country' => $id_country], 1, 0, [], $cache);
		if ($prestaTaxRules) {
			$taxRule = reset($prestaTaxRules);
			if ($taxRule) {
				return $this->fetch($taxRule->id_tax);
			}
		}

		return false;
	}
}

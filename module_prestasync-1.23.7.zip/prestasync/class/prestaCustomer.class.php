<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';

class PrestaCustomer extends PrestaCommonObject
{

	use PrestaCustomLinkInfo;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'customers';

	public $fields = [
		'id' => [
			'labelKey' => 'PrestaShopId',
		],
		'lastname' => [
			'labelKey' => 'Lastname',
		],
		'firstname' => [
			'labelKey' => 'Firstname',
		],

		'id_default_group' => [],
		'id_lang' => [],
		'newsletter_date_add' => [],
		'ip_registration_newslette' => [],
		'last_passwd_gen' => [],
		'secure_key' => [],
		'deleted' => [],
		'passwd' => [],
		'lastname' => [],
		'firstname' => [],
		'email' => [],
		'id_gender' => [],
		'birthday' => [],
		'newsletter' => [],
		'optin' => [],
		'websit' => [],
		'company' => [],
		'siret' => [],
		'ape' => [],
		'outstanding_allow_amount' => [],
		'show_public_prices' => [],
		'id_risk' => [],
		'max_payment_days' => [],
		'active' => [],
		'note' => [],
		'is_guest' => [],
		'id_shop' => [],
		'id_shop_group' => [],
		'date_add' => [],
		'date_upd' => [],
		'reset_password_token' => [],
		'reset_password_validity' => [],
		'associations' => [],
		'groups' => [],
	];

	public $id;
	public $id_default_group;
	public $id_lang;
	public $newsletter_date_add;
	public $ip_registration_newslette;
	public $last_passwd_gen;
	public $secure_key;
	public $deleted;
	public $passwd;
	public $lastname;
	public $firstname;
	public $email;
	public $id_gender;
	public $birthday;
	public $newsletter;
	public $optin;
	public $websit;
	public $company;
	public $siret;
	public $ape;
	public $outstanding_allow_amount;
	public $show_public_prices;
	public $id_risk;
	public $max_payment_days;
	public $active;
	public $note;
	public $is_guest;
	public $id_shop;
	public $id_shop_group;
	public $date_add;
	public $date_upd;
	public $reset_password_token;
	public $reset_password_validity;
	public $associations;
	public $groups;

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'societe';

	/**
	 * the Dolibarr linked object
	 *
	 * @var Societe $doliObject ;
	 */
	public $doliObject;

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_customer';
		$this->linkTableDoliCol = 'fk_soc_doli';
		$this->linkTablePrestaCol = 'fk_customer_presta';

		return parent::__construct($presta);
	}

	public function getFullName()
	{
		$out = '';

		if (!empty($this->company)) {
			$out .= $this->company . ' ';
		}

		$out .= ucfirst($this->firstname) . ' ' . strtoupper($this->lastname);

		return $out;
	}

	/**
	 * @param User          $user
	 * @param PrestaAddress|false $prestaAdress
	 *
	 * @return int|void
	 */
	public function syncToDolibarr($user, $prestaAdress, $update = false)
	{
		// TODO : add update mod
		// skip if already sync
		if (!empty($this->linkObject)) {
			$this->fetchDolibarrObject();

			if($update) {
				if (!empty($this->company)) {
					$this->doliObject->name = $this->company;
					$this->doliObject->name_alias = $this->getFullName();
				} else {
					$this->doliObject->name = ucfirst($this->firstname) . ' ' . strtoupper($this->lastname);
				}

				$this->doliObject->idprof2 = $this->siret;
				$this->doliObject->idprof3 = $this->ape;

				$this->doliObject->email = $this->email;
				if($prestaAdress){
					$this->doliObject->phone = !empty($prestaAdress->phone) ? $prestaAdress->phone : $prestaAdress->phone_mobile;

					require_once __DIR__ . '/prestaCountries.class.php';
					$prestaCountry = new PrestaCountries($this->presta);
					if (!$prestaCountry->fetch($prestaAdress->id_country)) {
						$this->setError('unable to fetch prestashop country');
						return false;
					}

					$c_country = $prestaCountry->getDolibarrCountry('', $prestaCountry->iso_code);
					if (!$c_country) {
						$this->setError('unable to find dolibarr country');
						return false;
					}

					$this->doliObject->country_id = $c_country->id;
					$this->doliObject->country_code = $c_country->code;

					$this->doliObject->address = $prestaAdress->getAddress(false, "\n");
					$this->doliObject->zip = $prestaAdress->postcode;
					$this->doliObject->town = $prestaAdress->city;
				}

				$this->doliObject->particulier = empty($this->company) ? 1 : 0;

				$resUpdate = $this->doliObject->update($this->doliObject->id, $user);
				if ($resUpdate < 0) {
					$this->setError($this->doliObject->errorsToString());
					return false;
				}
			}


			return true;
		}

		// Check if synced
		$this->getDolLinkInfo();

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		/* ***************
		 * ** IMPORTANT **
		 * ***************
		 *
		 * Il n'y a pas de recheche de société en dehors de celle déjà syncronisée
		 * TODO voir pour permettre de lier manuellement si besoin avec société existance
		 * Ce choix est fait par sécurité car on ne peut pas faire confiance à ce qui vient d'internet
		 * C'est important car comment être sur que la personne est bien légitime et n'a pas juste récupéré des infos sur internet
		 * car vu que la liason entre presta et Dolibarr pourrais permettre de récupérer les factures
		 * alors il faut faire attention que cette récupération soit limité mais ce n'est pas le cas actuellement.
		 */

		require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
		$this->doliObject = new Societe($this->presta->db);
		$this->doliObject->code_client = 'auto';
		$this->doliObject->client = 1;
		$this->doliObject->typent_id = 0; // TODO create mapping in prestashop object
		$this->doliObject->effectif_id = 0; // TODO create mapping in prestashop object
		$this->doliObject->forme_juridique_code = 0; // TODO create mapping in prestashop object

		$this->doliObject->tva_assuj = 1; // TODO VERIFIER SI ASSUGETI TVA
		$this->doliObject->status = 1;

		if (!empty($this->company)) {
			$this->doliObject->name = $this->company;
			$this->doliObject->name_alias = $this->getFullName();
		} else {
			$this->doliObject->name = ucfirst($this->firstname) . ' ' . strtoupper($this->lastname);
		}

		$this->doliObject->idprof2 = $this->siret;
		$this->doliObject->idprof3 = $this->ape;

		$this->doliObject->email = $this->email;
		if($prestaAdress){
			$this->doliObject->phone = !empty($prestaAdress->phone) ? $prestaAdress->phone : $prestaAdress->phone_mobile;

			require_once __DIR__ . '/prestaCountries.class.php';
			$prestaCountry = new PrestaCountries($this->presta);
			if (!$prestaCountry->fetch($prestaAdress->id_country)) {
				$this->setError('unable to fetch prestashop country');
				return false;
			}

			$c_country = $prestaCountry->getDolibarrCountry('', $prestaCountry->iso_code);
			if (!$c_country) {
				$this->setError('unable to find dolibarr country');
				return false;
			}

			$this->doliObject->country_id = $c_country->id;
			$this->doliObject->country_code = $c_country->code;

			$this->doliObject->address = $prestaAdress->getAddress(false, "\n");
			$this->doliObject->zip = $prestaAdress->postcode;
			$this->doliObject->town = $prestaAdress->city;
		}

		$this->doliObject->particulier = empty($this->company) ? 1 : 0;

		$this->presta->db->begin();
		$resCreate = $this->doliObject->create($user);
		if ($resCreate < 0) {
			$this->setError($this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		// Create link
		$this->doliElementId = $this->doliObject->id;
		if (!$this->setDolLink()) {
			$this->presta->db->rollback();
			return false;
		}

		$this->presta->db->commit();
		return true;
	}

}

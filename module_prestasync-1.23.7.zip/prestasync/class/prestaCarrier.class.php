<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';

class PrestaCarrier extends PrestaCommonObject
{
	use PrestaCustomLinkInfo;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'carriers';

	public $fields = [
		'id' => [],
		'deleted' => [],
		'is_module' => [],
		'id_tax_rules_group' => [],
		'id_reference' => [],
		'name' => [],
		'active' => [],
		'is_free' => [],
		'url' => [],
		'shipping_handling' => [],
		'shipping_external' => [],
		'range_behavior' => [],
		'shipping_method' => [],
		'max_width' => [],
		'max_height' => [],
		'max_depth' => [],
		'max_weight' => [],
		'grade' => [],
		'external_module_name' => [],
		'need_range' => [],
		'position' => [],
		'delay' => [],
	];

	public $id;
	public $deleted;
	public $is_module;
	public $id_tax_rules_group;
	public $id_reference;
	public $name;
	public $active;
	public $is_free;
	public $url;
	public $shipping_handling;
	public $shipping_external;
	public $range_behavior;
	public $shipping_method;
	public $max_width;
	public $max_height;
	public $max_depth;
	public $max_weight;
	public $grade;
	public $external_module_name;
	public $need_range;
	public $position;
	public $delay;

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_carrier';
		$this->linkTableDoliCol = 'fk_shipment_mode';
		$this->linkTablePrestaCol = 'fk_carrier_presta';

		return parent::__construct($presta);
	}

	/**
	 * @param User $user
	 *
	 * @return false|int|void
	 */
	public function syncToDolibarr($user, $notrigger = 0)
	{
		global $conf;

		// Check if synced
		$this->getDolLinkInfo();

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		require_once __DIR__ . '/mappingcarrier.class.php';
		$this->doliObject = new MappingCarrier($this->presta->db);
		$this->doliObject->fk_presta = $this->presta->id;
		$this->doliObject->fk_carrier_presta = $this->id;
		$this->doliObject->status = MappingCarrier::STATUS_DRAFT;

		$this->doliObject->fk_shipment_mode = !empty($conf->global->PRESTASYNC_SHIPPING_DEFAULT_MODE) ? intval($conf->global->PRESTASYNC_SHIPPING_DEFAULT_MODE) : null;

		$this->doliObject->db->begin();
		$resCreate = $this->doliObject->create($user);
		if ($resCreate <= 0) {
			$this->setError($this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		$this->doliObject->db->commit();
		return $resCreate;
	}

	/**
	 * Forge an set tracking url
	 *
	 * @param string $value Value
	 *
	 * @return    false|string
	 */
	function getDolibarrUrlTracking($value = '')
	{
		// Check if synced
		if (empty($this->linkObject)) {
			$this->getDolLinkInfo();
		}

		// skip if already sync
		if (empty($this->linkObject)) {
			return false;
		}

		if (empty($this->linkObject->fk_shipment_mode)) {
			return null;
		}

		$sql = "SELECT em.code, em.tracking";
		$sql .= " FROM " . MAIN_DB_PREFIX . "c_shipment_mode as em";
		$sql .= " WHERE em.rowid = " . $this->linkObject->fk_shipment_mode;
		$obj = $this->presta->db->getRow($sql);

		if (!empty($obj) && !empty($value)) {
			return str_replace('{TRACKID}', $value, $obj->tracking);
		}

		return false;
	}
}

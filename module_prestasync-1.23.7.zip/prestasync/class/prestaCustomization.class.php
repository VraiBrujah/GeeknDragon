<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaCustomization extends PrestaCommonObject
{

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'customizations';

	public $fields = [
		'id' => [],
		'id_address_delivery' => [],
		'id_cart' => [],
		'id_product' => [],
		'id_product_attribute' => [],
		'quantity' => [],
		'quantity_refunded' => [],
		'quantity_returned' => [],
		'in_cart' => [],
		'associations' => [
			'subObjectMapping' => [
				'customized_data_text_fields' => [
					// "id_customization_field": int,
					// "value": "Text string"
				],
				'customized_data_images' => [
					// "id_customization_field": int,
					// "value": "ca405d1469d7c6368115dbfd0806197c"
				],
			],
		],
	];

	public $id;
	public $id_address_delivery;
	public $id_cart;
	public $id_product;
	public $id_product_attribute;
	public $quantity;
	public $quantity_refunded;
	public $quantity_returned;
	public $in_cart;

	public $associations;

	public function fetchAllFromCartId($id_cart, $useCache = true)
	{
		return $this->fetchAll([], [], ['id_cart' => $id_cart], 0, 0, [], $useCache, 20);
	}
}

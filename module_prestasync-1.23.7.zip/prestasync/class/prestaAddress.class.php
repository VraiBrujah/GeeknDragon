<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';
require_once __DIR__ . '/prestaCountries.class.php';

class PrestaAddress extends PrestaCommonObject
{

	use PrestaCustomLinkInfo;

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string|false (use false if this prestahop resourse is not
	 */
	public $doliElement = 'contact';

	/**
	 * the Dolibarr linked object
	 *
	 * @var Contact $doliObject ;
	 */
	public $doliObject;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'addresses';

	public $fields = [
		'id' => [],
		'id_customer' => [],
		'id_manufacturer' => [],
		'id_supplier' => [],
		'id_warehouse' => [],
		'id_country' => [],
		'id_state' => [],
		'alias' => [],
		'company' => [],
		'lastname' => [],
		'firstname' => [],
		'vat_number' => [],
		'address1' => [],
		'address2' => [],
		'postcode' => [],
		'city' => [],
		'other' => [],
		'phone' => [],
		'phone_mobile' => [],
		'dni' => [],
		'deleted' => [],
		'date_add' => [],
		'date_upd' => [],
	];

	public $id;
	public $id_customer;
	public $id_manufacturer;
	public $id_supplier;
	public $id_warehouse;
	public $id_country;
	public $id_state;
	public $alias;
	public $company;
	public $lastname;
	public $firstname;
	public $vat_number;
	public $address1;
	public $address2;
	public $postcode;
	public $city;
	public $other;
	public $phone;
	public $phone_mobile;
	public $dni;
	public $deleted;
	public $date_add;
	public $date_upd;

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_address';
		$this->linkTableDoliCol = 'fk_socpeople_doli';
		$this->linkTablePrestaCol = 'fk_address_presta';

		return parent::__construct($presta);
	}

	public function getFullName()
	{
		$out = '';

		if (!empty($this->company)) {
			$out .= $this->company . ' ';
		}

		$out .= ucfirst($this->firstname) . ' ' . strtoupper($this->lastname);

		return $out;
	}

	/**
	 * @return string
	 */
	public function getFullAddress($lineBreak = '<br/>')
	{
		$out = $this->getFullName();
		$out .= $lineBreak . $this->getAddress();
		return $out;
	}

	/**
	 * @return string
	 */
	public function getAddress($includeZip = true, $lineBreak = '<br/>')
	{
		$out = '';
		if (!empty($this->address1)) {
			$out .= !empty($out) ? $lineBreak : '';
			$out .= $this->address1;
		}
		if (!empty($this->address2)) {
			$out .= !empty($out) ? $lineBreak : '';
			$out .= $this->address2;
		}

		if ($includeZip) {
			$out .= !empty($out) ? $lineBreak : '';
			$out .= $this->postcode;
			$out .= ' ' . $this->city;
		}

		return $out;
	}

	/**
	 * @param User $user
	 *
	 * @return int|void
	 */
	public function syncToDolibarr($user, $fk_soc)
	{
		// TODO : add update mod

		// skip if already sync
		if (!empty($this->linkObject)) {
			$this->fetchDolibarrObject();
			return true;
		}

		// Check if synced
		$this->getDolLinkInfo();

		// skip if already sync
		if (!empty($this->linkObject)) {
			$this->fetchDolibarrObject();
			return true;
		}

		require_once DOL_DOCUMENT_ROOT . '/contact/class/contact.class.php';
		$this->doliObject = new Contact($this->presta->db);

//		$this->doliObject->civility = ; // TODO Civility mapping

		$this->doliObject->firstname = ucfirst($this->firstname);
		$this->doliObject->lastname = strtoupper($this->lastname);
		$this->doliObject->address = $this->address1;
		if (!empty($this->address2)) {
			$this->doliObject->address .= (!empty($this->doliObject->address) ? ' ' : '') . $this->address2;
		}

		$this->doliObject->zip = $this->postcode;
		$this->doliObject->town = $this->city;
		$this->doliObject->socid = $fk_soc;
		$this->doliObject->phone_mobile = $this->phone_mobile;
		$this->doliObject->phone_pro = $this->phone;
		$this->doliObject->statut = 1;

		require_once __DIR__ . '/prestaCountries.class.php';
		$prestaCountry = new PrestaCountries($this->presta);
		if (!$prestaCountry->fetch($this->id_country)) {
			$this->setError('unable to fetch prestashop country');
			return false;
		}

		$c_country = $prestaCountry->getDolibarrCountry(0, $prestaCountry->iso_code);
		if (!$c_country) {
			$this->setError('unable to find dolibarr country');
			return false;
		}

		$this->doliObject->country_id = $c_country->id;
		$this->doliObject->country_code = $c_country->code;

		// TODO create a better departement mapping, currently only usable for france
		$c_departement = $this->getDolibarrDepartement(substr($this->postcode, 0, 2), $c_country->id);
		// No error management because work only for france
		if ($c_departement) {
			$this->doliObject->fk_departement = $c_departement->id;
		}

		$this->presta->db->begin();
		$resCreate = $this->doliObject->create($user);

		if ($resCreate < 0) {
			$this->setError($this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		// Create link
		$this->doliElementId = $this->doliObject->id;
		if (!$this->setDolLink()) {
			$this->presta->db->rollback();
			return false;
		}

		$this->presta->db->commit();
		return true;
	}

	public function getDolibarrDepartement($code_post, $fk_pays)
	{
		if (empty($id) && empty($code_iso)) {
			return false;
		}

		$sql = 'SELECT dep.rowid id, dep.code_iso, dep.label FROM ' . $this->presta->db->prefix() . 'c_departements dep ';
		$sql .= ' JOIN ' . $this->presta->db->prefix() . 'c_regions reg ON (reg.code_region = dep.fk_region) ';
		$sql .= ' dep.code_departement = \'' . $this->presta->db->escape($code_post) . '\' ';
		$sql .= ' AND reg.fk_pays = ' . intval($fk_pays);

		return $this->presta->db->getRow($sql);
	}

}

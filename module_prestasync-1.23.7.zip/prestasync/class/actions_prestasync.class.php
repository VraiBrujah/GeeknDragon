<?php
/* Copyright (C) 2024 John BOTELLA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * Class Actionsthersane
 */
class ActionsPrestasync
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;
	/**
	 * @var string Error
	 */
	public $error = '';
	/**
	 * @var array Errors
	 */
	public $errors = [];

	/**
	 * @var array Hook results. Propagated to $hookmanager->resArray for later reuse
	 */
	public $results = [];

	/**
	 * @var string String displayed by executeHook() immediately after return
	 */
	public $resprints;

	/**
	 * Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * @param $parameters
	 * @param $object CommonObject
	 * @param $action
	 * @param $hookmanager
	 */
	public function formObjectOptions($parameters, &$object, &$action, $hookmanager)
	{
		global $user, $conf, $langs, $form, $db;

		$context = explode(':', $parameters['context']);

		if (in_array('ordercard', $context)) {
			if (!array_key_exists('colspan', $parameters)) {
				$parameters['colspan'] = '';
			}

			require_once __DIR__ . '/prestaOrder.class.php';
			$prestaOrder = PrestaOrder::loadFromDolObject($object);
			if ($prestaOrder) {
				/** @var Commande $object */
				$row = '<tr>';
				$row .= '	<td>' . $langs->trans('PrestaShop') . '</td>';
				$row .= '	<td ' . $parameters['colspan'] . '>';

				if ($prestaOrder->getLinkStatus() != $prestaOrder::STATUS_LINKED) {
					$row .= $prestaOrder->getStatusBadge();
				} else {
					$cardUrl = dol_buildpath('prestasync/presta_order.php', 1) . '?presta_id=' . $prestaOrder->id . '&amp;id=' . $prestaOrder->presta->id;
					$row .= img_object('', $prestaOrder->presta->picto, 'class="paddingright" style="vertical-align:middle;"') . '<a href="' . $cardUrl . '" >' . $prestaOrder->getPrestaOrderStatusBadge() . '</a>';
				}

				$urlPresta = $prestaOrder->presta->getPrestaAdminUrl('order', ['id' => $prestaOrder->id]);
//				$row.= ' <a target="_blank" href="'.$urlPresta.'" title="'.$langs->trans('GoPrestaShop').'" ><i class="fa fa-link"></i></a>';

				require_once __DIR__ . '/prestaOrderCarrier.class.php';
				require_once __DIR__ . '/prestaCarrier.class.php';
				$carrierStatic = new PrestaOrderCarrier($prestaOrder->presta);
				$carriers = $carrierStatic->fetchAllFromOrderId($prestaOrder->id);
				if ($carriers) {
					foreach ($carriers as $carrier) {
						if (!empty($carrier->tracking_number)) {
							$prestaCarrier = new PrestaCarrier($carrier->presta);
							if ($prestaCarrier->fetch($carrier->id_carrier)) {
								$trackUrl = $prestaCarrier->getDolibarrUrlTracking($carrier->tracking_number);
								if ($trackUrl !== false) {
									$row .= ' <a href="' . $trackUrl . '" class="classfortooltip" target="_blank" title="' . dol_htmlentities($langs->trans('TrackingNumber') . ' : ' . $carrier->tracking_number) . '"><i class="fa fa-truck"></i> ' . $prestaCarrier->name . '</a>';
								}
							}
						}
					}
				}

				$row .= '	</td>';
				$row .= '</tr>';

				print $row;
			}

			$jsConf = [
				'imgPreviewUrl' => dol_buildpath('document.php',1).'?modulepart=commande&entity='.$object->entity,
				'orderRef' => $object->ref
			]
?>
				<script nonce="<?php print getNonce(); ?>" >
				$(function() {
					let conf = <?php print json_encode($jsConf); ?>;
					$('span.prestasync-line-customization-photo-lazy-link').each(function (){
						let dataFile = $(this).attr('data-file');
						if(dataFile !== undefined){
							let DlUrl = conf.imgPreviewUrl + '&file=' + encodeURI(conf.orderRef + '/' + dataFile);
							let viewUrl = DlUrl + '&attachment=0';

							let ext = dataFile.split('.').pop();
							let mime = false;
							if(ext == 'jpeg' || ext == 'jpg') {
								mime = 'image/jpeg'
							}else if(ext == 'pdf') {
								mime = 'application/pdf'
							}else if(ext == 'png') {
								mime = 'image/png'
							}

							let newLink = `<a href="${DlUrl}" target="_blank" >${dataFile}</a>`;
							if(mime){
								newLink = newLink + ` <a class="pictopreview documentpreview" mime="${mime}" href="${viewUrl}" ><span class="fa fa-search-plus pictofixedwidth" style="color: gray"></span></a>`;
							}

							$(this).replaceWith($( newLink ));
						}
					})
				});
				</script>
<?php

		}

		if (in_array('productcard', $context)) {
			if (!array_key_exists('colspan', $parameters)) {
				$parameters['colspan'] = '';
			}

			require_once __DIR__ . '/prestaProduct.class.php';
			$prestaProductsLinks = PrestaProduct::getAllPrestaLinksInfos($object);
			if ($prestaProductsLinks) {
				/** @var Product $object */
				$row = '<tr>';
				$row .= '	<td>' . $langs->trans('PrestaShop') . '</td>';
				$row .= '	<td ' . $parameters['colspan'] . '>';

				require_once __DIR__ . '/presta.class.php';
				foreach ($prestaProductsLinks as $prestaProductLink) {
					$presta = new Presta($object->db);
					if ($presta->fetch($prestaProductLink->fk_presta)) {
						$cardUrl = dol_buildpath('prestasync/presta_product.php', 1) . '?id=' . $presta->id . '&amp;presta_id=' . $prestaProductLink->fk_product_presta;

						if (!empty($prestaProductLink->fk_product_presta_attribute)) {
							$cardUrl .= '&amp;showmeattribute=' . intval($prestaProductLink->fk_product_presta_attribute);
							$cardUrl .= '#attribute-row-' . intval($prestaProductLink->fk_product_presta_attribute);
						}

						$row .= img_object('', $presta->picto, 'class="paddingright" style="vertical-align:middle;"') . '<a href="' . $cardUrl . '" >' . $presta->label . '</a>';
					}
				}

				$row .= '	</td>';
				$row .= '</tr>';

				print $row;
			}
		}
	}

	/**
	 * @param $parameters
	 * @param $object CommonObject
	 * @param $action
	 * @param $hookmanager
	 */
	public function printFieldPreListTitle($parameters, &$object, &$action, $hookmanager)
	{
		$context = explode(':', $parameters['context']);
		if (in_array('importfournprice_supplierpricelist_missing', $context)) {
			$this->resprints = '<td></td>';
		}
	}

	/**
	 * @param $parameters
	 * @param $object CommonObject
	 * @param $action
	 * @param $hookmanager
	 */
	public function printFieldListTitle($parameters, &$object, &$action, $hookmanager)
	{
		$context = explode(':', $parameters['context']);

		if (in_array('importfournprice_supplierpricelist_missing', $context)) {
			print_liste_field_titre("PrestaSync", $_SERVER["PHP_SELF"], "", $parameters['param'] ?? [], "", '', $parameters['sortfield'] ?? '', $parameters['sortorder'] ?? '', 'right ');
		}
	}

	/**
	 * @param $parameters
	 * @param $object CommonObject
	 * @param $action
	 * @param $hookmanager
	 */
	public function printFieldListValue($parameters, &$object, &$action, $hookmanager)
	{
		global $db;

		$context = explode(':', $parameters['context']);
		if (in_array('importfournprice_supplierpricelist_missing', $context)) {
			$this->resprints .= '<td class="center">';

			include_once __DIR__ . '/prestaProduct.class.php';
			$prestaProdLinks = PrestaProduct::getAllDolProductLinks($object->rowid);
			if (!empty($prestaProdLinks)) {
				$i = 0;
				foreach ($prestaProdLinks as $prestaProdLink) {
					$i++;
					$presta = new Presta($db);
					if ($presta->fetch($prestaProdLink->fk_presta) > 0) {
						$url = dol_buildpath('prestasync/presta_product.php', 1) . '?id=' . $prestaProdLink->fk_presta . '&presta_id=' . $prestaProdLink->fk_product_presta;
						$picto = img_object('', $presta->picto ? $presta->picto : 'generic', 'class="paddingright"');

						if ($i > 1) {
							$this->resprints .= ', ';
						}
						$this->resprints .= '<a class="nowraponall" href="' . $url . '" >' . $picto . $presta->label . '</a>';
					}

					if ($i > 4) {
						break;
					}
				}

				if (count($prestaProdLinks) > 4) {
					$this->resprints .= '...';
				}
			}

			$this->resprints .= '</td>';
		}
	}
}

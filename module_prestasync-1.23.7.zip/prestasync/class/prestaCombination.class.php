<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaProductOptionValue.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

class PrestaCombination extends PrestaCommonObject
{

	public string $linkTable;
	public string $linkTableDoliCol;
	public string $linkTablePrestaCol;
	public string $linkTablePrestaAttributeCol;

	/**
	 * the Dolibarr linked object
	 *
	 * @var Product $doliObject ;
	 */
	public $doliObject;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'combinations';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'product';

	/**
	 * @var PrestaProductOptionValue[] $optionsValues
	 */
	public $optionsValues;

	public $fields = [
		'id' => [],
		'id_product' => [],
		'ean13' => [],
		'reference' => [],
		'supplier_reference' => [],
		'wholesale_price' => [
			'type' => 'price',
		],
		'price' => [
			'type' => 'price',
		],
		'ecotax' => [
			'type' => 'price',
		],
		'weight' => [],
		'unit_price_impact' => [
			'type' => 'price',
		],
		'minimal_quantity' => [],
		'available_date' => [],
		'associations' => [
			'subObjectMapping' => [
				'product_option_values' => [],
				'images' => [],
			],
		],
	];

	public $id;
	public $id_product;
	public $ean13;
	public $reference;
	public $supplier_reference;
	public $wholesale_price;
	public $price;
	public $ecotax;
	public $weight;
	public $unit_price_impact;
	public $minimal_quantity;
	public $available_date;
	public $associations;

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_product';
		$this->linkTableDoliCol = 'fk_product_doli';
		$this->linkTablePrestaCol = 'fk_product_presta';
		$this->linkTablePrestaAttributeCol = 'fk_product_presta_attribute';

		return parent::__construct($presta);
	}

	/**
	 * Check if product use combinations
	 *
	 * @return bool
	 */
	public function fetchOptionValues()
	{
		$idList = [];

		if (empty($this->associations->product_option_values)) {
			$this->setError('No option to fetch');
			return false;
		}

		foreach ($this->associations->product_option_values as $option_value) {
			if (empty($option_value->id)) {
				continue;
			}
			$idList[] = intval($option_value->id);
		}

		$optionValuesStatic = new PrestaProductOptionValue($this->presta);
		$optionsValues = $optionValuesStatic->fetchAll([], [], ['id' => $idList], 0, 0, [], true, 600);
		if (!$optionsValues) {
			return false;
		}

		$this->optionsValues = $optionsValues;
		return true;
	}

	/**
	 * @param bool   $withToolTip default false, set it to true to add html tooltip, keep false for no html
	 * @param string $separator
	 *
	 * @return void
	 */
	public function getProductCombinationName($withToolTip = false, $separator = ' - ')
	{
		if (empty($this->optionsValues)) {
			$this->fetchOptionValues();
		}

		if (empty($this->optionsValues)) {
			$this->setError('No option values detected');
			return false;
		}

		$out = '';
		foreach ($this->optionsValues as $optionsValue) {
			$out .= (!empty($out) ? $separator : '');

			if ($withToolTip) {
				$out .= '<span title="' . dol_escape_htmltag($optionsValue->getProductOptionName()) . '">' . $this->getTradValue($optionsValue->name) . '</span>';
			} else {
				$out .= $this->getTradValue($optionsValue->name);
			}
		}

		return $out;
	}

	public function getImageLink($imageId)
	{
		return dol_buildpath('prestasync/interface-image.php', 1) . '?presta-id=1&resource=product&productid=' . $this->id_product . '&imageid=' . $imageId;
	}

	public function setDolLink()
	{
		return $this->setCustomDolLink();
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getDolLinkInfo()
	{
		$res = $this->getCustomTableDolLinkInfo();
		if ($res === false) {
			return false;
		}

		if(!empty($this->linkObject) && !$this->checkDolProductIdExist($this->doliElementId)){
			$this->delDolLink();
			return 0;
		}

		if (!empty($this->reference) && getDolGlobalInt('PRESTASYNC_PRODUCT_AUTO_LINK') && $this->getLinkStatus() == self::STATUS_NOT_LINKED) {
			$doliProductCombination = new Product($this->presta->db);
			if ($doliProductCombination->fetch(null, $this->reference) > 0) {
				if (!$this->linkToExistingDolibarrProduct($doliProductCombination->id, true)) {
					$res = $this->getCustomTableDolLinkInfo();
				}
			}
		}

		return $res;
	}

	function checkDolProductIdExist($id){
		$sql = 'SELECT rowid FROM '.$this->presta->db->prefix().'product WHERE rowid = '. (int)$id;
		return (bool) $this->presta->db->getRow($sql);
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getPrestaLinkInfo()
	{
		return $this->getCustomTablePrestaLinkInfo();
	}

	public function setCustomDolLink()
	{
		if (method_exists($this, 'checkCreateLinkReady') && !$this->checkCreateLinkReady()) {
			return false;
		}

		$sql = 'INSERT INTO ' . $this->presta->db->prefix() . $this->linkTable . '
					 (rowid, fk_presta, ' . $this->linkTablePrestaCol . ',' . $this->linkTableDoliCol . ',' . $this->linkTablePrestaAttributeCol . ', date_creation, tms)
					 VALUES
					 (NULL, ' . intval($this->presta->id) . ', ' . intval($this->id_product) . ', ' . intval($this->doliElementId) . ',' . intval($this->id) . ', NOW(), NOW())
    			';

		if (!$this->presta->db->query($sql)) {
			$this->setError('Error setLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->getDolLinkInfo();

		return true;
	}

	/**
	 * @return bool
	 */
	public function delDolLink()
	{
		if (empty($this->linkObject)) {
			$this->getDolLinkInfo();
		}

		if (empty($this->linkObject)) {
			return false;
		}

		$sql = 'DELETE FROM ' . $this->presta->db->prefix() . $this->linkTable . ' WHERE rowid = ' . intval($this->linkObject->id);

		if (!$this->presta->db->query($sql)) {
			$this->setError('Error delLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->linkObject = null;
		$this->doliElementId = 0;
		return true;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	protected function getCustomTableDolLinkInfo()
	{
		$this->linkObject = null;

		$sql = 'SELECT rowid id, fk_presta, ' . $this->linkTableDoliCol . ', ' . $this->linkTablePrestaCol . ', date_creation, tms
					FROM ' . $this->presta->db->prefix() . $this->linkTable . '
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND ' . $this->linkTablePrestaCol . ' = ' . intval($this->id_product) . '
						AND ' . $this->linkTablePrestaAttributeCol . ' = ' . intval($this->id) . '
    			';

		$this->doliElementId = false;
		$obj = $this->presta->db->getRow($sql);

		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj === 0) {
			$this->doliElementId = 0;
			return 0;
		}

		$this->doliElementId = intval($obj->{$this->linkTableDoliCol});
		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->tms);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	protected function getCustomTablePrestaLinkInfo()
	{
		$this->linkObject = null;

		$sql = 'SELECT rowid id, fk_presta, ' . $this->linkTableDoliCol . ', ' . $this->linkTablePrestaCol . ', date_creation, tms
					FROM ' . $this->presta->db->prefix() . $this->linkTable . '
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND ' . $this->linkTableDoliCol . ' = ' . intval($this->doliElementId) . '
    			';

		$obj = $this->presta->db->getRow($sql);
		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj == 0) {
			return 0;
		}

		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->tms);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @param      $dolibarr_product_id
	 * @param bool $skipGetDolLinkInfo // to avoid infinite loop because getDolLinkInfo use linkToExistingDolibarrProduct too
	 *
	 * @return void
	 */
	public function linkToExistingDolibarrProduct($dolibarr_product_id, $skipGetDolLinkInfo = false)
	{
		// 1 check if link already exist
		if (!$skipGetDolLinkInfo && $this->getDolLinkInfo()) {
			$this->setError($this->reference . ' Already linked');
			return false;
		}

		// 2 check product and ref
		$product = new Product($this->presta->db);
		if ($product->fetch($dolibarr_product_id) <= 0) {
			$this->setError(' Product id ' . $dolibarr_product_id . ' not found');
			return false;
		}

		if ($product->ref != $this->reference) {
			$this->setError(' Product ref ' . $product->ref . ' is different of ' . $this->reference);
			return false;
		}

		$this->doliObject = $product;
		$this->doliElementId = $product->id;

		return $this->setDolLink();
	}

	function updateFields(array $fields)
	{
		if (empty($this->id)) {
			return false;
		}

		if (empty($fields) || !is_array($fields)) {
			$this->setError('Need fields values');
			return false;
		}

		foreach ($fields as $kField => $vField) {
			if (!in_array($kField, ['reference', 'weight', 'ecotax', 'price', 'wholesale_price', 'reference', 'ean13', 'supplier_reference'])) {
				$this->setError('Combination field update not allowed for : ' . $kField);
				return false;
			}
		}

		if((int)$this->presta->shop_version == 0) {
			$this->setError('Shop version not defined');
			return false;
		}

		if((int)$this->presta->shop_version < 8) {
			$this->setError('Shop version under 8 not support patch');
			return false;
		}

		$fields = array_map('trim', $fields);
		$fields['id'] = $this->id;
//		$fields['id_product']= $this->id_product;

		$moreOpt = [
			'id' => $this->id,
		];

		$result = $this->presta->updateToWebService($this->resource, $fields, $moreOpt);

		if (!$result && !empty($this->presta->errors)) {
			$this->setError($this->presta->errors);
		}
		return $result;
	}
}

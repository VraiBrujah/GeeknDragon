<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

class prestaLib
{

	/**
	 * @param     $oldPrice
	 * @param     $newPrice
	 * @param int $round
	 *
	 * @return float|int
	 */
	public static function priceEvo($oldPrice, $newPrice, $round = 2)
	{
		$oldPrice = floatval($oldPrice);
		if (empty($oldPrice)) return 0;
		$evo = ($newPrice - $oldPrice) / $oldPrice * 100;

		if (!empty($round)) {
			$evo = round($evo, $round);
		}
		return $evo;
	}

	/**
	 * @param     $oldPrice
	 * @param     $newPrice
	 * @param int $round
	 *
	 * @return float|int
	 */
	public static function displayEvo($percentage, $displayType = 'badge', $text = '', $title = '', $revert = false)
	{
		$preclass = 'badge';
		if ($displayType != 'badge') {
			$preclass = 'text';
		}

		$successClass = $preclass . '-success';
		$dangerClass = $preclass . '-danger';
		if ($revert) {
			$successClass = $preclass . '-danger';
			$dangerClass = $preclass . '-success';
		}

		$moreclass = '';
		if (!empty($title)) {
			$moreclass = 'classfortooltip';
		}

		if (empty($text)) {
			$text = price($percentage) . '%';
		}

		if ($percentage > 0) {
			print '<span class="badge ' . $successClass . ' ' . $moreclass . '" title="' . dol_escape_htmltag($title) . '"><i class="fa fa-caret-up"></i> ' . $text . '</span>';
		} elseif ($percentage < 0) {
			print '<span class="badge ' . $dangerClass . ' ' . $moreclass . '" title="' . dol_escape_htmltag($title) . '"><i class="fa fa-caret-down"></i> ' . $text . '</span>';
		} else {
			print price($percentage) . '%';
		}
	}

	/**
	 * @param $ref
	 *
	 * @return bool|int|object   false on sql fail , 0 on not found, > 0 for id
	 */
	public static function searchProductIdByRef($ref)
	{
		global $db;
		$obj = $db->getRow('SELECT rowid id FROM ' . $db->prefix() . 'product WHERE ref = \'' . $db->escape($ref) . '\' ');
		if (empty($obj)) {
			return $obj;
		}

		return $obj->id;
	}

	public static function genHtmlAttr($attr)
	{
		// escape all attribute
		$attr = array_map('dol_escape_htmltag', $attr);

		$TCompiledAttr = [];
		foreach ($attr as $key => $value) {
			$TCompiledAttr[] = $key . '="' . $value . '"';
		}

		return empty($TCompiledAttr) ? '' : implode(' ', $TCompiledAttr);
	}

}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

include_once __DIR__ . '/presta.class.php';
require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';
require_once __DIR__ . '/prestaCombination.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

class PrestaProduct extends PrestaCommonObject
{

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'products';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'product';

	/**
	 * the Dolibarr linked object
	 *
	 * @var Product $doliObject ;
	 */
	public $doliObject;

	public string $linkTable;
	public string $linkTableDoliCol;
	public string $linkTablePrestaCol;
	public string $linkTablePrestaAttributeCol;

	/**
	 * @var PrestaCombination[]
	 */
	public array $combinations = [];

	public $fields = [
		'id' => [],
		'id_manufacturer' => [],
		'id_supplier' => [],
		'id_category_default' => [],
		'new' => [],
		'cache_default_attribute' => [],
		'id_default_image' => [],
		'id_default_combination' => [],
		'id_tax_rules_group' => [],
		'position_in_category' => [],
		'manufacturer_name' => [
			'notWritable' => true,
		],
		'quantity' => [
			'notWritable' => true,
		],
		'type' => [],
		'id_shop_default' => [],
		'reference' => [
			'labelKey' => 'Ref',
		],
		'supplier_reference' => [],
		'location' => [],
		'width' => [],
		'height' => [],
		'depth' => [],
		'weight' => [],
		'quantity_discount' => [],
		'ean13' => [],
		'isbn' => [],
		'upc' => [],
		'mpn' => [],
		'cache_is_pack' => [],
		'cache_has_attachments' => [],
		'is_virtual' => [],
		'state' => [

		],
		'additional_delivery_times' => [],
		'delivery_in_stock' => [],
		'delivery_out_stock' => [],
		'product_type' => [
			'compatibility' => [
				'1.7' => 'type',
			],
		],
		'on_sale' => [],
		'online_only' => [],
		'ecotax' => [],
		'minimal_quantity' => [],
		'low_stock_threshold' => [],
		'low_stock_alert' => [],
		'price' => [
			'labelKey' => 'Price',
		],
		'wholesale_price' => [
			'labelKey' => 'BuyPrice',
		],
		'unity' => [],
		'unit_price' => [],
		'unit_price_ratio' => [],
		'additional_shipping_cost' => [],
		'customizable' => [],
		'text_fields' => [],
		'uploadable_files' => [],
		'active' => [
			'labelKey' => 'PrestaProductActiveStatus'],
		'redirect_type' => [],
		'id_type_redirected' => [],
		'available_for_order' => [],
		'available_date' => [],
		'show_condition' => [],
		'condition' => [],
		'show_price' => [],
		'indexed' => [],
		'visibility' => [],
		'advanced_stock_management' => [],
		'date_add' => [],
		'date_upd' => [],
		'pack_stock_type' => [],
		'meta_description' => [
			'langs' => true,
		],
		'meta_keywords' => [
			'langs' => true,
		],
		'meta_title' => [
			'langs' => true,
		],
		'link_rewrite' => [
			'labelKey' => 'PublicUrl',
			'langs' => true,
			'pattern' => '[0-9a-zA-Z_\-]{1,255}',
			'placeholder' => ''
		],
		'name' => [
			'labelKey' => 'PrestaProductName',
			'langs' => true,
		],
		'description' => [
			'langs' => true,
		],
		'description_short' => [
			'langs' => true,
		],
		'available_now' => [],
		'available_later' => [],
		'associations' => [
			'subObjectMapping' => [
				'categories' => [],
				'images' => [],
				'combinations' => [],
				'product_option_values' => [],
				'product_features' => [],
				'tags' => [],
				'stock_availables' => [],
				'attachments' => [],
				'accessories' => [],
			],
		],
	];

	public $id;
	public $id_manufacturer;
	public $id_supplier;
	public $id_category_default;
	public $new;
	public $cache_default_attribute;
	public $id_default_image;
	public $id_default_combination;
	public $id_tax_rules_group;
	public $position_in_category;
	public $manufacturer_name;
	public $quantity;
	public $type;
	public $id_shop_default;
	public $reference;
	public $supplier_reference;
	public $location;
	public $width;
	public $height;
	public $depth;
	public $weight;
	public $quantity_discount;
	public $ean13;
	public $isbn;
	public $upc;
	public $mpn;
	public $cache_is_pack;
	public $cache_has_attachments;
	public $is_virtual;
	public $state;
	public $additional_delivery_times;
	public $delivery_in_stock;
	public $delivery_out_stock;
	public $product_type;
	public $on_sale;
	public $online_only;
	public $ecotax;
	public $minimal_quantity;
	public $low_stock_threshold;
	public $low_stock_alert;
	public $price;
	public $wholesale_price;
	public $unity;
	public $unit_price;
	public $unit_price_ratio;
	public $additional_shipping_cost;
	public $customizable;
	public $text_fields;
	public $uploadable_files;
	public $active;
	public $redirect_type;
	public $id_type_redirected;
	public $available_for_order;
	public $available_date;
	public $show_condition;
	public $condition;
	public $show_price;
	public $indexed;
	public $visibility;
	public $advanced_stock_management;
	public $date_add;
	public $date_upd;
	public $pack_stock_type;
	public $meta_description;
	public $meta_keywords;
	public $meta_title;
	public $link_rewrite;
	public $name;
	public $description;
	public $description_short;
	public $available_now;
	public $available_later;
	public $associations;

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_product';
		$this->linkTableDoliCol = 'fk_product_doli';
		$this->linkTablePrestaCol = 'fk_product_presta';
		$this->linkTablePrestaAttributeCol = 'fk_product_presta_attribute';

		return parent::__construct($presta);
	}

	/**
	 * Check if product use combinations
	 *
	 * @return bool
	 */
	public function useCombinations()
	{
		return $this->product_type == 'combinations' ? true : false;
	}

	/**
	 * Check if product use combinations
	 *
	 * @return bool
	 */
	public function fetchCombinations()
	{
		$combiIdList = [];

		if (empty($this->associations->combinations)) {
			$this->setError('No combinations to fetch');
			return false;
		}

		foreach ($this->associations->combinations as $assocCombination) {
			$combiIdList[] = intval($assocCombination->id);
		}

		$combinationStatic = new PrestaCombination($this->presta);
		$combinations = $combinationStatic->fetchAll(
			[],
			[],
			[
				'id' => $combiIdList,
				'id_product' => $this->id,
			],
			count($this->associations->combinations)
		);

		if (!$combinations) {
			return false;
		}

		$this->combinations = $combinations;
		return true;
	}

	/**
	 * Return HTML string to show a field into a page
	 * Code very similar with showOutputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $value     Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
	 * @param string $moreparam To add more parametes on html input tag
	 * @param mixed  $morecss   Value for css to define size. May also be a numeric.
	 *
	 * @return string
	 */
	public function showOutputFieldQuick($key, $moreparam = '', $morecss = '')
	{
		global $langs, $conf;

		if ($key == 'active') {
			if (!empty($this->active)) {
				return dolGetBadge($langs->trans('Activated'), '', 'success');
			} else {
				return dolGetBadge($langs->trans('Disabled'), '', 'status9');
			}
		}
		if ($key == 'link_rewrite') {
			return '<a href="' . $this->getUrl() . '" target="_blank">' . $this->getUrl() . '</a>';
		}
		if ($key == 'is_virtual') {
			return intval($this->is_virtual) > 0 ? $langs->trans('Yes') : $langs->trans('No');
		}
		if ($key == 'on_sale') {
			return intval($this->on_sale) > 0 ? $langs->trans('ToSellSaleOnWebSite') : $langs->trans('NotSaleOnWebSite');
		} else {
			return parent::showOutputFieldQuick($key, $moreparam, $morecss);
		}
	}

	/**
	 * TODO : this is a duplicated method present in prestaOrder.class.php : create trait ?
	 *
	 * @return false|string
	 */
	public function getNomUrlDolibarr()
	{
		if (!empty($this->doliObject)) {
			return $this->doliObject->getNomUrl();
		} elseif ($this->doliElement) {
			return false;
		}
	}

	/**
	 * @param User $user
	 *
	 * @return false|int|void
	 */
	public function syncToDolibarr($user, $notrigger = 0)
	{
		global $conf, $langs;

		// Check if synced
		$this->getDolLinkInfo();

		if ($this->useCombinations() && !$this->fetchCombinations()) {
			return false;
		}

		if ($this->useCombinations()) {
			$errorCount = 0;
			foreach ($this->combinations as $combination) {
				if (!$this->syncCombinationToDolibarr($user, $combination, $notrigger)) {
					$errorCount++;
				}
			}

			if ($errorCount) {
				return false;
			}
		} else {
			if (!empty($this->linkObject)) {
				/**
				 * UPDATE PRODUCT
				 */

				if (!$this->fetchDolibarrObject()) {
					$this->setError('Error: syncToDolibarr:fetchDolibarrObject');
					return false;
				}

				$product = clone $this->doliObject;

				$needUpdate = false;

				if ($product === false) {
					$this->setError('Error: syncToDolibarr: product not fetched');
					return false;
				}

				$productDefaultData = $this->prepareDolProductObject('update');

				if (getDolGlobalInt('PRESTASYNC_PRODUCT_NO_DESC') == 0 && $product->description != $productDefaultData->description_short) {
					$product->description = $productDefaultData->description_short;
					$needUpdate = true;
				}

				if (getDolGlobalInt('PRESTASYNC_PRODUCT_NO_UPD_SELL_PRICE') == 0 && floatval($product->price) != floatval($productDefaultData->price)) {
					$product->price = $productDefaultData->price;
					$product->default_vat_code = $productDefaultData->default_vat_code;
					$product->updatePrice($productDefaultData->price, 'HT', $user, $productDefaultData->tva_tx);
					$needUpdate = true;
				}

				$fieldsToCheck = ['label', 'ref', 'weight', 'barcode', 'url'];
				foreach ($fieldsToCheck as $field){
					if ($product->$field != $productDefaultData->$field ) {
						$product->$field = $productDefaultData->$field;
						$needUpdate = true;
					}
				}


				if ($needUpdate) {
					$resCreate = $product->update($product->id, $user);
					if ($resCreate < 0) {
						$this->setError('Product ref ' . $this->reference . ' creation fail : ' . $product->errorsToString());
						return false;
					}
				}

				/**
				 * IMPORT CATEGORIES
				 */
				if(!empty($this->associations) && !empty($this->associations->categories)){
					$this->syncPrestaCatToDoliProduct($user, $product);
				}

			} else {
				/**
				 * IMPORT PRODUCT
				 */
				// Combinations are based on parent product
				$product = $this->prepareDolProductObject();

				if ($product === false) {
					return false;
				}

				$resCreate = $product->create($user);
				if ($resCreate < 0) {
					$this->setError('Product ref ' . $this->reference . ' creation fail : ' . $product->errorsToString());
					return false;
				}

				// ADD link
				$this->doliElementId = $product->id;
				$this->doliObject = $product;
				if (!$this->setDolLink()) {
					return false;
				}
			}

			if ($product) {
				/**
				 * IMPORT FOURN PRICE AND REF
				 */
				if ($this->syncPrestaFournPriceToDoliProduct($user, $product, $this->id, 0, 'auto', $notrigger) === false) {
					// TODO : fail or continue for photo ?
				}

				/**
				 * IMPORT CATEGORIES
				 */
				if(!empty($this->associations) && !empty($this->associations->categories)){
					$this->syncPrestaCatToDoliProduct($user, $product);
				}

				/**
				 * IMPORT PHOTO
				 */
				// Fetch photo from prestashop
				if ($this->syncPhotoToDolibarr($product) === false) {
					return false;
				}

				return $product->id;
			}
		}
	}

	/**
	 * @param User  $user
	 * @param array $ids
	 * @param int   $notrigger
	 *
	 * @return false|int|void
	 */
	public function syncCombinationsIdsToDolibarr(User $user, array $ids, int $notrigger = 0, $fieldsToUpdate = [])
	{
		// Check if synced
		$this->getDolLinkInfo();

		if ($this->useCombinations() && !$this->fetchCombinations()) {
			return false;
		}

		$errorCount = 0;
		foreach ($this->combinations as $combination) {
			if (in_array($combination->id, $ids)) {
				if (!$this->syncCombinationToDolibarr($user, $combination, $notrigger, $fieldsToUpdate)) {
					$errorCount++;
				}
			}
		}

		if ($errorCount) {
			return false;
		}
	}

	/**
	 * @param User              $user
	 * @param PrestaCombination $combination
	 * @param int               $notrigger
	 *
	 * @return false|int|void
	 */
	public function syncCombinationToDolibarr($user, PrestaCombination $combination, int $notrigger = 0, $fieldsToUpdate = [])
	{
		global $conf, $langs;

		// Check if synced
		$combination->getDolLinkInfo();

		if (empty($combination->linkObject)) {
			/**
			 * PRODUCT CREATION
			 */
			return $this->importCombinationToDolibarr($user, $combination, $notrigger);
		}

		/**
		 * PRODUCT UPDATE
		 */
		if (!$combination->fetchDolibarrObject() || empty($fieldsToUpdate)) {
			return false;
		}

		// Combinations are based on parent product
		$newProductData = $this->prepareDolProductObjectFromCombination($combination);

		$product = $combination->doliObject;
		foreach ($fieldsToUpdate as $fieldToUpdate) {
			if ($fieldToUpdate === 'price') {
				$product->$fieldToUpdate = $newProductData->$fieldToUpdate;
				$product->updatePrice($newProductData->$fieldToUpdate, 'HT', $user);
				continue;
			}

			if ($fieldToUpdate === 'weight') {
				$product->weight_units = $newProductData->weight_units;
			}

			if (!property_exists($product, $fieldToUpdate)) {
				continue;
			}

			// Mise à jour du champ
			$product->$fieldToUpdate = $newProductData->$fieldToUpdate;
		}

		$resCreate = $product->update($product->id, $user);
		if ($resCreate < 0) {
			$this->setError('Product ref ' . $combination->reference . ' creation fail : ' . $product->errorsToString());
			return false;
		}

		/**
		 * IMPORT FOURN PRICE AND REF
		 */
		// errors message allready managed in syncPrestaFournPriceToDoliProduct method
		if (in_array('buy-price-force', $fieldsToUpdate)) {
			$this->syncPrestaFournPriceToDoliProduct($user, $product, $combination->id_product, $combination->id, true, $notrigger);
		} elseif (in_array('buy-price', $fieldsToUpdate)) {
			$this->syncPrestaFournPriceToDoliProduct($user, $product, $combination->id_product, $combination->id, 'auto', $notrigger);
		} elseif (in_array('buy-price-no-zero', $fieldsToUpdate)) {
			$this->syncPrestaFournPriceToDoliProduct($user, $product, $combination->id_product, $combination->id, 'no-zero', $notrigger);
		} elseif (in_array('buy-price-new-only', $fieldsToUpdate)) {
			$this->syncPrestaFournPriceToDoliProduct($user, $product, $combination->id_product, $combination->id, false, $notrigger);
		}

		/**
		 * IMPORT PHOTO
		 */
		// Fetch photo from prestashop
		if (in_array('image', $fieldsToUpdate)) {
			$res = $this->syncCombinationPhotoToDolibarr($product, $combination, true);
			if ($res === false) {
				return false;
			}

			// Clear other photos
			if (in_array('clear_images', $fieldsToUpdate)) {
				// Import photo
				require_once __DIR__ . '/prestaImage.class.php';
				require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';
				$image = new PrestaImage($this->presta);
				$imgDir = $image->getImageProductDir($product);
				if ($imgDir !== false) {
					$filearray = dol_dir_list($imgDir, "files", 0, '', '\.meta$', 'name', SORT_ASC, 1);
					if ($filearray && is_array($filearray)) {
						foreach ($filearray as $imgFile) {
							// Clear other images
							if ((strtolower(substr($imgFile['name'], -3)) == 'jpg' || strtolower(substr($imgFile['name'], -4)) == 'jpeg')
								&& !preg_match('/^photo\-[0-9]+\-[0-9]+\.jpeg$/', strtolower($imgFile['name']))) {
								unlink($imgFile['fullname']);
								$fileName = pathinfo($imgFile['fullname'], PATHINFO_FILENAME);

								$smallThumbPath = $imgFile['path'] . '/thumbs/' . $fileName . '_small.jpeg';
								if (file_exists($smallThumbPath)) {
									unlink($smallThumbPath);
								}

								$miniThumbPath = $imgFile['path'] . '/thumbs/' . $fileName . '_mini.jpeg';
								if (file_exists($miniThumbPath)) {
									unlink($miniThumbPath);
								}
							}
						}
					}
				}
			}
		}

		/**
		 * IMPORT CATEGORIES
		 */
		if(!empty($this->associations) && !empty($this->associations->categories)){
			$this->syncPrestaCatToDoliProduct($user, $product);
		}

		return true;
	}

	/**
	 * @param User              $user
	 * @param PrestaCombination $combination
	 * @param int               $notrigger
	 *
	 * @return false|int|void
	 */
	public function importCombinationToDolibarr($user, PrestaCombination $combination, $notrigger = 0)
	{
		global $conf, $langs;

		// skip if already sync
		if (!empty($combination->linkObject)) {
			return true;
		}

		// Check if synced
		$combination->getDolLinkInfo();

		// skip if already sync
		if (!empty($combination->linkObject)) {
			return true;
		}

		/**
		 * PRODUCT CREATION
		 */

		require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
		$searchProduct = new Product($this->presta->db);
		if ($searchProduct->fetch(null, $combination->reference) > 0) {
			$this->setError('Product ref ' . $combination->reference . ' allready exist in database');
			return false;
		}

		// Combinations are based on parent product
		$product = $this->prepareDolProductObjectFromCombination($combination);
		if (!$product) {
			$this->setError('Product ref ' . $combination->reference . ' prepare fail : ' . $this->getLastError());
			return false;
		}

		$resCreate = $product->create($user);
		if ($resCreate < 0) {
			$this->setError('Product ref ' . $combination->reference . ' creation fail : ' . $product->errorsToString());
			return false;
		}

		// ADD link
		$combination->doliElementId = $resCreate;
		$combination->doliObject = $product;
		if (!$combination->setDolLink()) {
			return false;
		}

		/**
		 * IMPORT FOURN PRICE AND REF
		 */
		if ($this->syncPrestaFournPriceToDoliProduct($user, $product, $combination->id_product, $combination->id, 'auto', $notrigger) === false) {
			// TODO : fail or continue for photo ?
		}

		/**
		 * IMPORT PHOTO
		 */
		// Fetch photo from prestashop
		if ($this->syncCombinationPhotoToDolibarr($product, $combination) === false) {
			return false;
		}

		return true;
	}

	/**
	 * IMPORT FOURN PRICE AND REF
	 *
	 * @param         $user
	 * @param Product $product
	 * @param         $prestaProductId
	 * @param int     $prestaProductCombinationId
	 * @param bool    $update Set true to update if price if exist or false for create only, use auto to use configuration choice
	 * @param int     $notrigger
	 *
	 * @return bool
	 */
	function syncPrestaFournPriceToDoliProduct($user, Product $product, $prestaProductId, $prestaProductCombinationId = 0, $update = 'auto', $notrigger = 0)
	{
		require_once __DIR__ . '/prestaProductSupplier.class.php';
		$prestaProductSuppliers = new PrestaProductSupplier($this->presta);
		$prestaSuppliersPricesList = $prestaProductSuppliers->fetchAll([], [], ['id_product' => $prestaProductId, 'id_product_attribute' => $prestaProductCombinationId]);
		if ($prestaSuppliersPricesList) {
			$errorsAddSupPrices = 0;
			foreach ($prestaSuppliersPricesList as $prestaSupplierPrice) {
				if ($this->syncProductSupplierPriceToDolibarr($user, $prestaSupplierPrice, $product, $update, $notrigger) === false) {
					// errors message allready managed in syncProductSupplierPriceToDolibarr method
					$errorsAddSupPrices++;
				}
			}

			if ($errorsAddSupPrices) {
				return false;
			}
		}

		return true;
	}

	/**
	 * SET PRODUCT CATEGORIES IN DOLIBARR FROM
	 * Prestashop categories (Categories need to exists in dolibarr before)
	 *
	 * @param         $user
	 * @param Product $product
	 *
	 * @return bool
	 */
	function syncPrestaCatToDoliProduct($user, Product $product)
	{
		require_once __DIR__ . '/prestaProductCategory.class.php';

		$dolibarrProductCats = $product->getCategoriesCommon(Categorie::TYPE_PRODUCT);
		foreach ($this->associations->categories as $prestaCatId) {
			$categoryPresta = new PrestaProductCategory($this->presta);
			$dolibarrCat = $categoryPresta->getDolibarrIdFromPrestaId($prestaCatId->id, true);
			if ($dolibarrCat > 0 && !in_array($dolibarrCat, $dolibarrProductCats)) {
				$product->setCategoriesCommon($dolibarrCat, Categorie::TYPE_PRODUCT, false);
			}

			// TODO add auto import categories and parents
		}

		return true;
	}

	/**
	 * @param      $product
	 * @param      $combination
	 * @param bool $forceReplaceImage
	 *
	 * @return bool|null
	 */
	public function syncCombinationPhotoToDolibarr($product, $combination, $forceReplaceImage = false)
	{
		/**
		 * IMPORT PHOTO
		 * TODO : Sync all photo ?
		 */
		// Fetch photo from prestashop
		$prestaIdImage = 0;
		if (!empty($combination->associations->images)) {
			$firstImg = reset($combination->associations->images);
			$prestaIdImage = $firstImg->id;
		}

		if (!$prestaIdImage && !empty($this->id_default_image)) {
			$prestaIdImage = $this->id_default_image;
		}

		if ($prestaIdImage) {
			// Import photo
			require_once __DIR__ . '/prestaImage.class.php';
			$image = new PrestaImage($this->presta);
			if (!$image->importImageDolProduct($product, $this->id, $prestaIdImage, $forceReplaceImage)) {
				$this->setError($image->getErrors());
				return false;
			}

			return true;
		}

		return null;
	}

	public function syncPhotoToDolibarr($product)
	{
		/**
		 * IMPORT PHOTO
		 * TODO : Sync all photo ?
		 */
		// Fetch photo from prestashop
		$prestaIdImage = 0;
		if (!empty($this->associations->images)) {
			$firstImg = reset($this->associations->images);
			$prestaIdImage = $firstImg->id;
		}

		if (!$prestaIdImage && !empty($this->id_default_image)) {
			$prestaIdImage = $this->id_default_image;
		}

		if ($prestaIdImage) {
			// Import photo
			require_once __DIR__ . '/prestaImage.class.php';
			$image = new PrestaImage($this->presta);
			if (!$image->importImageDolProduct($product, $this->id, $prestaIdImage)) {
				$this->setError($image->getErrors());
				return false;
			}

			return true;
		}

		return null;
	}

	/**
	 * @param User                  $user
	 * @param PrestaProductSupplier $prestaSupplierPrice
	 * @param Product               $product   target product
	 * @param bool                  $update    Set true to update if price if exist or false for create only, use auto to use configuration choice
	 * @param int                   $notrigger update_buyprice have no $notrigger trigger param but i prefer have it in case of it change
	 *
	 * @return false|int|void
	 */
	public function syncProductSupplierPriceToDolibarr($user, PrestaProductSupplier $prestaSupplierPrice, Product $product, $update = 'auto', $notrigger = 0)
	{
		global $conf, $langs;

		require_once __DIR__ . '/prestaSupplier.class.php';
		require_once DOL_DOCUMENT_ROOT . '/fourn/class/fournisseur.product.class.php';

		$prestaSupplier = new PrestaSupplier($this->presta);
		if (!$prestaSupplier->fetch($prestaSupplierPrice->id_supplier)) {
			$this->setError('Error fetching prestashop supplier id ' . $prestaSupplierPrice->id_supplier);
			return false;
		}

		// Check if supplier is linked to dolibarr
		if (!$prestaSupplier->doliElementId) {
			$this->setError('Error fetching prestashop supplier id ' . $prestaSupplierPrice->id_supplier . ' : supplier not linked');
			return false;
		}

		if (!$prestaSupplier->fetchDolibarrObject()) {
			$this->setError('Error fetching dolibarr supplier object for prestashop supplier id : ' . $prestaSupplierPrice->id_supplier);
			return false;
		}

		$productFour = new ProductFournisseur($this->presta->db);
		if ($productFour->fetch($product->id) < 1) { // fetch product
			$this->setError($productFour->errorsToString());
			return false;
		}

		$productSupplierPrice = $this->getProductSupplierPrice($prestaSupplier->doliObject->id, $prestaSupplier->id, $prestaSupplierPrice->product_supplier_reference, 1);
		if ($productSupplierPrice) {
			if (!$update) {
				return null;
			}

			if ($update === 'no-zero' && empty($prestaSupplierPrice->product_supplier_price_te)) {
				return null;
			}

			if ($update === 'auto' && getDolGlobalInt('PRESTASYNC_PRODUCT_NO_UPD_BUY_PRICE') > 0) {
				return null;
			}

			// note for update mode : To avoid update_buyprice to erase data, we need to set $product->product_fourn_price_id before update
			$idFournPrice = $productSupplierPrice->id;
			$productFour->fetch_product_fournisseur_price($idFournPrice);
		}

		if ($productFour->update_buyprice(1, $prestaSupplierPrice->product_supplier_price_te, $user, 'HT', $prestaSupplier->doliObject, 1, $prestaSupplierPrice->product_supplier_reference, $product->tva_tx) < 0) {
			$this->setError('Error fetching dolibarr supplier object for prestashop supplier id : ' . $prestaSupplierPrice->id_supplier);
			return false;
		}

		return true;
	}

	/**
	 * @param        $fk_product
	 * @param        $fk_soc
	 * @param string $ref_fourn
	 * @param int    $qty
	 *
	 * @return false|Object
	 */
	public function getProductSupplierPrice($fk_product, $fk_soc, $ref_fourn = '', $qty = 1)
	{
		$var = 'SELECT rowid,rowid id, entity, datec,tms,fk_product,fk_soc,ref_fourn,desc_fourn,fk_availability,price,quantity,remise_percent,remise,unitprice,charges,tva_tx,default_vat_code,info_bits,fk_user,fk_supplier_price_expression,import_key,delivery_time_days,supplier_reputation,multicurrency_tx,multicurrency_unitprice,fk_multicurrency,multicurrency_code,multicurrency_price,localtax1_tx,localtax1_type,localtax2_tx,localtax2_type,barcode,fk_barcode_type';
		$var .= ' FROM ' . MAIN_DB_PREFIX . 'product_fournisseur_price WHERE  fk_product = \'' . intval($fk_product) . '\' ';
		$var .= ' AND fk_soc = \'' . intval($fk_soc) . '\' ';
		$var .= ' AND ref_fourn = \'' . $this->presta->db->escape($ref_fourn) . '\' AND quantity <= ' . doubleval($qty) . ' ORDER BY quantity DESC';
		return $this->presta->db->getRow($var);
	}

	/**
	 * @return false|Product
	 */
	public function prepareDolProductObject($mode = 'create')
	{
		global $mysoc;
		require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
		$product = new Product($this->presta->db);

		$product->label = $this->getTradValue($this->name);
		$product->ref = $this->reference;
		$product->entity = $this->presta->entity;
		$product->barcode_type = getDolGlobalString('PRESTASYNC_EAN13', 0);
		$product->fk_unit = getDolGlobalInt('PRESTASYNC_DEFAULT_UNIT', 0);

		$product->status_buy = $this->active;
		if (getDolGlobalInt('PRESTASYNC_PRODUCT_FORCE_ACTIVE_ON_CREATE') > 0 && $mode == 'create') {
			$product->status_buy = 1;
			$product->status = 1;
		}

		$defaultWarehouse = getDolGlobalInt('MAIN_DEFAULT_WAREHOUSE');
		$defaultWarehouseSelected = getDolGlobalInt('PRESTASYNC_DEFAULT_PRODUCT_WAREHOUSE');
		$product->fk_default_warehouse = $defaultWarehouseSelected > 0 ? $defaultWarehouseSelected : ($defaultWarehouse > 0 ? $defaultWarehouse : null);

		// TODO : Get VAT from prestashop
		$sql = "SELECT taux as vat, code ";
		$sql .= " FROM " . $this->presta->db->prefix() . "c_tva";
		$sql .= " WHERE active > 0";
		$sql .= " AND rowid = " . getDolGlobalInt('PRESTASYNC_DEFAULT_VAT');
		$objTx = $this->presta->db->getRow($sql);
		if (!$objTx) {
			$this->setError('Invalid VAT setup');
			return false;
		}

		$product->tva_tx = $objTx->vat;
		$product->default_vat_code = $objTx->code;

		if (getDolGlobalInt('PRESTASYNC_PRODUCT_NO_DESC') == 0) {
			$product->description = $this->getTradValue($this->description_short);
		}

		$product->price = $this->price;
		$product->width_units = 0;
		$product->weight = $this->weight;
//		$product->height = $this->height; TODO Unit

//		$product->type = $this->product_type
		$product->barcode = static::generateNextProductBarcode($product, $product->barcode_type);
		if (!empty($this->ean13)) {
			$product->barcode = $this->ean13;
		}

		$product->url = $this->getUrl();

		return $product;
	}

	public function getUrl()
	{
		return rtrim($this->presta->shop_url, '/') . '/index.php?id_product=' . $this->id . '&rewrite=' . $this->getTradValue($this->link_rewrite) . '&controller=product';
	}

	/**
	 * @param PrestaCombination $combination
	 *
	 * @return false|Product
	 */
	public function prepareDolProductObjectFromCombination(PrestaCombination $combination)
	{
		// Combinations are based on parent product
		$product = $this->prepareDolProductObject();
		if (!$product) {
			return false;
		}

		$product->label .= ' ' . $combination->getProductCombinationName();

		// Combination use price impact
		$product->price += $combination->price;
		$product->ref = $combination->reference;

		$product->barcode = static::generateNextProductBarcode($product, $product->barcode_type);
		if (!empty($combination->ean13)) {
			$product->barcode = $combination->ean13;
		}

		$product->weight += $combination->weight;
//		$product->height = $combination->height; // TODO Unit

		return $product;
	}

	public function setCustomDolLink()
	{
		if (method_exists($this, 'checkCreateLinkReady') && !$this->checkCreateLinkReady()) {
			return false;
		}

		$sql = 'INSERT INTO ' . $this->presta->db->prefix() . $this->linkTable . '
					 ( fk_presta, ' . $this->linkTablePrestaCol . ',' . $this->linkTableDoliCol . ',' . $this->linkTablePrestaAttributeCol . ', date_creation, tms)
					 VALUES
					 ( ' . intval($this->presta->id) . ', ' . intval($this->id) . ', ' . intval($this->doliElementId) . ',0, NOW(), NOW())
    			';

		if (!$this->presta->db->query($sql)) {
			$this->setError('Error setLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->getDolLinkInfo();

		return true;
	}

	/**
	 * @return bool
	 */
	public function delDolLink()
	{
		if (empty($this->linkObject)) {
			$this->getDolLinkInfo();
		}

		if (empty($this->linkObject)) {
			return false;
		}

		$sql = 'DELETE FROM ' . $this->presta->db->prefix() . $this->linkTable . ' WHERE rowid = ' . intval($this->linkObject->id);
		if (!$this->presta->db->query($sql)) {
			$this->setError('Error delLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->linkObject = null;
		$this->doliElementId = 0;
		return true;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	protected function getCustomTableDolLinkInfo()
	{
		$this->linkObject = null;

		$sql = 'SELECT rowid id, fk_presta, ' . $this->linkTableDoliCol . ', ' . $this->linkTablePrestaCol . ', date_creation, tms
					FROM ' . $this->presta->db->prefix() . $this->linkTable . '
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND ' . $this->linkTablePrestaCol . ' = ' . intval($this->id) . '
						AND ' . $this->linkTablePrestaAttributeCol . ' = 0
    			';

		$this->doliElementId = false;
		$obj = $this->presta->db->getRow($sql);

		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj === 0) {
			$this->doliElementId = 0;
			return 0;
		}

		$this->doliElementId = intval($obj->{$this->linkTableDoliCol});
		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->date_creation);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	protected function getCustomTablePrestaLinkInfo()
	{
		$this->linkObject = null;

		$sql = 'SELECT rowid id, fk_presta, ' . $this->linkTableDoliCol . ', ' . $this->linkTablePrestaCol . ', date_creation, tms
					FROM ' . $this->presta->db->prefix() . $this->linkTable . '
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND ' . $this->linkTableDoliCol . ' = ' . intval($this->doliElementId) . '
    			';

		$obj = $this->presta->db->getRow($sql);
		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj == 0) {
			return 0;
		}

		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->date_creation);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @param int $productId
	 */
	static function getAllDolProductLinks(int $productId, $limit = 10)
	{
		global $db;

		$prestaStatic = new Presta($db);
		$prestaProduct = new self($prestaStatic);

		$sql = 'SELECT rowid id, fk_presta, ' . $prestaProduct->linkTableDoliCol . ' as fk_product_doli, ' . $prestaProduct->linkTablePrestaCol . ' as fk_product_presta, date_creation, tms
					FROM ' . $prestaProduct->presta->db->prefix() . $prestaProduct->linkTable . '
					WHERE ' . $prestaProduct->linkTableDoliCol . ' = ' . $productId . ' LIMIT ' . $limit;

		$objs = $prestaProduct->presta->db->getRows($sql);
		if ($objs === false) {
			return false;
		}

		if (empty($objs)) {
			return [];
		}

		foreach ($objs as $k => $obj) {
			$objs[$k]->tms = $prestaProduct->presta->db->jdate($obj->tms);
			$objs[$k]->date_creation = $prestaProduct->presta->db->jdate($obj->date_creation);
		}

		return $objs;
	}

	public function setDolLink()
	{
		return $this->setCustomDolLink();
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getDolLinkInfo()
	{
		$res = $this->getCustomTableDolLinkInfo();
		if ($res === false) {
			return false;
		}

		if(!empty($this->linkObject) && !$this->checkDolProductIdExist($this->doliElementId)){
			$this->delDolLink();
			return 0;
		}

		if (!empty($this->reference) && getDolGlobalInt('PRESTASYNC_PRODUCT_AUTO_LINK') && $this->getLinkStatus() == self::STATUS_NOT_LINKED) {
			$doliProductCombination = new Product($this->presta->db);
			if ($doliProductCombination->fetch(null, $this->reference) > 0) {
				if (!$this->linkToExistingDolibarrProduct($doliProductCombination->id, true)) {
					$res = $this->getCustomTableDolLinkInfo();
				}
			}
		}

		return $res;
	}

	function checkDolProductIdExist($id){
		$sql = 'SELECT rowid FROM '.$this->presta->db->prefix().'product WHERE rowid = '. (int)$id;
		return (bool) $this->presta->db->getRow($sql);
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getPrestaLinkInfo()
	{
		return $this->getCustomTablePrestaLinkInfo();
	}

	/**
	 * @param Product $product
	 */
	public static function getAllPrestaLinksInfos(Product $product)
	{
		global $db;

		$sql = 'SELECT rowid id, fk_presta, fk_product_doli, fk_product_presta,fk_product_presta_attribute, date_creation, tms
					FROM ' . $db->prefix() . 'prestasync_product
					WHERE fk_product_doli = ' . intval($product->id) . ' LIMIT ' . PHP_INT_MAX;

		$objs = $db->getRows($sql);
		if ($objs === false) {
			return false;
		}

		if (empty($objs)) {
			return [];
		}

		$out = [];
		foreach ($objs as $obj) {
			$obj->tms = $db->jdate($obj->tms);
			$obj->date_creation = $db->jdate($obj->date_creation);
			$out[$obj->id] = $obj;
		}

		return $out;
	}

	public function getImageLink($imageId)
	{
		return dol_buildpath('prestasync/interface-image.php', 1) . '?presta-id='.$this->presta->id.'&resource=product&productid=' . $this->id . '&imageid=' . $imageId;
	}

	public function getDefaultImageLink()
	{
		if (empty($this->id_default_image)) {
			return false;
		}

		return $this->getImageLink($this->id_default_image);
	}

	/**
	 * @param string $mode default '' , 'pill', 'dot'
	 *
	 * @return string
	 */
	public function getStatusBadge($mode = '')
	{
		global $langs;

		if (!$this->useCombinations()) {
			return parent::getStatusBadge($mode);
		}

		return dolGetBadge($langs->trans('Combinations'), '', 'status2', $mode);
	}

	/**
	 * @param Product $object
	 * @param         $fk_barcode_type
	 *
	 * @return string|void
	 */
	public static function generateNextProductBarcode(Product $object, $fk_barcode_type)
	{
		global $conf;
		if (!empty($conf->barcode->enabled) && !empty($conf->global->BARCODE_PRODUCT_ADDON_NUM)) {
			$module = strtolower($conf->global->BARCODE_PRODUCT_ADDON_NUM);
			$dirbarcode = array_merge(['/core/modules/barcode/'], $conf->modules_parts['barcode']);
			foreach ($dirbarcode as $dirroot) {
				$res = dol_include_once($dirroot . $module . '.php');
				if ($res) {
					break;
				}
			}
			if ($res > 0) {
				if (!class_exists($module)) {
					return '';
				}

				$modBarCodeProduct = new $module();

				if (empty($tmpcode) && !empty($modBarCodeProduct->code_auto)) {
					return $modBarCodeProduct->getNextValue($object, $fk_barcode_type);
				}
			}

			return '';
		}
	}

	/**
	 * @param $dolibarr_product_id
	 *
	 * @return void
	 */
	public function linkToExistingDolibarrProduct($dolibarr_product_id, $skipGetDolLinkInfo = false)
	{
		// 1 check if link already exist
		if (!$skipGetDolLinkInfo && $this->getDolLinkInfo()) {
			$this->setError($this->reference . ' Already linked');
			return false;
		}

		// 2 check product and ref
		$product = new Product($this->presta->db);
		if ($product->fetch($dolibarr_product_id) <= 0) {
			$this->setError(' Product id ' . $dolibarr_product_id . ' not found');
			return false;
		}

		if ($product->ref != $this->reference) {
			$this->setError(' Product ref ' . $product->ref . ' is different of ' . $this->reference);
			return false;
		}

		$this->doliObject = $product;
		$this->doliElementId = $product->id;

		return $this->setDolLink();
	}

	function updateFields(array $fields)
	{
		if (empty($this->id)) {
			return false;
		}

		if (empty($fields) || !is_array($fields)) {
			$this->setError('Need fields values');
			return false;
		}

		if((int)$this->presta->shop_version == 0) {
			$this->setError('Shop version not defined');
			return false;
		}

		if((int)$this->presta->shop_version < 8) {
			$this->setError('Shop version under V8 not support patch, please upgrade your prestashop to V8 minimum');
			return false;
		}

		foreach ($fields as $kField => $vField) {
			if (!in_array($kField, ['name','meta_title','meta_description','meta_keywords','link_rewrite', 'reference', 'weight', 'ecotax', 'price', 'wholesale_price', 'reference', 'ean13', 'supplier_reference','description_short', 'description'])) {
				$this->setError('Product field update not allowed for : ' . $kField);
				return false;
			}
		}


		$fields['id'] = $this->id;
//		$fields['id_product']= $this->id_product;

		$moreOpt = [
			'id' => $this->id,
		];

		$result = $this->presta->updateToWebService($this->resource, $fields, $moreOpt);

		if (!$result && !empty($this->presta->errors)) {
			$this->setError($this->presta->errors);
		}
		return $result;
	}

	/**
	 * @return    bool|int                False on failure, 0 on empty, id > 0 on success
	 */
	public static function checkProductRefExistsInDolibarr($ref, $entity)
	{
		global $db;
		require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
		$product = new Product($db);
		$sql = 'SELECT rowid id ';
		$sql .= ' FROM ' . $db->prefix() . $product->table_element;
		$sql .= ' WHERE entity = ' . intval($entity) . ' AND ref = \'' . $db->escape($ref) . '\' ';

		$obj = $db->getRow($sql);
		if ($obj) {
			return $obj->id;
		}

		return $obj;
	}

	/**
	 * @param int $id_product
	 * @param int $id_product_attribute
	 *
	 * @return false
	 */
	public function getProductRefFromPresta(int $id_product = 0 , int $id_product_attribute = 0){

		if($id_product_attribute > 0 ) {
			if (!class_exists('PrestaCombination')) { require_once __DIR__ . '/prestaCustomization.class.php'; }
			$prestaCombination = new PrestaCombination($this->presta);
			if(!$prestaCombination->fetch($id_product_attribute)){
				$this->setError('Unable to fetch product combination in prestashop');
				return false;
			}
			return $prestaCombination->reference;
		}

		if($id_product > 0 ){
			$prestaProduct = new PrestaProduct($this->presta);
			if(!$prestaProduct->fetch($id_product)){
				$this->setError('Unable to fecth product in prestashop');
				return false;
			}

			return $prestaProduct->reference;
		}

		return false;
	}
}

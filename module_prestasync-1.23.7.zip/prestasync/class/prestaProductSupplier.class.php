<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaProductSupplier extends PrestaCommonObject
{
	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'product_suppliers';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = false;

	public $fields = [
		'id' => [],
		'id_product' => [],
		'id_product_attribute' => [],
		'id_supplier' => [],
		'id_currency' => [],
		'product_supplier_reference' => [],
		'product_supplier_price_te' => [],
	];

	public $id;
	public $id_product;
	public $id_product_attribute;
	public $id_supplier;
	public $id_currency;
	public $product_supplier_reference;
	public $product_supplier_price_te;

}

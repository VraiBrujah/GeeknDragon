<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaConfiguration extends PrestaCommonObject
{
	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'configurations';

	public $fields = [
		'id' => [],
		'value' => [],
		'name' => [],
		'id_shop_group' => [],
		'id_shop' => [],
		'date_add' => [],
		'date_upd' => [],
	];

	public $id;
	public $value;
	public $name;
	public $id_shop_group;
	public $id_shop;
	public $date_add;
	public $date_upd;

	/*
	const PRESTA_CONF_LIST = [
		'PRESTASYNC_WEBHOOK_URL' => [
			'label' => 'WebHookUrl'
		],
		'PRESTASYNC_MASS_UPDATE_MODE' => [
			'label' => 'UpdateMode'
		],
		'PRESTASYNC_IMPORT_FILE_URL' => [
			'label' => 'ImportFileUrl'
		]
	];
	*/

	/**
	 * @param $name
	 * @param $cache
	 *
	 * @return bool
	 */
	public function fetchFromName($name, $cache = true)
	{
		$resource = $this->presta->getFromWebService($this->resource, [], [], ['name' => $name], 1, false, [], $cache);
		if (!$resource) {
			$this->setError($this->presta->error);
			return false;
		}

		$resource = $this->presta::idFyArray($resource);
		if (empty($resource)) {
			return false;
		}

		$this->populate(reset($resource));
//		$this->getDolLinkInfo();

		return true;
	}

	/**
	 * @param $cache
	 *
	 * @return bool
	 */
	public function fetchAllPrestasyncConf($cache = true)
	{
		return $this->fetchAll([], [], ['name' => ['operator' => 'begin', 'search' => 'PRESTASYNC_']], false, false, [], $cache);
	}
}

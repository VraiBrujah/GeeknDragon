<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/presta.class.php
 * \ingroup     prestasync
 * \brief       This file is a CRUD class file for Presta (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT . '/core/class/commonobject.class.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
require_once __DIR__ . '/fetchCache.trait.php';

/**
 * Class for Presta
 */
class Presta extends CommonObject
{

	use \prestasync\fetchCache;

	const STATUS_DRAFT = 0;
	const STATUS_VALIDATED = 1;
	const STATUS_CANCELED = 9;
	/**
	 * @var string ID of module.
	 */
	public $module = 'prestasync';
	/**
	 * @var string ID to identify managed object.
	 */
	public $element = 'presta';
	/**
	 * @var string Name of table without prefix where object is stored. This is also the key used for extrafields management.
	 */
	public $table_element = 'prestasync_presta';
	/**
	 * @var int  Does this object support multicompany module ?
	 * 0=No test on entity, 1=Test with field entity, 'field@table'=Test with link by field@table
	 */
	public $ismultientitymanaged = 1;
	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 1;

	/**
	 * @var int  Prestashop default language id
	 */
	public $language = 1;

	public $forceCheckErrorsOnOutputFields = false;

	/**
	 * @var string String with name of icon for presta. Must be a 'fa-xxx' fontawesome code (or 'fa-xxx_fa_color_size') or 'presta@prestasync' if picto is file 'img/object_presta.png'.
	 */
	public $picto = 'prestasync.svg@prestasync';

	/**
	 *  'type' field format:
	 *    'integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter[:Sortfield]]]',
	 *    'select' (list of values are in 'options'),
	 *    'sellist:TableName:LabelFieldName[:KeyFieldName[:KeyFieldParent[:Filter[:Sortfield]]]]',
	 *    'chkbxlst:...',
	 *    'varchar(x)',
	 *    'text', 'text:none', 'html',
	 *    'double(24,8)', 'real', 'price',
	 *    'date', 'datetime', 'timestamp', 'duration',
	 *    'boolean', 'checkbox', 'radio', 'array',
	 *    'mail', 'phone', 'url', 'password', 'ip'
	 *        Note: Filter can be a string like "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.nature:is:NULL)"
	 *  'label' the translation key.
	 *  'picto' is code of a picto to show before value in forms
	 *  'enabled' is a condition when the field must be managed (Example: 1 or '$conf->global->MY_SETUP_PARAM' or '!empty($conf->multicurrency->enabled)' ...)
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 or 2 if field can be used for measure. Field type must be summable like integer or double(24,8). Use 1 in most cases, or 2 if you don't want to see the column total into list (for example for percentage)
	 *  'css' and 'cssview' and 'csslist' is the CSS style to use on field. 'css' is used in creation and update. 'cssview' is used in view mode. 'csslist' is used for columns in lists. For example: 'css'=>'minwidth300 maxwidth500 widthcentpercentminusx', 'cssview'=>'wordbreak', 'csslist'=>'tdoverflowmax200'
	 *  'help' is a 'TranslationString' to use to show a tooltip on field. You can also use 'TranslationString:keyfortooltiponlick' for a tooltip on click.
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
	 *  'arrayofkeyval' to set a list of values if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel"). Note that type can be 'integer' or 'varchar'
	 *  'autofocusoncreate' to have field having the focus on a create form. Only 1 field should have this property set to 1.
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *    'validate' is 1 if need to validate with $this->validateField()
	 *  'copytoclipboard' is 1 or 2 to allow to add a picto to copy value into clipboard (1=picto after label, 2=picto after value)
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields = [
		'rowid' => ['type' => 'integer', 'label' => 'TechnicalID', 'enabled' => '1', 'position' => 1, 'notnull' => 1, 'visible' => 0, 'noteditable' => '1', 'index' => 1, 'css' => 'left', 'comment' => "Id"],
		'ref' => ['type' => 'varchar(128)', 'label' => 'Ref', 'enabled' => '1', 'position' => 20, 'notnull' => 1, 'visible' => 4, 'noteditable' => '0', 'default' => '(PROV)', 'index' => 1, 'searchall' => 1, 'showoncombobox' => '1', 'validate' => '1', 'comment' => "Reference of object"],
		'entity' => ['type' => 'integer', 'label' => 'Entity', 'enabled' => '1', 'position' => 20, 'notnull' => 1, 'visible' => -1, 'default' => '1', 'index' => 1,],
		'label' => ['type' => 'varchar(255)', 'label' => 'Label', 'enabled' => '1', 'position' => 30, 'notnull' => 1, 'visible' => 1, 'searchall' => 1, 'css' => 'minwidth300', 'cssview' => 'wordbreak', 'help' => "Help text", 'showoncombobox' => '2', 'validate' => '1',],
		'shop_url' => ['type' => 'url', 'label' => 'ShopUrl', 'enabled' => '1', 'position' => 40, 'notnull' => 1, 'visible' => 1, 'validate' => '1',],
		'shop_admin_url' => ['type' => 'url', 'label' => 'ShopAdminUrl', 'enabled' => '1', 'position' => 41, 'notnull' => 0, 'visible' => 3, 'validate' => '1',],
		'api_key' => ['type' => 'password', 'label' => 'APIKey', 'help' => 'APIKeyHelp', 'enabled' => '1', 'position' => 42, 'notnull' => 1, 'visible' => 3, 'validate' => '1',],

		// Ne pas afficher shop_id et language car il vont chercher l'info par un apel API, si le site Presta met du temps à répondre toute la liste peut étre bloquée
		'shop_id' => ['type' => 'integer', 'label' => 'ShopID', 'enabled' => '1', 'position' => 42, 'notnull' => 1, 'default' => 1, 'visible' => 3, 'noteditable' => '0', 'index' => 1, 'css' => 'left', 'arrayofkeyval' => [0 => 'NotSelected']],
		'language' => ['type' => 'select', 'label' => 'PrestaLanguageId', 'enabled' => '1', 'position' => 43, 'notnull' => 1, 'default' => 1, 'visible' => 3, 'noteditable' => '0', 'index' => 1, 'css' => 'left', 'arrayofkeyval' => [0 => 'NotSelected']],

		// WorkFlow

		// TODO : manage it in a table
		// Ne pas afficher car il vont chercher l'info par un apel API, si le site Presta met du temps à répondre toute la liste peut étre bloquée
		'order_status_to_sync' => ['type' => 'checkbox', 'label' => 'OrderStatusToSync', 'arrayofkeyval' => [], 'help' => 'OrderStatusToSyncHelp', 'enabled' => '1', 'position' => 50, 'notnull' => 0, 'visible' => 3, 'noteditable' => '0', 'index' => 1, 'css' => 'left'],

		// Ne pas afficher car il vont chercher l'info par un apel API, si le site Presta met du temps à répondre toute la liste peut étre bloquée
		'order_status_on_sync' => ['type' => 'select', 'label' => 'OrderStatusOnSync', 'arrayofkeyval' => [], 'help' => 'OrderStatusOnSyncHelp', 'enabled' => '1', 'position' => 51, 'notnull' => 0, 'visible' => 3, 'noteditable' => '0', 'index' => 1, 'css' => 'left'],

		// TODO : manage it in a table
		// Ne pas afficher car il vont chercher l'info par un apel API, si le site Presta met du temps à répondre toute la liste peut étre bloquée
		'order_status_delivered' => ['type' => 'checkbox', 'label' => 'OrderStatusDelivered', 'arrayofkeyval' => [], 'help' => 'OrderStatusDeliveredHelp', 'enabled' => '1', 'position' => 52, 'notnull' => 0, 'visible' => 3, 'noteditable' => '0', 'index' => 1, 'css' => 'left'],

		'shop_version' => ['type' => 'varchar(5)', 'label' => 'ShopVersion', 'enabled' => '1', 'position' => 42, 'notnull' => 1, 'visible' => 1, 'noteditable' => '0', 'index' => 1, 'css' => 'left', 'default' => '1.8',
			'arrayofkeyval' => ['1.6' => '1.6 - not tested', '1.7' => '1.7', '8' => '8.x', '9' => '9.x', '10' => '10.x - not tested'],
		],
		'description' => ['type' => 'text', 'label' => 'Description', 'enabled' => '1', 'position' => 60, 'notnull' => 0, 'visible' => 3, 'validate' => '1',],
		'note_public' => ['type' => 'html', 'label' => 'NotePublic', 'enabled' => '1', 'position' => 61, 'notnull' => 0, 'visible' => 0, 'cssview' => 'wordbreak', 'validate' => '1',],
		'note_private' => ['type' => 'html', 'label' => 'NotePrivate', 'enabled' => '1', 'position' => 62, 'notnull' => 0, 'visible' => 0, 'cssview' => 'wordbreak', 'validate' => '1',],
		'date_creation' => ['type' => 'datetime', 'label' => 'DateCreation', 'enabled' => '1', 'position' => 500, 'notnull' => 1, 'visible' => -2,],
		'tms' => ['type' => 'timestamp', 'label' => 'DateModification', 'enabled' => '1', 'position' => 501, 'notnull' => 0, 'visible' => -2,],
		'fk_user_creat' => ['type' => 'integer:User:user/class/user.class.php', 'label' => 'UserAuthor', 'picto' => 'user', 'enabled' => '1', 'position' => 510, 'notnull' => 1, 'visible' => -2, 'foreignkey' => 'user.rowid',],
		'fk_user_modif' => ['type' => 'integer:User:user/class/user.class.php', 'label' => 'UserModif', 'picto' => 'user', 'enabled' => '1', 'position' => 511, 'notnull' => -1, 'visible' => -2,],
		'fk_c_input_reason' => ['type' => 'sellist:c_input_reason:label:rowid::(active:=:1):label', 'label' => 'PrestaInputReasonToUse', 'help' => 'PrestaInputReasonToUseHelp', 'picto' => 'question', 'enabled' => '1', 'position' => 520, 'notnull' => -1, 'visible' => 1,],
		'fk_project' => ['type' => 'integer:Project:projet/class/project.class.php:1', 'label' => 'Project', 'help' => 'PrestaProjectLinkHelp', 'picto' => 'project', 'enabled' => '$conf->project->enabled', 'position' => 521, 'notnull' => -1, 'visible' => -1, 'index' => 1, 'css' => 'maxwidth500 widthcentpercentminusxx', 'validate' => '1',],

		'fk_cond_reglement_id' => ['type' => 'sellist:c_payment_term:libelle:rowid::(active:=:1):sortorder', 'label' => 'DefaultMappingDefaultReglementCond', 'enabled' => '1', 'position' => 52, 'notnull' => 0, 'visible' => -1, 'index' => 1, 'css' => 'maxwidth500 widthcentpercentminusxx', 'validate' => '0',],
		'fk_mode_reglement_id' => ['type' => 'sellist:c_paiement:libelle:id::(active:=:1):libelle', 'label' => 'DefaultMappingDefaultReglementMode', 'enabled' => '1', 'position' => 52, 'notnull' => 0, 'visible' => -1, 'index' => 1, 'css' => 'maxwidth500 widthcentpercentminusxx', 'validate' => '0',],

		'last_main_doc' => ['type' => 'varchar(255)', 'label' => 'LastMainDoc', 'enabled' => '1', 'position' => 600, 'notnull' => 0, 'visible' => 0,],
		'import_key' => ['type' => 'varchar(14)', 'label' => 'ImportId', 'enabled' => '1', 'position' => 1000, 'notnull' => -1, 'visible' => -2,],
		'model_pdf' => ['type' => 'varchar(255)', 'label' => 'Model pdf', 'enabled' => '1', 'position' => 1010, 'notnull' => -1, 'visible' => 0,],
		'status' => ['type' => 'integer', 'label' => 'Status', 'enabled' => '1', 'position' => 2000, 'notnull' => 1, 'visible' => 0, 'default' => 0, 'index' => 1, 'arrayofkeyval' => ['0' => 'Brouillon', '1' => 'Valid&eacute;', '9' => 'Annul&eacute;'], 'validate' => '1',],
	];
	public $rowid;
	public $entity;
	public $ref;
	public $label;
	public $fk_project;
	public $fk_cond_reglement_id;
	public $shop_url;
	public $shop_id;
	public $shop_admin_url;
	public $shop_version;
	public $api_key;
	public $description;
	public $note_public;
	public $note_private;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $fk_c_input_reason;
	public $last_main_doc;
	public $import_key;
	public $model_pdf;
	public $status;
	public $fk_mode_reglement_id;
	public $order_status_delivered;
	public $order_status_on_sync;
	public $order_status_to_sync;
	// END MODULEBUILDER PROPERTIES

	// If this object has a subtable with lines

	// /**
	//  * @var string    Name of subtable line
	//  */
	// public $table_element_line = 'prestasync_prestaline';

	// /**
	//  * @var string    Field with ID of parent key if this object has a parent
	//  */
	// public $fk_element = 'fk_presta';

	// /**
	//  * @var string    Name of subtable class that manage subtable lines
	//  */
	// public $class_element_line = 'Prestaline';

	// /**
	//  * @var array	List of child tables. To test if we can delete object.
	//  */
	// protected $childtables = array();

	// /**
	//  * @var array    List of child tables. To know object to delete on cascade.
	//  *               If name matches '@ClassNAme:FilePathClass;ParentFkFieldName' it will
	//  *               call method deleteByParentField(parentId, ParentFkFieldName) to fetch and delete child object
	//  */
	// protected $childtablesoncascade = array('prestasync_prestadet');

	// /**
	//  * @var PrestaLine[]     Array of subtable lines
	//  */
	// public $lines = array();

	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $conf, $langs;

		$this->db = $db;

		if (empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && isset($this->fields['rowid']) && !empty($this->fields['ref'])) {
			$this->fields['rowid']['visible'] = 0;
		}

		if (empty($conf->multicompany->enabled) && isset($this->fields['entity'])) {
			$this->fields['entity']['enabled'] = 0;
		}

		// Example to show how to set values of fields definition dynamically
		/*if ($user->rights->prestasync->presta->read) {
			$this->fields['myfield']['visible'] = 1;
			$this->fields['myfield']['noteditable'] = 0;
		}*/

		// Unset fields that are disabled
//		foreach ($this->fields as $key => $val) {
//			if (isset($val['enabled']) && empty($val['enabled'])) {
//				unset($this->fields[$key]);
//			}
//		}

		if (intval(DOL_VERSION) < 19) {
			$this->fields['fk_c_input_reason']['type'] = 'sellist:c_input_reason:label:rowid::active=1:label';
			$this->fields['fk_cond_reglement_id']['type'] = 'sellist:c_payment_term:libelle:rowid::active=1:sortorder';
			$this->fields['fk_mode_reglement_id']['type'] = 'sellist:c_paiement:libelle:id::active=1:libelle';


			$this->fields['order_status_to_sync']['type'] = 'chkbxlst';
			$this->fields['order_status_delivered']['type'] = 'chkbxlst';
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs)) {
			foreach ($this->fields as $key => $val) {
				if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
					foreach ($val['arrayofkeyval'] as $key2 => $val2) {
						$this->fields[$key]['arrayofkeyval'][$key2] = $langs->trans($val2);
					}
				}
			}
		}
	}

	/**
	 * remplace les clés d'un tableau d'objets par les id des objets
	 *
	 * @param array $array
	 * @param       $field
	 *
	 * @return array|false
	 */
	public static function idFyArray($array, $field = 'id')
	{
		if (!is_array($array)) {
			return false;
		}

		$output = [];

		foreach ($array as $k => $v) {
			if (!isset($v->$field)) {
				return false;
			}

			$output[$v->$field] = $v;

			unset($array[$k]);
		}

		return $output;
	}

	/**
	 * Create object into database
	 *
	 * @param User $user      User that creates
	 * @param bool $notrigger false=launch triggers after, true=disable triggers
	 *
	 * @return int             <0 if KO, Id of created object if OK
	 */
	public function create(User $user, $notrigger = false)
	{
		$resultcreate = $this->createCommon($user, $notrigger);

		//$resultvalidate = $this->validate($user, $notrigger);

		return $resultcreate;
	}

	/**
	 * Clone an object into another one
	 *
	 * @param User $user   User that creates
	 * @param int  $fromid Id of object to clone
	 *
	 * @return    mixed                New object created, <0 if KO
	 */
	public function createFromClone(User $user, $fromid)
	{
		global $langs, $extrafields;
		$error = 0;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$object = new self($this->db);

		$this->db->begin();

		// Load source object
		$result = $object->fetchCommon($fromid);
		if ($result > 0 && !empty($object->table_element_line)) {
			$object->fetchLines();
		}

		// get lines so they will be clone
		//foreach($this->lines as $line)
		//	$line->fetch_optionals();

		// Reset some properties
		unset($object->id);
		unset($object->fk_user_creat);
		unset($object->import_key);

		// Clear fields
		if (property_exists($object, 'ref')) {
			$object->ref = empty($this->fields['ref']['default']) ? "Copy_Of_" . $object->ref : $this->fields['ref']['default'];
		}
		if (property_exists($object, 'label')) {
			$object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf") . " " . $object->label : $this->fields['label']['default'];
		}
		if (property_exists($object, 'status')) {
			$object->status = self::STATUS_DRAFT;
		}
		if (property_exists($object, 'date_creation')) {
			$object->date_creation = dol_now();
		}
		if (property_exists($object, 'date_modification')) {
			$object->date_modification = null;
		}
		// ...
		// Clear extrafields that are unique
		if (is_array($object->array_options) && count($object->array_options) > 0) {
			$extrafields->fetch_name_optionals_label($this->table_element);
			foreach ($object->array_options as $key => $option) {
				$shortkey = preg_replace('/options_/', '', $key);
				if (!empty($extrafields->attributes[$this->table_element]['unique'][$shortkey])) {
					//var_dump($key);
					//var_dump($clonedObj->array_options[$key]); exit;
					unset($object->array_options[$key]);
				}
			}
		}

		// Create clone
		$object->context['createfromclone'] = 'createfromclone';
		$result = $object->createCommon($user);
		if ($result < 0) {
			$error++;
			$this->error = $object->error;
			$this->errors = $object->errors;
		}

		if (!$error) {
			// copy internal contacts
			if ($this->copy_linked_contact($object, 'internal') < 0) {
				$error++;
			}
		}

		if (!$error) {
			// copy external contacts if same company
			if (!empty($object->socid) && property_exists($this, 'fk_soc') && $this->fk_soc == $object->socid) {
				if ($this->copy_linked_contact($object, 'external') < 0) {
					$error++;
				}
			}
		}

		unset($object->context['createfromclone']);

		// End
		if (!$error) {
			$this->db->commit();
			return $object;
		} else {
			$this->db->rollback();
			return -1;
		}
	}

	/**
	 * Load object lines in memory from the database
	 *
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchLines()
	{
		$this->lines = [];

		$result = $this->fetchLinesCommon();
		return $result;
	}

	/**
	 * Load object in memory from the database
	 *
	 * @param int    $id  Id object
	 * @param string $ref Ref
	 *
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null)
	{
		$result = $this->fetchCommon($id, $ref);
		if ($result > 0 && !empty($this->table_element_line)) {
			$this->fetchLines();
		}
		return $result;
	}

	/**
	 * Load list of objects in memory from the database.
	 *
	 * @param string $sortorder  Sort Order
	 * @param string $sortfield  Sort field
	 * @param int    $limit      limit
	 * @param int    $offset     Offset
	 * @param array  $filter     Filter array. Example array('field'=>'valueforlike', 'customurl'=>...)
	 * @param string $filtermode Filter mode (AND or OR)
	 *
	 * @return array|int                 int <0 if KO, array of pages if OK
	 */
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = [], $filtermode = 'AND')
	{
		global $conf;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$records = [];

		$sql = "SELECT ";
		$sql .= $this->getFieldList('t');
		$sql .= " FROM " . MAIN_DB_PREFIX . $this->table_element . " as t";
		if (isset($this->ismultientitymanaged) && $this->ismultientitymanaged == 1) {
			$sql .= " WHERE t.entity IN (" . getEntity($this->element) . ")";
		} else {
			$sql .= " WHERE 1 = 1";
		}
		// Manage filter
		$sqlwhere = [];
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				if ($key == 't.rowid') {
					$sqlwhere[] = $key . " = " . ((int) $value);
				} elseif (in_array($this->fields[$key]['type'], ['date', 'datetime', 'timestamp'])) {
					$sqlwhere[] = $key . " = '" . $this->db->idate($value) . "'";
				} elseif ($key == 'customsql') {
					$sqlwhere[] = $value;
				} elseif (strpos($value, '%') === false) {
					$sqlwhere[] = $key . " IN (" . $this->db->sanitize($this->db->escape($value)) . ")";
				} else {
					$sqlwhere[] = $key . " LIKE '%" . $this->db->escape($value) . "%'";
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= " AND (" . implode(" " . $filtermode . " ", $sqlwhere) . ")";
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= $this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			while ($i < ($limit ? min($limit, $num) : $num)) {
				$obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error ' . $this->db->lasterror();
			dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 * Update object into database
	 *
	 * @param User $user      User that modifies
	 * @param bool $notrigger false=launch triggers after, true=disable triggers
	 *
	 * @return int             <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = false)
	{
		if (empty($this->order_status_on_sync) || intval($this->order_status_on_sync) < 1) {
			$this->order_status_on_sync = null;
		}

		if (empty($this->order_status_delivered) || intval($this->order_status_delivered) < 1) {
			$this->order_status_delivered = null;
		}

		if((int)DOL_VERSION < 19){
			if (is_array($this->order_status_to_sync)) {
				$this->order_status_to_sync = implode(',', $this->order_status_to_sync);
			}

			if (is_array($this->order_status_delivered)) {
				$this->order_status_delivered = implode(',', $this->order_status_delivered);
			}
		}

		return $this->updateCommon($user, $notrigger);
	}

	/**
	 * Delete object in database
	 *
	 * @param User $user      User that deletes
	 * @param bool $notrigger false=launch triggers after, true=disable triggers
	 *
	 * @return int             <0 if KO, >0 if OK
	 */
	public function delete(User $user, $notrigger = false)
	{
		$this->clearWebServiceCache(false, true);

		$childTable = [
			'prestasync_address' => ['extrafield' => false, 'table' => 'prestasync_address'],
			'prestasync_carrier' => ['extrafield' => true, 'table' => 'prestasync_carrier'],
			'prestasync_customer' => ['extrafield' => false, 'table' => 'prestasync_customer'],
			'prestasync_order' => ['extrafield' => false, 'table' => 'prestasync_order'],
			'prestasync_payment' => ['extrafield' => true, 'table' => 'prestasync_payment'],
			'prestasync_product' => ['extrafield' => false, 'table' => 'prestasync_product'],
			'prestasync_supplier' => ['extrafield' => false, 'table' => 'prestasync_supplier'],
		];

		foreach ($childTable as $table => $tConf) {
			if (!empty($tConf['extrafield'])) {
				$this->db->query(
					'DELETE tex.* FROM ' . $this->db->prefix() . $table . '_extrafields tex '
					. 'WHERE fk_presta = ' . intval($this->id))
				. ' AND  tex.fk_object IN (SELECT t.rowid  FROM ' . $this->db->prefix() . $table . ' t WHERE t.fk_presta = ' . intval($this->id) . ' )';
			}

			$this->db->query('DELETE FROM ' . $this->db->prefix() . $table . ' WHERE fk_presta = ' . intval($this->id));
		}

		return $this->deleteCommon($user, $notrigger);
		//return $this->deleteCommon($user, $notrigger, 1);
	}

	/**
	 * @param $force set true to remove all for shop
	 *
	 * @return bool
	 */
	public function clearWebServiceCache($cacheId = false, $force = false)
	{
		$sql = 'DELETE FROM ' . $this->db->prefix() . 'prestasync_presta_query_cache WHERE fk_presta = ' . intval($this->id);
		if (!$force) {
			$sql .= " AND expire < '" . $this->db->idate(time()) . "' ";
		}

		if ($cacheId !== false) {
			$sql .= " AND cacheid = '" . $this->db->escape($cacheId) . "' ";
		}

		return boolval($this->db->query($sql));
	}

	/**
	 *  Delete a line of object in database
	 *
	 * @param User $user      User that delete
	 * @param int  $idline    Id of line to delete
	 * @param bool $notrigger false=launch triggers after, true=disable triggers
	 *
	 * @return int                >0 if OK, <0 if KO
	 */
	public function deleteLine(User $user, $idline, $notrigger = false)
	{
		if ($this->status < 0) {
			$this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
			return -2;
		}

		return $this->deleteLineCommon($user, $idline, $notrigger);
	}

	/**
	 *    Validate object
	 *
	 * @param User $user      User making status change
	 * @param int  $notrigger 1=Does not execute triggers, 0= execute triggers
	 *
	 * @return    int                        <=0 if OK, 0=Nothing done, >0 if KO
	 */
	public function validate($user, $notrigger = 0)
	{
		global $conf, $langs;

		require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';

		$error = 0;

		// Protection
		if ($this->status == self::STATUS_VALIDATED) {
			dol_syslog(get_class($this) . "::validate action abandonned: already validated", LOG_WARNING);
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->presta->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->presta->presta_advance->validate))))
		 {
		 $this->error='NotEnoughPermissions';
		 dol_syslog(get_class($this)."::valid ".$this->error, LOG_ERR);
		 return -1;
		 }*/

		$now = dol_now();

		$this->db->begin();

		// Define new ref
		if (!$error && (preg_match('/^[\(]?PROV/i', $this->ref) || empty($this->ref))) { // empty should not happened, but when it occurs, the test save life
			$num = $this->getNextNumRef();
		} else {
			$num = $this->ref;
		}
		$this->newref = $num;

		if (!empty($num)) {
			// Validate
			$sql = "UPDATE " . MAIN_DB_PREFIX . $this->table_element;
			$sql .= " SET ref = '" . $this->db->escape($num) . "',";
			$sql .= " status = " . self::STATUS_VALIDATED;
			if (!empty($this->fields['date_validation'])) {
				$sql .= ", date_validation = '" . $this->db->idate($now) . "'";
			}
			if (!empty($this->fields['fk_user_valid'])) {
				$sql .= ", fk_user_valid = " . ((int) $user->id);
			}
			$sql .= " WHERE rowid = " . ((int) $this->id);

			dol_syslog(get_class($this) . "::validate()", LOG_DEBUG);
			$resql = $this->db->query($sql);
			if (!$resql) {
				dol_print_error($this->db);
				$this->error = $this->db->lasterror();
				$error++;
			}

			if (!$error && !$notrigger) {
				// Call trigger
				$result = $this->call_trigger('PRESTA_VALIDATE', $user);
				if ($result < 0) {
					$error++;
				}
				// End call triggers
			}
		}

		if (!$error) {
			$this->oldref = $this->ref;

			// Rename directory if dir was a temporary ref
			if (preg_match('/^[\(]?PROV/i', $this->ref)) {
				// Now we rename also files into index
				$sql = 'UPDATE ' . MAIN_DB_PREFIX . "ecm_files set filename = CONCAT('" . $this->db->escape($this->newref) . "', SUBSTR(filename, " . (strlen($this->ref) + 1) . ")), filepath = 'presta/" . $this->db->escape($this->newref) . "'";
				$sql .= " WHERE filename LIKE '" . $this->db->escape($this->ref) . "%' AND filepath = 'presta/" . $this->db->escape($this->ref) . "' and entity = " . $conf->entity;
				$resql = $this->db->query($sql);
				if (!$resql) {
					$error++;
					$this->error = $this->db->lasterror();
				}

				// We rename directory ($this->ref = old ref, $num = new ref) in order not to lose the attachments
				$oldref = dol_sanitizeFileName($this->ref);
				$newref = dol_sanitizeFileName($num);
				$dirsource = $conf->prestasync->dir_output . '/presta/' . $oldref;
				$dirdest = $conf->prestasync->dir_output . '/presta/' . $newref;
				if (!$error && file_exists($dirsource)) {
					dol_syslog(get_class($this) . "::validate() rename dir " . $dirsource . " into " . $dirdest);

					if (@rename($dirsource, $dirdest)) {
						dol_syslog("Rename ok");
						// Rename docs starting with $oldref with $newref
						$listoffiles = dol_dir_list($conf->prestasync->dir_output . '/presta/' . $newref, 'files', 1, '^' . preg_quote($oldref, '/'));
						foreach ($listoffiles as $fileentry) {
							$dirsource = $fileentry['name'];
							$dirdest = preg_replace('/^' . preg_quote($oldref, '/') . '/', $newref, $dirsource);
							$dirsource = $fileentry['path'] . '/' . $dirsource;
							$dirdest = $fileentry['path'] . '/' . $dirdest;
							@rename($dirsource, $dirdest);
						}
					}
				}
			}
		}

		// Set new ref and current status
		if (!$error) {
			$this->ref = $num;
			$this->status = self::STATUS_VALIDATED;
		}

		if (!$error) {
			$this->db->commit();
			return 1;
		} else {
			$this->db->rollback();
			return -1;
		}
	}

	/**
	 *  Returns the reference to the following non used object depending on the active numbering module.
	 *
	 * @return string            Object free reference
	 */
	public function getNextNumRef()
	{
		global $langs, $conf;
		$langs->load("prestasync@prestasync");

		if (empty($conf->global->PRESTASYNC_PRESTA_ADDON)) {
			$conf->global->PRESTASYNC_PRESTA_ADDON = 'mod_presta_standard';
		}

		if (!empty($conf->global->PRESTASYNC_PRESTA_ADDON)) {
			$mybool = false;

			$file = $conf->global->PRESTASYNC_PRESTA_ADDON . ".php";
			$classname = $conf->global->PRESTASYNC_PRESTA_ADDON;

			// Include file with class
			$dirmodels = array_merge(['/'], (array) $conf->modules_parts['models']);
			foreach ($dirmodels as $reldir) {
				$dir = dol_buildpath($reldir . "core/modules/prestasync/");

				// Load file with numbering class (if found)
				$mybool |= @include_once $dir . $file;
			}

			if ($mybool === false) {
				dol_print_error('', "Failed to include file " . $file);
				return '';
			}

			if (class_exists($classname)) {
				$obj = new $classname();
				$numref = $obj->getNextValue($this);

				if ($numref != '' && $numref != '-1') {
					return $numref;
				} else {
					$this->error = $obj->error;
					//dol_print_error($this->db,get_class($this)."::getNextNumRef ".$obj->error);
					return "";
				}
			} else {
				print $langs->trans("Error") . " " . $langs->trans("ClassNotFound") . ' ' . $classname;
				return "";
			}
		} else {
			print $langs->trans("ErrorNumberingModuleNotSetup", $this->element);
			return "";
		}
	}

	/**
	 *    Set draft status
	 *
	 * @param User $user      Object user that modify
	 * @param int  $notrigger 1=Does not execute triggers, 0=Execute triggers
	 *
	 * @return    int                        <0 if KO, >0 if OK
	 */
	public function setDraft($user, $notrigger = 0)
	{
		// Protection
		if ($this->status <= self::STATUS_DRAFT) {
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->prestasync_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_DRAFT, $notrigger, 'PRESTA_UNVALIDATE');
	}

	/**
	 *    Set cancel status
	 *
	 * @param User $user      Object user that modify
	 * @param int  $notrigger 1=Does not execute triggers, 0=Execute triggers
	 *
	 * @return    int                        <0 if KO, 0=Nothing done, >0 if OK
	 */
	public function cancel($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_VALIDATED) {
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->prestasync_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_CANCELED, $notrigger, 'PRESTA_CANCEL');
	}

	/**
	 *    Set back to validated status
	 *
	 * @param User $user      Object user that modify
	 * @param int  $notrigger 1=Does not execute triggers, 0=Execute triggers
	 *
	 * @return    int                        <0 if KO, 0=Nothing done, >0 if OK
	 */
	public function reopen($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_CANCELED) {
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->prestasync->prestasync_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_VALIDATED, $notrigger, 'PRESTA_REOPEN');
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps

	/**
	 *  Return a link to the object card (with optionaly the picto)
	 *
	 * @param int    $withpicto             Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
	 * @param string $option                On what the link point to ('nolink', ...)
	 * @param int    $notooltip             1=Disable tooltip
	 * @param string $morecss               Add more css on link
	 * @param int    $save_lastsearch_value -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
	 *
	 * @return    string                              String with URL
	 */
	public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
	{
		global $conf, $langs, $hookmanager;

		if (!empty($conf->dol_no_mouse_hover)) {
			$notooltip = 1; // Force disable tooltips
		}

		$result = '';

		$label = img_picto('', $this->picto) . ' <u>' . $langs->trans("Presta") . '</u>';
		if (isset($this->status)) {
			$label .= ' ' . $this->getLibStatut(5);
		}
		$label .= '<br>';
		$label .= '<b>' . $langs->trans('Ref') . ':</b> ' . $this->ref . '<br/>';
		$label .= $this->label . '<br/>';
		$label .= $this->shop_url;

		$url = dol_buildpath('/prestasync/presta_card.php', 1) . '?id=' . $this->id;

		if ($option != 'nolink') {
			// Add param to save lastsearch_values or not
			$add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
			if ($save_lastsearch_value == -1 && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) {
				$add_save_lastsearch_values = 1;
			}
			if ($url && $add_save_lastsearch_values) {
				$url .= '&save_lastsearch_values=1';
			}
		}

		$linkclose = '';
		if (empty($notooltip)) {
			if (!empty($conf->global->MAIN_OPTIMIZEFORTEXTBROWSER)) {
				$label = $langs->trans("ShowPresta");
				$linkclose .= ' alt="' . dol_escape_htmltag($label, 1) . '"';
			}
			$linkclose .= ' title="' . dol_escape_htmltag($label, 1) . '"';
			$linkclose .= ' class="classfortooltip' . ($morecss ? ' ' . $morecss : '') . '"';
		} else {
			$linkclose = ($morecss ? ' class="' . $morecss . '"' : '');
		}

		if ($option == 'nolink' || empty($url)) {
			$linkstart = '<span';
		} else {
			$linkstart = '<a href="' . $url . '"';
		}
		$linkstart .= $linkclose . '>';
		if ($option == 'nolink' || empty($url)) {
			$linkend = '</span>';
		} else {
			$linkend = '</a>';
		}

		$result .= $linkstart;

		if (empty($this->showphoto_on_popup)) {
			if ($withpicto) {
				$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="' . (($withpicto != 2) ? 'paddingright ' : '') . 'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
			}
		} else {
			if ($withpicto) {
				require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';

				[$class, $module] = explode('@', $this->picto);
				$upload_dir = $conf->$module->multidir_output[$conf->entity] . "/$class/" . dol_sanitizeFileName($this->ref);
				$filearray = dol_dir_list($upload_dir, "files");
				$filename = $filearray[0]['name'];
				if (!empty($filename)) {
					$pospoint = strpos($filearray[0]['name'], '.');

					$pathtophoto = $class . '/' . $this->ref . '/thumbs/' . substr($filename, 0, $pospoint) . '_mini' . substr($filename, $pospoint);
					if (empty($conf->global->{strtoupper($module . '_' . $class) . '_FORMATLISTPHOTOSASUSERS'})) {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref"><img class="photo' . $module . '" alt="No photo" border="0" src="' . DOL_URL_ROOT . '/viewimage.php?modulepart=' . $module . '&entity=' . $conf->entity . '&file=' . urlencode($pathtophoto) . '"></div></div>';
					} else {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><img class="photouserphoto userphoto" alt="No photo" border="0" src="' . DOL_URL_ROOT . '/viewimage.php?modulepart=' . $module . '&entity=' . $conf->entity . '&file=' . urlencode($pathtophoto) . '"></div>';
					}

					$result .= '</div>';
				} else {
					$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="' . (($withpicto != 2) ? 'paddingright ' : '') . 'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
				}
			}
		}

		if ($withpicto != 2) {
			$result .= $this->ref;
		}

		$result .= $linkend;
		//if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

		global $action, $hookmanager;
		$hookmanager->initHooks(['prestadao']);
		$parameters = ['id' => $this->id, 'getnomurl' => &$result];
		$reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) {
			$result = $hookmanager->resPrint;
		} else {
			$result .= $hookmanager->resPrint;
		}

		return $result;
	}

	/**
	 *  Return the label of the status
	 *
	 * @param int $mode 0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *
	 * @return    string                   Label of status
	 */
	public function getLibStatut($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	/**
	 *  Return the status
	 *
	 * @param int $status Id status
	 * @param int $mode   0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *
	 * @return string                   Label of status
	 */
	public function LibStatut($status, $mode = 0)
	{
		// phpcs:enable
		if (empty($this->labelStatus) || empty($this->labelStatusShort)) {
			global $langs;
			//$langs->load("prestasync@prestasync");
			$this->labelStatus[self::STATUS_DRAFT] = $langs->transnoentitiesnoconv('Draft');
			$this->labelStatus[self::STATUS_VALIDATED] = $langs->transnoentitiesnoconv('Enabled');
			$this->labelStatus[self::STATUS_CANCELED] = $langs->transnoentitiesnoconv('Disabled');
			$this->labelStatusShort[self::STATUS_DRAFT] = $langs->transnoentitiesnoconv('Draft');
			$this->labelStatusShort[self::STATUS_VALIDATED] = $langs->transnoentitiesnoconv('Enabled');
			$this->labelStatusShort[self::STATUS_CANCELED] = $langs->transnoentitiesnoconv('Disabled');
		}

		$statusType = 'status' . $status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		if ($status == self::STATUS_CANCELED) {
			$statusType = 'status6';
		}

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
	}

	/**
	 *  Return the label of the status
	 *
	 * @param int $mode 0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *
	 * @return    string                   Label of status
	 */
	public function getLabelStatus($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	/**
	 *    Load the info information in the object
	 *
	 * @param int $id Id of object
	 *
	 * @return    void
	 */
	public function info($id)
	{
		$sql = "SELECT rowid,";
		$sql .= " date_creation as datec, tms as datem,";
		$sql .= " fk_user_creat, fk_user_modif";
		$sql .= " FROM " . MAIN_DB_PREFIX . $this->table_element . " as t";
		$sql .= " WHERE t.rowid = " . ((int) $id);

		$result = $this->db->query($sql);
		if ($result) {
			if ($this->db->num_rows($result)) {
				$obj = $this->db->fetch_object($result);

				$this->id = $obj->rowid;

				$this->user_creation_id = $obj->fk_user_creat;
				$this->user_modification_id = $obj->fk_user_modif;
				if (!empty($obj->fk_user_valid)) {
					$this->user_validation_id = $obj->fk_user_valid;
				}
				$this->date_creation = $this->db->jdate($obj->datec);
				$this->date_modification = empty($obj->datem) ? '' : $this->db->jdate($obj->datem);
				if (!empty($obj->datev)) {
					$this->date_validation = empty($obj->datev) ? '' : $this->db->jdate($obj->datev);
				}
			}

			$this->db->free($result);
		} else {
			dol_print_error($this->db);
		}
	}

	/**
	 * Initialise object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return void
	 */
	public function initAsSpecimen()
	{
		// Set here init that are not commonf fields
		// $this->property1 = ...
		// $this->property2 = ...

		$this->initAsSpecimenCommon();
	}

	/**
	 *    Create an array of lines
	 *
	 * @return array|int        array of lines if OK, <0 if KO
	 */
	public function getLinesArray()
	{
		$this->lines = [];

		$objectline = new PrestaLine($this->db);
		$result = $objectline->fetchAll('ASC', 'position', 0, 0, ['customsql' => 'fk_presta = ' . ((int) $this->id)]);

		if (is_numeric($result)) {
			$this->error = $objectline->error;
			$this->errors = $objectline->errors;
			return $result;
		} else {
			$this->lines = $result;
			return $this->lines;
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 * @param string     $modele      Force template to use ('' to not force)
	 * @param Translate  $outputlangs objet lang a utiliser pour traduction
	 * @param int        $hidedetails Hide details of lines
	 * @param int        $hidedesc    Hide description
	 * @param int        $hideref     Hide ref
	 * @param null|array $moreparams  Array to provide more information
	 *
	 * @return     int                        0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	{
		global $conf, $langs;

		$result = 0;
		$includedocgeneration = 0;

		$langs->load("prestasync@prestasync");

		if (!dol_strlen($modele)) {
			$modele = 'standard_presta';

			if (!empty($this->model_pdf)) {
				$modele = $this->model_pdf;
			} elseif (!empty($conf->global->PRESTA_ADDON_PDF)) {
				$modele = $conf->global->PRESTA_ADDON_PDF;
			}
		}

		$modelpath = "core/modules/prestasync/doc/";

		if ($includedocgeneration && !empty($modele)) {
			$result = $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
		}

		return $result;
	}

	/**
	 * Action executed by scheduler
	 * CAN BE A CRON TASK. In such a case, parameters come from the schedule job setup field 'Parameters'
	 * Use public function doScheduledJob($param1, $param2, ...) to get parameters
	 *
	 * @return    int            0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
	 */
	public function doScheduledJob()
	{
		global $conf, $langs;

		//$conf->global->SYSLOG_FILE = 'DOL_DATA_ROOT/dolibarr_mydedicatedlofile.log';

		$error = 0;
		$this->output = '';
		$this->error = '';

		dol_syslog(__METHOD__, LOG_DEBUG);

		$now = dol_now();

		$this->db->begin();

		// ...

		$this->db->commit();

		return $error;
	}

	/**
	 * @param $resource
	 *
	 * @return bool raw
	 */
	public function getFileFromWebService($resource)
	{
		if (!$resource) {
			return false;
		}

		require_once __DIR__ . '/prestaWebService.class.php';

		// Here we set the option array for the Webservice
		$opt = [];
		$opt['resource'] = $resource;

		// Here we make the WebService Call
		try {
			$webService = new PrestaWebservice($this->shop_url, $this->api_key, false);

			// Call
			$result = $webService->getFile($opt);
			if ($result === false) {
				return false;
			}

			return $result;
		} catch (PrestaShopWebserviceException $e) {
			// Here we are dealing with errors
			$this->convertExeptionMessageToErrors($e);
			return false;
		}
	}

	protected function convertExeptionMessageToErrors(PrestaShopWebserviceException $e)
	{
		$trace = $e->getTrace();
		if (isset($trace[0]['args']) && $trace[0]['args'][0] == 404) $this->errors[] = 'Bad id or url';
		else if (isset($trace[0]['args']) && $trace[0]['args'][0] == 401) $this->errors[] = 'Bad auth key';
		else  $this->errors[] = 'Prestashop webService error : ' . $e->getMessage();
	}

	/**
	 * a simple way to send data to prestashop webService
	 *
	 * @param       $resource
	 * @param array $data
	 *
	 * @return bool
	 */
	public function addToWebService($resource, $data, $moreUrl = '')
	{
		if (!$resource) {
			return false;
		}

		/** Because Prestashop web servir use xml */
		// creating object of SimpleXMLElement
		$xml_data = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8" ?><prestashop xmlns:xlink="http://www.w3.org/1999/xlink"></prestashop>');
		// function call to convert array to xml

		$this->arrayToSimpleXml([$resource => $data], $xml_data);

		require_once __DIR__ . '/prestaWebService.class.php';

		// Here we make the WebService Call
		try {
			// Here we set the option array for the Webservice
			$opt = [];
			$opt['resource'] = $resource . ($moreUrl ? '?' . $moreUrl : '');
			$opt['postXml'] = $xml_data->asXML();

			$webService = new PrestaWebservice($this->shop_url, $this->api_key, false);

			// Call
			$result = $webService->add($opt);

			// TODO return bool
			return $result;
		} catch (PrestaShopWebserviceException $e) {
			// Here we are dealing with errors
			$this->convertExeptionMessageToErrors($e);
			return false;
		}
	}

	/**
	 * function defination to convert array to xml
	 *
	 * @param                  $data
	 * @param SimpleXMLElement $xml_data
	 */
	public function arrayToSimpleXml($data, &$xml_data)
	{
		foreach ($data as $key => $value) {
			if($key == 'language' && is_array($value)) {
				// Multilanguage detected
				foreach ($value as $langId => $lVal){
					$subnode = $xml_data->addChild($key, htmlspecialchars($lVal));
					$subnode->addAttribute('id', $langId);
				}
			}
			elseif (is_array($value)) {
				if (is_numeric($key)) {
					$key = 'item' . $key; //dealing with <0/>..<n/> issues
				}
				$subnode = $xml_data->addChild($key);
				$this->arrayToSimpleXml($value, $subnode);
			} else {
				$xml_data->addChild($key, htmlspecialchars($value));
			}
		}
	}

	/**
	 * a simple way to send data to prestashop webService
	 *
	 * @param       $resource
	 * @param array $data
	 *
	 * @return bool
	 */
	public function updateToWebService($resource, $data, $moreOpt = [], $moreUrl = '', $method = 'PATCH')
	{
		if (!$resource) {
			return false;
		}

		/** Because Prestashop web service use xml */
		// creating object of SimpleXMLElement
		$xml_data = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8" ?><prestashop xmlns:xlink="http://www.w3.org/1999/xlink"></prestashop>');
		// function call to convert array to xml

		$this->arrayToSimpleXml([$resource => $data], $xml_data);

		require_once __DIR__ . '/prestaWebService.class.php';

		// Here we make the WebService Call
		try {
			// Here we set the option array for the Webservice
			$opt = [];
			$opt['resource'] = $resource . ($moreUrl ? '?' . $moreUrl : '');
			$opt['putXml'] = $xml_data->asXML();

			if (!empty($moreOpt)) {
				foreach ($moreOpt as $mk => $mv) {
					$opt[$mk] = $mv;
				}
			}

			$webService = new PrestaWebservice($this->shop_url, $this->api_key, false);

			// Call
//			$method = (int)$this->shop_version < 8 ? 'PUT' : 'PATCH'; //ATTENTION PUT remplace TOUT !!! il est préférable de preparer la requette en amont en ayant conscience de ça

			$result = $webService->edit($opt,$method);
			// TODO return bool
			return $result;
		} catch (PrestaShopWebserviceException $e) {
			// Here we are dealing with errors
			$this->convertExeptionMessageToErrors($e);
			return false;
		}
	}

	/**
	 * return array indexed array of all items of a given resource
	 *
	 * @param $resource
	 *
	 * @return false|array
	 */
	public function getAllResources($resource)
	{
		if (!in_array($resource, ['order_states', 'languages'])) {
			return false;
		}

		$objs = $this->getFromWebService($resource, [], [], [], false, 0, [], true);

		$list = [];
		if (!empty($objs) && is_array($objs)) {
			foreach ($objs as $obj) {
				$list[$obj->id] = $obj;
			}
		}

		return $list;
	}

	/**
	 * @param bool       $resource
	 * @param array      $display
	 * @param array      $sort
	 * @param array      $filters
	 *                             [
	 *                             'operator' => the query operator : or | interval | begin | end | contains | literal
	 *                             'search' => the value to search
	 *                             ]
	 * @param int|string $limit
	 * @param int        $page
	 * @param array      $opt
	 * @param bool       $useCache to use only for statics elements like status etc....
	 * @param int        $cacheExpire
	 *
	 * @return bool|stdClass|array
	 */
	public function getFromWebService($resource, $display = [], $sort = [], $filters = [], $limit = 25, $page = 0, $opt = [], $useCache = false, $cacheExpire = 600)
	{
		require_once __DIR__ . '/prestaWebService.class.php';

		// Here we set the option array for the Webservice
		$opt['resource'] = $resource;

		if ($this->shop_id > 0) {
			$opt['id_shop'] = (int) $this->shop_id;
		}

		if (empty($opt['language'])) {
			$opt['language'] = $this->language;
		}

		$opt['display'] = 'full';
		if (!empty($display) && is_array($display)) {
			$opt['display'] = '[' . implode(',', $display) . ']';
		}

		if ($this->shop_version == '1.6') {
			$opt['ws_key'] = $this->api_key;
		}

		if (!empty($filters) && is_array($filters)) {
			foreach ($filters as $field => $filter) {
				if (in_array($field, ['date_add'])) {
					$opt['date'] = 1;
				}

				if (!is_array($filter)) {
					$opt['filter'][$field] = $filter;
				} elseif (isset($filter['operator'])) {
					if ($filter['operator'] == 'or' && isset($filter['search'])) {
						if (empty($filter['search']) || !is_array($filter['search'])) {
							$this->errors[] = 'Search value error for ' . $field;
							return false;
						}

						if (count($filter['search']) > 1) {
							$opt['filter'][$field] = '[' . $this->cleanSearchString(implode('|', $filter['search'])) . ']';
						} else {
							$opt['filter'][$field] = $this->cleanSearchString(reset($filter['search']));
						}
					} elseif ($filter['operator'] == 'interval') {
						if (!isset($filter['min']) || !isset($filter['max'])) {
							$this->errors[] = 'Search value error for ' . $field;
							return false;
						}

						$opt['filter'][$field] = '[' . $filter['min'] . ',' . $filter['max'] . ']';
					} elseif ($filter['operator'] == 'begin' && isset($filter['search'])) {
						$opt['filter'][$field] = '%[' . $filter['search'] . ']';
					} elseif ($filter['operator'] == 'end' && isset($filter['search'])) {
						$opt['filter'][$field] = '[' . $filter['search'] . ']%';
					} elseif ($filter['operator'] == 'contains' && isset($filter['search'])) {
						$opt['filter'][$field] = '%[' . $filter['search'] . ']%';
					} elseif ($filter['operator'] == 'literal' && isset($filter['search'])) {
						$opt['filter'][$field] = '[' . $filter['search'] . ']';
					} elseif ($filter['operator'] == 'natural' && isset($filter['search'])) {
						$searchExplode = explode(' ', $filter['search']);
						$searchExplode = array_diff($searchExplode, [""]);
						if (!empty($searchExplode) && count($searchExplode) > 1) {
							$opt['filter'][$field] = [];
							foreach ($searchExplode as $sk => $sv) {
								$opt['filter'][$field][] = '%[' . $this->cleanSearchString($sv) . ']%';
							}
						} else {
							$opt['filter'][$field] = '%[' . $this->cleanSearchString($filter['search']) . ']%';
						}
					} else {
						$this->errors[] = 'Search value error for ' . $field;
						return false;
					}
				} else {
					$opt['filter'][$field] = '[' . $this->cleanSearchString(implode('|', $filter)) . ']';
				}
			}
		}

		if (!empty($sort) && is_array($sort)) {
			$sortStrings = [];
			foreach ($sort as $skey => $sorder) {
				if (in_array($skey, ['date_add'])) {
					$opt['date'] = 1;
				}

				$sorder = strtoupper($sorder);
				if (!in_array($sorder, ['DESC', 'ASC'])) {
					$sorder = 'DESC';
				}
				$sortStrings[] = $skey . '_' . $sorder;
			}

			$opt['sort'] = '[' . implode(',', $sortStrings) . ']';
		}

		if ($limit !== false && strpos($limit, ',') === false) {
			$opt['limit'] = 25;
			if ($limit > 0) {
				$opt['limit'] = intval($limit);
			}

			if (!empty($page)) {
				$opt['limit'] = intval($page * intval($limit) - 1) . ',' . $opt['limit']; // 0 is the first result
			}
		}

		$cacheId = md5(json_encode($opt));
		if (!$useCache) {
			$this->clearWebServiceCache($cacheId, true);
		}

		if ($useCache) {
			$cacheObj = $this->getWebServiceCache($resource, $cacheId);
			if ($cacheObj) {
				return $cacheObj->result;
			}
		}

		// Here we make the WebService Call
		try {
			$webService = new PrestaWebservice($this->shop_url, $this->api_key, false);

			// Call
			$result = $webService->getJson($opt);
			if ($result && isset($result->$resource)) {
				$result = $result->$resource;
			}

			if ($useCache && $result !== false) {
				$this->setWebServiceCache($resource, $cacheId, $result, $cacheExpire);
			}

			if ($result === false) {
				return false;
			}

			if (empty($this->shop_version)) {
				$this->shop_version = $webService->getPrestaVersion();
			}

			return $result;
		} catch (PrestaShopWebserviceException $e) {
			// Here we are dealing with errors
			$trace = $e->getTrace();
			if (isset($trace[0]) && isset($trace[0]['args']) && isset($trace[0]['args'][0]) && $trace[0]['args'][0] == 404) $this->errors[] = 'Bad ID';
			else if (isset($trace[0]) && isset($trace[0]['args']) && isset($trace[0]['args'][0]) && $trace[0]['args'][0] == 401) $this->errors[] = 'Bad auth key';
			else  $this->errors[] = 'Prestashop webService error : ' . $e->getMessage();
			return false;
		}
	}

	public function cleanSearchString($subject)
	{
		return str_replace(['%', '[', ']'], '', $subject);
	}

	public function getWebServiceCache($resource, $cacheId)
	{
		if (!$cacheId) {
			return false;
		}

		$sql = 'SELECT rowid, result,resource, cacheid, fk_presta, tms, expire FROM ' . $this->db->prefix() . 'prestasync_presta_query_cache WHERE fk_presta = ' . intval($this->id);
		$sql .= " AND cacheid = '" . $this->db->escape($cacheId) . "' ";
		$sql .= " AND expire >= '" . $this->db->idate(time()) . "' ";
		$sql .= " AND resource = '" . $this->db->escape($resource) . "'  ";

		$obj = $this->db->getRow($sql);
		if ($obj === false) {
			$this->error = $this->db->error();
			return false;
		}

		if (!$obj) {
			return false;
		}

		$obj->tms = $this->db->jdate($obj->tms);
		$obj->result = json_decode($obj->result);

		return $obj;
	}

	/**
	 * @param $cacheId
	 * @param $result
	 * @param $expire time in seconds, use false to use default
	 *
	 * @return bool|resource
	 */
	public function setWebServiceCache($resource, $cacheId, $result, $expire = false)
	{
		if (!$cacheId) {
			return false;
		}

		if (!$this->clearWebServiceCache($cacheId, true)) {
			return false;
		}

		$expireTime = time() + 86400 * 30;
		if ($expire) {
			$expireTime = time() + intval($expire);
		}

		// Insert into database
		$sql = "INSERT INTO " . $this->db->prefix() . "prestasync_presta_query_cache";
		$sql .= " ( result, cacheid, fk_presta,resource, tms, expire) ";
		$sql .= " VALUES ";
		$sql .= " ( '" . $this->db->escape(json_encode($result)) . "', '" . $this->db->escape($cacheId) . "' , " . intval($this->id) . ", '" . $this->db->escape($resource) . "' , '" . $this->db->idate(time()) . "', '" . $this->db->idate($expireTime) . "' )";

		$result = $this->db->query($sql);
		if (!$result) {
			$this->error = $this->db->error();
			return false;
		}

		return true;
	}

	/**
	 * genenerate page url
	 * will be usefull for version url compatibility
	 *
	 * @param $page
	 *
	 * @return mixed
	 */
	public function getPrestaAdminUrl($page = false, $params = [])
	{
		$url = rtrim($this->shop_admin_url, '/') . '/';

		if ($page == 'cart') {
			if (empty($params['id']) && !empty($params['id_cart'])) {
				$params['id'] = $params['id_cart'];
			}

			if ($this->shop_version == '1.6') {
				return $url . 'index.php?controller=AdminCarts&id_cart=' . $params['id'];
			} else {
				return $url . 'index.php/sell/orders/carts/' . $params['id'] . '/view';
			}
		}

		if ($page == 'order') {
			return $url . 'index.php/sell/orders/' . $params['id'] . '/view';
		}

		return $url;
	}

	/**
	 * @return string
	 */
	public function generateWebHookToken()
	{
		if (empty($this->api_key) || empty($this->shop_id)) {
			return false;
		}

		$webHookToken = $this->api_key . $this->shop_id . getDolGlobalString('PRESTASYNC_GLOBAL_TOKEN');
		return md5($webHookToken);
	}

	/**
	 * Return HTML string to put an input field into a page
	 * Code very similar with showInputField of extra fields
	 *
	 * @param ?array{type:string,label:string,enabled:int<0,2>|string,position:int,notnull?:int,visible:int,noteditable?:int,default?:string,index?:int,foreignkey?:string,searchall?:int,isameasure?:int,css?:string,csslist?:string,help?:string,showoncombobox?:int,disabled?:int,arrayofkeyval?:array<int,string>,comment?:string}    $val    Array of properties for field to show (used only if ->fields not defined)
	 *                                                                                                                                                                                                                                                                                                                                          Array of properties of field to show
	 * @param string          $key                                                                                                                                                                                                                                                                                                              Key of attribute
	 * @param string|string[] $value                                                                                                                                                                                                                                                                                                            Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value, for array type must be array)
	 * @param string          $moreparam                                                                                                                                                                                                                                                                                                        To add more parameters on html input tag
	 * @param string          $keysuffix                                                                                                                                                                                                                                                                                                        Suffix string to add into name and id of field (can be used to avoid duplicate names)
	 * @param string          $keyprefix                                                                                                                                                                                                                                                                                                        Prefix string to add into name and id of field (can be used to avoid duplicate names)
	 * @param string|int      $morecss                                                                                                                                                                                                                                                                                                          Value for css to define style/length of field. May also be a numeric.
	 * @param int<0,1>        $nonewbutton   Force to not show the new button on field that are links to object
	 *
	 * @return string
	 */
	public function showInputField($val, $key, $value, $moreparam = '', $keysuffix = '', $keyprefix = '', $morecss = 0, $nonewbutton = 0)
	{
		global $conf, $langs, $form;

		if ($key == 'order_status_to_sync' || $key == 'order_status_on_sync' || $key == 'order_status_delivered') {
			require_once __DIR__ . '/prestaOrder.class.php';
			$prestaOrder = new PrestaOrder($this);

			// load status list from prestashop
			$this->fields[$key]['arrayofkeyval'] = $prestaOrder->getSimpleListOfAvailableOrderStatus();

			if((int)DOL_VERSION < 19 && in_array($key,  ['order_status_to_sync', 'order_status_delivered'])){
				$value_arr = explode(',', $value);
				return  $form->multiselectarray($keyprefix.$key.$keysuffix, (empty($this->fields[$key]['arrayofkeyval']) ?null:$this->fields[$key]['arrayofkeyval']), $value_arr, '', 0, $morecss, 0, '100%');
			}
		}

		if ($key == 'language' && (empty($this->fields[$key]['arrayofkeyval']) || count($this->fields[$key]['arrayofkeyval']) == 1) && $this->restApiIsSet()) {
			$pListLangs = $this->getAllPrestaLanguages();
			if ($pListLangs) {
				$this->fields[$key]['arrayofkeyval'] = [];
				foreach ($pListLangs as $pLang) {
					$this->fields[$key]['arrayofkeyval'][$pLang->id] = $pLang->name;
				}
				$val['arrayofkeyval'] = $this->fields[$key]['arrayofkeyval'];
			}
		}

		if ($key == 'shop_id' && (empty($this->fields[$key]['arrayofkeyval']) || count($this->fields[$key]['arrayofkeyval']) == 1) && $this->restApiIsSet()) {
			$pListShops = $this->getAllPrestaShops();
			if ($pListShops) {
				$this->fields[$key]['arrayofkeyval'] = [];
				foreach ($pListShops as $pShops) {
					$this->fields[$key]['arrayofkeyval'][$pShops->id] = $pShops->name;
				}
				$val['arrayofkeyval'] = $this->fields[$key]['arrayofkeyval'];
			}
		}

		return parent::showInputField($val, $key, $value, $moreparam, $keysuffix, $keyprefix, $morecss, $nonewbutton);
	}

	/**
	 * @return bool
	 */
	public function restApiIsSet()
	{
		if (empty($this->shop_url) || empty($this->api_key)) {
			return false;
		}

		return true;
	}

	/**
	 * @param bool $active
	 *
	 * @return array ex [
	 * {
	 * "id": 1,
	 * "name": "Français (French)",
	 * "iso_code": "fr",
	 * "locale": "fr-FR",
	 * "language_code": "fr",
	 * "active": 1,
	 * "is_rtl": 0,
	 * "date_format_lite": "d/m/Y",
	 * "date_format_full": "d/m/Y H:i:s"
	 * }
	 * ]
	 */
	public function getAllPrestaLanguages($active = true)
	{
		$filter = [];
		if ($active) {
			$filter['active'] = 1;
		}
		$objs = $this->getFromWebService('languages', [], [], $filter);
		$list = [];
		if (!empty($objs) && is_array($objs)) {
			foreach ($objs as $obj) {
				$list[$obj->id] = $obj;
			}
		}

		return $list;
	}

	/**
	 * @param bool $active
	 *
	 * @return array ex [
	 * {
	 * "id": 1,
	 * "id_shop_group": 1,
	 * "id_category": 2,
	 * "active": 1,
	 * "deleted": 0,
	 * "name": "Shop name",
	 * "color": "",
	 * "theme_name": "default"
	 * }
	 * ]
	 */
	public function getAllPrestaShops($active = true, $returnFields = ['id', 'name'])
	{
		$filter = [];
		if ($active) {
			$filter['active'] = 1;
		}
		$objs = $this->getFromWebService('shops', $returnFields, [], $filter);

		$list = [];
		if (!empty($objs) && is_array($objs)) {
			foreach ($objs as $obj) {
				$list[$obj->id] = $obj;
			}
		}

		return $list;
	}


	public function validateAllFields()
	{
		foreach ($this->fields as $key => $val) {
			if (!empty($val['validate']) && is_callable(array($this, 'validateField'))) {
				$this->validateField($this->fields, $key, $this->$key);
			}
		}
	}


	/**
	 * Return validation test result for a field
	 *
	 * @param  array   $fields	       		Array of properties of field to show
	 * @param  string  $fieldKey            Key of attribute
	 * @param  string  $fieldValue          value of attribute
	 * @return bool return false if fail true on success, see $this->error for error message
	 */
	public function validateField($fields, $fieldKey, $fieldValue)
	{
		global $langs;

		if (!class_exists('Validate')) {
			require_once DOL_DOCUMENT_ROOT . '/core/class/validate.class.php';
		}

		$this->clearFieldError($fieldKey);

		if (!isset($fields[$fieldKey])) {
			$this->setFieldError($fieldKey, $langs->trans('FieldNotFoundInObject'));
			return false;
		}

		$val = $fields[$fieldKey];

		if((int)DOL_VERSION < 19 && in_array($fieldKey,  ['order_status_to_sync', 'order_status_delivered'])){
			// PATCH la V18 de dolibarr ne gère pas les multiselects
			return true;
		}

		return parent::validateField($fields, $fieldKey, $fieldValue);
	}

	/**
	 * Return HTML string to show a field into a page
	 * Code very similar with showOutputField of extra fields
	 *
	 * @param array{type:string,label:string,enabled:int<0,2>|string,position:int,notnull?:int,visible:int,noteditable?:int,default?:string,index?:int,foreignkey?:string,searchall?:int,isameasure?:int,css?:string,csslist?:string,help?:string,showoncombobox?:int,disabled?:int,arrayofkeyval?:array<int,string>,comment?:string}    $val    Array of properties of field to show
	 * @param string $key       Key of attribute
	 * @param string $value     Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
	 * @param string $moreparam To add more parameters on html tag
	 * @param string $keysuffix Prefix string to add into name and id of field (can be used to avoid duplicate names)
	 * @param string $keyprefix Suffix string to add into name and id of field (can be used to avoid duplicate names)
	 * @param mixed  $morecss   Value for CSS to use (Old usage: May also be a numeric to define a size).
	 *
	 * @return string
	 */
	public function showOutputField($val, $key, $value, $moreparam = '', $keysuffix = '', $keyprefix = '', $morecss = '')
	{
		/**
		 * Display error message for field
		 */
		$errorAppend = '';
		if($this->forceCheckErrorsOnOutputFields){

			$this->fields['language']['validate'] = 1;
			$this->fields['language']['required'] = 1;
			if((int)$this->language == 0){
				$this->language = null;
			}

			$this->fields['shop_id']['validate'] = 1;
			$this->fields['shop_id']['required'] = 1;

			$this->fields['shop_version']['validate'] = 1;
			$this->fields['shop_version']['required'] = 1;
			if((int)$this->shop_version == 0){
				$this->shop_version = null;
			}


			$this->validateField($this->fields, $key, $value);
			$fieldValidationErrorMsg = $this->getFieldError($key);
			if (!empty($fieldValidationErrorMsg) && function_exists('getFieldErrorIcon')) {
				$errorAppend .= ' '.getFieldErrorIcon($fieldValidationErrorMsg);
			}
		}


		/**
		 * Display fields
		 */
		if ($key == 'order_status_delivered' || $key == 'order_status_to_sync') {
			require_once __DIR__ . '/prestaOrder.class.php';
			$prestaOrder = new PrestaOrder($this);
			$out = '';

			$statusList = false;
			if ($key == 'order_status_delivered') {
				$statusList = $this->getOrderStatusDelivred();
			} else if ($key == 'order_status_to_sync') {
				$statusList = $this->getOrderStatusToSync();
			}

			if (!empty($statusList)) {
				foreach ($statusList as $statusItem) {
					$out .= $prestaOrder->getPrestaOrderStatusBadge($statusItem, true) . ' ';
				}
			}

			return $out.$errorAppend;
		}

		if ($key == 'language' && empty($this->fields[$key]['arrayofkeyval'])) {
			$pListLangs = $this->getAllPrestaLanguages();
			if ($pListLangs) {
				$this->fields[$key]['arrayofkeyval'] = [];
				foreach ($pListLangs as $pLang) {
					$this->fields[$key]['arrayofkeyval'][$pLang->id] = $pLang->name;
				}
				$val['arrayofkeyval'] = $this->fields[$key]['arrayofkeyval'];
			}
		}

		if ($key == 'shop_id' && empty($this->fields[$key]['arrayofkeyval']) && $this->restApiIsSet()) {
			$pListShops = $this->getAllPrestaShops();
			if ($pListShops) {
				$this->fields[$key]['arrayofkeyval'] = [];
				foreach ($pListShops as $pShops) {
					$this->fields[$key]['arrayofkeyval'][$pShops->id] = $pShops->name;
				}
				$val['arrayofkeyval'] = $this->fields[$key]['arrayofkeyval'];
			}
		}

		if ($key == 'order_status_on_sync') {
			require_once __DIR__ . '/prestaOrder.class.php';
			$prestaOrder = new PrestaOrder($this);
			return $prestaOrder->getPrestaOrderStatusBadge($this->$key).$errorAppend;
		}

		return parent::showOutputField($val, $key, $value, $moreparam, $keysuffix, $keyprefix, $morecss).$errorAppend;
	}

	/**
	 * @return string[]
	 */
	public function getOrderStatusDelivred()
	{
		if (!empty($this->order_status_delivered)) {
			$statusList = explode(',', $this->order_status_delivered);
			if (!empty($statusList) && is_array($statusList)) {
				return $statusList;
			}
		}

		return [];
	}

	/**
	 * @return string[]
	 */
	public function getOrderStatusToSync()
	{
		if (!empty($this->order_status_to_sync)) {
			$statusList = explode(',', $this->order_status_to_sync);
			if (!empty($statusList) && is_array($statusList)) {
				return $statusList;
			}
		}

		return [];
	}
}

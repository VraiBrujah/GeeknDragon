<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaError.trait.php';
require_once __DIR__ . '/presta.class.php';

class PrestaCommonObject
{

	use PrestaErrors;

	const STATUS_LINK_ERROR = 0;
	const STATUS_LINK_NOT_FETCHED = 1;
	const STATUS_NOT_LINKED = 2;
	const STATUS_LINKED = 3;

	/**
	 * @var Presta $presta
	 */
	public $presta;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = '';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string|false (use false if this prestahop resourse is not
	 */
	public $doliElement = false;

	/**
	 * @var null  if null : not fetched yet, 0 : i0 : not sync  , > 0 : if fetched and false on error
	 */
	public $doliElementId = null;

	/**
	 * the Dolibarr linked object
	 *
	 * @var CommonObject $doliObject ;
	 */
	public $doliObject;

	public $linkObject;

	/**
	 * The Prestashop resource id
	 *
	 * @var string
	 */
	public $id = false;

	public $fields = [
		'id' => [
			'labelKey' => 'PrestaShopId',
		],
	];

	/**
	 * @param Presta $presta
	 */
	public function __construct(Presta $presta)
	{
		global $langs;

		$langs->load('prestasync@prestasync');
		$this->presta = $presta;

		foreach ($this->fields as $k => $v) {
			if (!isset($this->fields[$k]['type'])) {
				$this->fields[$k]['type'] = 'varchar(500)';
			}

			if (!isset($this->fields[$k]['enabled'])) {
				$this->fields[$k]['enabled'] = 1;
			}

			if (!isset($this->fields[$k]['visible'])) {
				$this->fields[$k]['visible'] = 1;
			}

			if (!isset($this->fields[$k]['position'])) {
				$this->fields[$k]['position'] = array_search($k, array_keys($this->fields));
			}

			if (isset($this->fields[$k]['labelKey'])) {
				$this->fields[$k]['label'] = $langs->trans($this->fields[$k]['labelKey']);
			} else {
				$this->fields[$k]['labelKey'] = 'Presta' . $this::dashesToCamelCase($k, true);
				if (!empty($langs->tab_translate[$this->fields[$k]['labelKey']])) {
					$this->fields[$k]['label'] = $langs->trans($this->fields[$k]['labelKey']);
				}else {
					$this->fields[$k]['label'] = $langs->trans($k);
				}
			}
		}
	}

	/**
	 * @param $id
	 *
	 * @return bool
	 */
	public function fetch($id, $cache = true)
	{
		$resource = $this->presta->getFromWebService($this->resource, [], [], ['id' => $id], false, false, [], $cache);
		if (!$resource) {
			$this->setError($this->presta->error);
			return false;
		}

		$resource = $this->presta::idFyArray($resource);
		if (empty($resource[$id])) {
			$this->id = false;
			return false;
		}

		$this->populate($resource[$id]);
		$this->getDolLinkInfo();

		return true;
	}

	/**
	 * @param array $fields
	 * @param array $sort
	 * @param array $filters
	 *                    [
	 *                    'operator' => the query operator : or | interval | begin | end | contains | literal
	 *                    'search' => the value to search
	 *                    ]
	 * @param int   $limit
	 * @param int   $page
	 * @param array $opt
	 * @param bool  $useCache
	 * @param int   $cacheExpire
	 *
	 * @return static[]|false
	 */
	public function fetchAll($fields = [], $sort = [], $filters = [], $limit = 0, $page = 0, $opt = [], $useCache = true, $cacheExpire = 600)
	{
		if (!empty($fields) && $fields != 'full' && !in_array('id', $fields)) {
			$fields[] = 'id';
		}

		$resources = $this->presta->getFromWebService($this->resource, $fields, $sort, $filters, $limit, $page, $opt, $useCache, $cacheExpire);
		if (!$resources) {
			$this->setError($this->presta->error);
			return false;
		}

		$out = [];
		foreach ($resources as $resource) {
			$obj = new static($this->presta);
			$obj->populate($resource);
			$out[$obj->id] = $obj;
		}

		return $out;
	}

	/**
	 * @param $resultObj
	 *
	 * @return void
	 */
	public function populate($resultObj)
	{
		if (!is_object($resultObj)) {
			return false;
		}

		foreach ($this->fields as $field => $def) {
			$fieldToGet = $this->getWebServiceFieldNameAccordingToVersion($field);
			if ($fieldToGet === false) {
				$fieldToGet = $field;
			}

			if (isset($resultObj->$fieldToGet)) {
				$this->$field = $resultObj->$fieldToGet;
			}
		}

		if(!empty($resultObj->associations)){
			$this->associations = $resultObj->associations;
		}
	}

	/**
	 * @param $field
	 *
	 * @return false|string
	 */
	public function getWebServiceFieldNameAccordingToVersion($field)
	{
		if (!isset($this->fields[$field])) {
			return false;
		}

		$def = $this->fields[$field];
		$fieldToGet = $field;
		if (!empty($def['compatibility']) && !empty($def['compatibility'][$this->presta->shop_version])) {
			$fieldToGet = $def['compatibility'][$this->presta->shop_version];
		}

		return $fieldToGet;
	}

	/**
	 * @param array $TField
	 *
	 * @return array
	 */
	public function reMapWebServiceArrayOfFieldAccordingToVersion(array $TField)
	{
		foreach ($TField as $dId => $dFieldItem) {
			$fieldToGet = $this->getWebServiceFieldNameAccordingToVersion($dFieldItem);
			if ($fieldToGet === false) {
				unset($TField[$dId]);
			}

			if ($dFieldItem != $fieldToGet) {
				unset($TField[$dId]);
				$TField[$dId] = $fieldToGet;
			}
		}

		return $TField;
	}

	static function dashesToCamelCase($string, $capitalizeFirstCharacter = false)
	{
		$str = str_replace('-', ' ', $string);
		$str = str_replace('_', ' ', $str);
		$str = str_replace(' ', '', ucwords($str));

		if (!$capitalizeFirstCharacter) {
			$str = lcfirst($str);
		}

		return $str;
	}

	public function setDolLink()
	{
		if (!$this->checkCreateLinkReady()) {
			return false;
		}

		$sql = 'INSERT INTO ' . $this->presta->db->prefix() . 'prestasync_resource_element
					 (fk_presta, presta_resource, presta_resource_id, dol_element,dol_element_id, date_creation, tms)
					 VALUES
					 (' . intval($this->presta->id) . ', \'' . $this->presta->db->escape($this->resource) . '\', ' . intval($this->id) . ', \'' . $this->presta->db->escape($this->doliElement) . '\',' . intval($this->doliElementId) . ', NOW(), NOW())
    			';

		if (!$this->presta->db->query($sql)) {
			$this->setError('Error setLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->getDolLinkInfo();

		return true;
	}

	/**
	 * @return bool
	 */
	public function delDolLink()
	{
		if (empty($this->linkObject)) {
			$this->getDolLinkInfo();
		}

		if (empty($this->linkObject)) {
			return false;
		}

		$sql = 'DELETE FROM ' . $this->presta->db->prefix() . 'prestasync_resource_element WHERE rowid = ' . intval($this->linkObject->id);
		if (!$this->presta->db->query($sql)) {
			$this->setError('Error delLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->linkObject = null;
		$this->doliElementId = 0;
		return true;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getPrestaLinkInfo()
	{
		//$targetSyncElement

		$this->linkObject = null;

		if (!$this->doliElement) {
			$this->setError('Missing targetSyncElement');
			return false;
		}

		$sql = 'SELECT rowid id, fk_presta, presta_resource, presta_resource_id, dol_element,dol_element_id, date_creation, tms
					FROM ' . $this->presta->db->prefix() . 'prestasync_resource_element
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND dol_element = \'' . $this->presta->db->escape($this->doliElement) . '\'
						AND dol_element_id = ' . intval($this->doliElementId) . '
    			';

		$obj = $this->presta->db->getRow($sql);
		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->tms);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getDolLinkInfo()
	{
		if (!$this->doliElement) {
			return false;
		}

		$this->linkObject = null;
		$this->doliElementId = false;

		$sql = 'SELECT rowid id, fk_presta, presta_resource, presta_resource_id, dol_element,dol_element_id, date_creation, tms
					FROM ' . $this->presta->db->prefix() . 'prestasync_resource_element
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND presta_resource = \'' . $this->presta->db->escape($this->resource) . '\'
						AND presta_resource_id = ' . intval($this->id) . '
    			';

		$obj = $this->presta->db->getRow($sql);
		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj == 0) {
			$this->doliElementId = 0;
			return 0;
		}

		$this->doliElementId = intval($obj->dol_element_id);
		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->tms);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @return bool|int false on error, id on success and 0 on not found
	 */
	public function fetchDoliSyncElementId()
	{
		$this->doliElementId = null;

		if (!$this->doliElement) {
			$this->setError('Missing targetSyncElement');
			return false;
		}

		$linkObj = $this->getDolLinkInfo();
		if ($linkObj === false) {
			$this->setError('Error while fetching getPrestaLinkInfo');
			return false;
		}

		if ($linkObj === 0) {
			return 0;
		}

		$this->doliElementId = $linkObj->dol_element_id;
		return $this->doliElementId;
	}

	/**
	 * @return bool|int false on error, true on success and 0 on not found
	 */
	public function fetchDolibarrObject()
	{
		global $conf, $db;

		if (empty($this->doliElement)) {
			$this->setError('Missing targetSyncElement');
			return false;
		}

		if (empty($this->doliElementId)) {
			$this->fetchDoliSyncElementId();
		}

		if (empty($this->doliElementId)) {
			$this->setError('Missing targetSyncElementId');
			return false;
		}

		$element_prop = getElementProperties($this->doliElement);

		if (is_array($element_prop)) {
			dol_include_once('/' . $element_prop['classpath'] . '/' . $element_prop['classfile'] . '.class.php');

			$this->doliObject = new $element_prop['classname']($db);
			$ret = $this->doliObject->fetch($this->doliElementId);
			if ($ret > 0) {
				return true;
			} else {
				if ($ret == 0) {
					$this->delDolLink();
				}

				$this->doliObject = null;
				return 0;
			}
		} else {
			return false;
		}
	}

	/**
	 * @return static::STATUS_LINK_NOT_FETCHED|static::STATUS_NOT_LINKED|static::STATUS_LINKED|static::STATUS_LINK_ERROR;
	 */
	public function getLinkStatus()
	{
		// false on error
		if ($this->doliElementId === false) {
			return static::STATUS_LINK_ERROR;
		}

		// if null : not fetched yet
		if (is_null($this->doliElementId)) {
			return static::STATUS_LINK_NOT_FETCHED;
		}

		// if 0 : not sync
		if ($this->doliElementId === 0) {
			return static::STATUS_NOT_LINKED;
		}

		// if 0 : not sync
		if ($this->doliElementId > 0) {
			return static::STATUS_LINKED;
		} else {
			return static::STATUS_LINK_ERROR;
		}
	}

	/**
	 * @param string $mode default '' , 'pill', 'dot'
	 *
	 * @return string
	 */
	public function getStatusBadge($mode = '')
	{
		global $langs;

		$class = 'status8';
		$label = $langs->trans('STATUS_LINKED_ERROR');
		$status = $this->getLinkStatus();
		if ($status == static::STATUS_LINK_NOT_FETCHED) {
			$class = 'status0';
			$label = $langs->trans('STATUS_LINK_NOT_FETCHED');
		} elseif ($status == static::STATUS_NOT_LINKED) {
			$class = 'status1';
			$label = $langs->trans('STATUS_NOT_LINKED');
		} elseif ($status == static::STATUS_LINKED) {
			$class = 'status4';
			$label = $langs->trans('STATUS_LINKED');
		}

		return dolGetBadge($label, '', $class, $mode);
	}

	/**
	 *    Return clicable name (with picto eventually)
	 *
	 * @param int $withpicto Add picto into link
	 *
	 * @return string                                String with URL
	 */
	function getDolNomCardUrl($withpicto = 0)
	{
		if (!$this->doliObject) {
			$this->fetchDolibarrObject();
		}

		if ($this->doliObject) {
			if (method_exists($this->doliObject, 'getNomUrl')) {
				return $this->doliObject->getNomUrl($withpicto);
			}
		}
	}

	/**
	 * Return HTML string to show a field into a page
	 * Code very similar with showOutputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $value     Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
	 * @param string $moreparam To add more parametes on html input tag
	 * @param mixed  $morecss   Value for css to define size. May also be a numeric.
	 *
	 * @return string
	 */
	public function showOutputFieldQuick($key, $moreparam = '', $morecss = '')
	{
		global $conf, $langs, $form;

		$val = $this->fields[$key];

		$value = $this->$key;
		if (!empty($val['langs'])) {
			$value = $this->getTradValue($value);
		}

		if (!is_object($form)) {
			require_once DOL_DOCUMENT_ROOT . '/core/class/html.form.class.php';
			$form = new Form($this->presta->db);
		}

		$objectid = $this->id;    // Not used ???

		$label = empty($val['label']) ? '' : $val['label'];
		$type = empty($val['type']) ? '' : $val['type'];
		$size = empty($val['css']) ? '' : $val['css'];
		$reg = [];

		// Convert var to be able to share same code than showOutputField of extrafields
		if (preg_match('/varchar\((\d+)\)/', $type, $reg)) {
			$type = 'varchar'; // convert varchar(xx) int varchar
			$size = $reg[1];
		} elseif (preg_match('/varchar/', $type)) {
			$type = 'varchar'; // convert varchar(xx) int varchar
		}
		if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
			$type = 'select';
		}
		if (preg_match('/^integer:(.*):(.*)/i', $val['type'], $reg)) {
			$type = 'link';
		}

		$default = empty($val['default']) ? '' : $val['default'];
		$computed = empty($val['computed']) ? '' : $val['computed'];
		$unique = empty($val['unique']) ? '' : $val['unique'];
		$required = empty($val['required']) ? '' : $val['required'];
		$param = [];
		$param['options'] = [];

		if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
			$param['options'] = $val['arrayofkeyval'];
		}
		if (preg_match('/^integer:(.*):(.*)/i', $val['type'], $reg)) {
			$type = 'link';
			$param['options'] = [$reg[1] . ':' . $reg[2] => $reg[1] . ':' . $reg[2]];
		} elseif (preg_match('/^sellist:(.*):(.*):(.*):(.*)/i', $val['type'], $reg)) {
			$param['options'] = [$reg[1] . ':' . $reg[2] . ':' . $reg[3] . ':' . $reg[4] => 'N'];
			$type = 'sellist';
		} elseif (preg_match('/^sellist:(.*):(.*):(.*)/i', $val['type'], $reg)) {
			$param['options'] = [$reg[1] . ':' . $reg[2] . ':' . $reg[3] => 'N'];
			$type = 'sellist';
		} elseif (preg_match('/^sellist:(.*):(.*)/i', $val['type'], $reg)) {
			$param['options'] = [$reg[1] . ':' . $reg[2] => 'N'];
			$type = 'sellist';
		}

		$langfile = empty($val['langfile']) ? '' : $val['langfile'];
		$list = (empty($val['list']) ? '' : $val['list']);
		$help = (empty($val['help']) ? '' : $val['help']);
		$hidden = (($val['visible'] == 0) ? 1 : 0); // If zero, we are sure it is hidden, otherwise we show. If it depends on mode (view/create/edit form or list, this must be filtered by caller)

		if ($hidden) {
			return '';
		}

		// If field is a computed field, value must become result of compute
		if ($computed) {
			// Make the eval of compute string
			//var_dump($computed);
			$value = dol_eval($computed, 1, 0, '');
		}

		if (empty($morecss)) {
			if ($type == 'date') {
				$morecss = 'minwidth100imp';
			} elseif ($type == 'datetime' || $type == 'timestamp') {
				$morecss = 'minwidth200imp';
			} elseif (in_array($type, ['int', 'double', 'price'])) {
				$morecss = 'maxwidth75';
			} elseif ($type == 'url') {
				$morecss = 'minwidth400';
			} elseif ($type == 'boolean') {
				$morecss = '';
			} else {
				if (is_numeric($size) && round($size) < 12) {
					$morecss = 'minwidth100';
				} elseif (is_numeric($size) && round($size) <= 48) {
					$morecss = 'minwidth200';
				} else {
					$morecss = 'minwidth400';
				}
			}
		}

		// Format output value differently according to properties of field
		if (in_array($key, ['rowid', 'ref']) && method_exists($this, 'getNomUrl')) {
			if ($key != 'rowid' || empty($this->fields['ref'])) {    // If we want ref field or if we want ID and there is no ref field, we show the link.
				$value = $this->getNomUrl(1, '', 0, '', 1);
			}
		} elseif ($key == 'status' && method_exists($this, 'getLibStatut')) {
			$value = $this->getLibStatut(3);
		} elseif ($type == 'date') {
			if (!empty($value)) {
				$value = dol_print_date($value, 'day');    // We suppose dates without time are always gmt (storage of course + output)
			} else {
				$value = '';
			}
		} elseif ($type == 'datetime' || $type == 'timestamp') {
			if (!empty($value)) {
				$value = dol_print_date($value, 'dayhour', 'tzuserrel');
			} else {
				$value = '';
			}
		} elseif ($type == 'duration') {
			include_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';
			if (!is_null($value) && $value !== '') {
				$value = convertSecondToTime($value, 'allhourmin');
			}
		} elseif ($type == 'double' || $type == 'real') {
			if (!is_null($value) && $value !== '') {
				$value = price($value);
			}
		} elseif ($type == 'boolean') {
			$checked = '';
			if (!empty($value)) {
				$checked = ' checked ';
			}
			$value = '<input type="checkbox" ' . $checked . ' ' . ($moreparam ? $moreparam : '') . ' readonly disabled>';
		} elseif ($type == 'mail' || $type == 'email') {
			$value = dol_print_email($value, 0, 0, 0, 64, 1, 1);
		} elseif ($type == 'url') {
			$value = dol_print_url($value, '_blank', 32, 1);
		} elseif ($type == 'phone') {
			$value = dol_print_phone($value, '', 0, 0, '', '&nbsp;', 'phone');
		} elseif ($type == 'price') {
			if (!is_null($value) && $value !== '') {
				$value = price(price2num($value), 0, $langs, 0, 0, -1, $conf->currency);
			}
		} elseif ($type == 'select') {
			$value = isset($param['options'][$value]) ? $param['options'][$value] : '';
		} elseif ($type == 'sellist') {
			$param_list = array_keys($param['options']);
			$InfoFieldList = explode(":", $param_list[0]);

			$selectkey = "rowid";
			$keyList = 'rowid';

			if (count($InfoFieldList) > 4 && !empty($InfoFieldList[4])) {
				$selectkey = $InfoFieldList[2];
				$keyList = $InfoFieldList[2] . ' as rowid';
			}

			$fields_label = explode('|', $InfoFieldList[1]);
			if (is_array($fields_label)) {
				$keyList .= ', ';
				$keyList .= implode(', ', $fields_label);
			}

			$sql = "SELECT " . $keyList;
			$sql .= ' FROM ' . $this->presta->db->prefix() . $InfoFieldList[0];
			if (strpos($InfoFieldList[4], 'extra') !== false) {
				$sql .= ' as main';
			}
			if ($selectkey == 'rowid' && empty($value)) {
				$sql .= " WHERE " . $selectkey . " = 0";
			} elseif ($selectkey == 'rowid') {
				$sql .= " WHERE " . $selectkey . " = " . ((int) $value);
			} else {
				$sql .= " WHERE " . $selectkey . " = '" . $this->presta->db->escape($value) . "'";
			}

			//$sql.= ' AND entity = '.$conf->entity;

			dol_syslog(get_class($this) . ':showOutputField:$type=sellist', LOG_DEBUG);
			$resql = $this->presta->db->query($sql);
			if ($resql) {
				$value = ''; // value was used, so now we reste it to use it to build final output
				$numrows = $this->presta->db->num_rows($resql);
				if ($numrows) {
					$obj = $this->presta->db->fetch_object($resql);

					// Several field into label (eq table:code|libelle:rowid)
					$fields_label = explode('|', $InfoFieldList[1]);

					if (is_array($fields_label) && count($fields_label) > 1) {
						foreach ($fields_label as $field_toshow) {
							$translabel = '';
							if (!empty($obj->$field_toshow)) {
								$translabel = $langs->trans($obj->$field_toshow);
							}
							if ($translabel != $field_toshow) {
								$value .= dol_trunc($translabel, 18) . ' ';
							} else {
								$value .= $obj->$field_toshow . ' ';
							}
						}
					} else {
						$translabel = '';
						if (!empty($obj->{$InfoFieldList[1]})) {
							$translabel = $langs->trans($obj->{$InfoFieldList[1]});
						}
						if ($translabel != $obj->{$InfoFieldList[1]}) {
							$value = dol_trunc($translabel, 18);
						} else {
							$value = $obj->{$InfoFieldList[1]};
						}
					}
				}
			} else {
				dol_syslog(get_class($this) . '::showOutputField error ' . $this->presta->db->lasterror(), LOG_WARNING);
			}
		} elseif ($type == 'radio') {
			$value = $param['options'][$value];
		} elseif ($type == 'checkbox') {
			$value_arr = explode(',', $value);
			$value = '';
			if (is_array($value_arr) && count($value_arr) > 0) {
				$toprint = [];
				foreach ($value_arr as $keyval => $valueval) {
					$toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories" style="background: #bbb">' . $param['options'][$valueval] . '</li>';
				}
				$value = '<div class="select2-container-multi-dolibarr" style="width: 90%;"><ul class="select2-choices-dolibarr">' . implode(' ', $toprint) . '</ul></div>';
			}
		} elseif ($type == 'chkbxlst') {
			$value_arr = explode(',', $value);

			$param_list = array_keys($param['options']);
			$InfoFieldList = explode(":", $param_list[0]);

			$selectkey = "rowid";
			$keyList = 'rowid';

			if (count($InfoFieldList) >= 3) {
				$selectkey = $InfoFieldList[2];
				$keyList = $InfoFieldList[2] . ' as rowid';
			}

			$fields_label = explode('|', $InfoFieldList[1]);
			if (is_array($fields_label)) {
				$keyList .= ', ';
				$keyList .= implode(', ', $fields_label);
			}

			$sql = "SELECT " . $keyList;
			$sql .= ' FROM ' . $this->presta->db->prefix() . $InfoFieldList[0];
			if (strpos($InfoFieldList[4], 'extra') !== false) {
				$sql .= ' as main';
			}
			// $sql.= " WHERE ".$selectkey."='".$this->presta->db->escape($value)."'";
			// $sql.= ' AND entity = '.$conf->entity;

			dol_syslog(get_class($this) . ':showOutputField:$type=chkbxlst', LOG_DEBUG);
			$resql = $this->presta->db->query($sql);
			if ($resql) {
				$value = ''; // value was used, so now we reste it to use it to build final output
				$toprint = [];
				while ($obj = $this->presta->db->fetch_object($resql)) {
					// Several field into label (eq table:code|libelle:rowid)
					$fields_label = explode('|', $InfoFieldList[1]);
					if (is_array($value_arr) && in_array($obj->rowid, $value_arr)) {
						if (is_array($fields_label) && count($fields_label) > 1) {
							foreach ($fields_label as $field_toshow) {
								$translabel = '';
								if (!empty($obj->$field_toshow)) {
									$translabel = $langs->trans($obj->$field_toshow);
								}
								if ($translabel != $field_toshow) {
									$toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories" style="background: #bbb">' . dol_trunc($translabel, 18) . '</li>';
								} else {
									$toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories" style="background: #bbb">' . $obj->$field_toshow . '</li>';
								}
							}
						} else {
							$translabel = '';
							if (!empty($obj->{$InfoFieldList[1]})) {
								$translabel = $langs->trans($obj->{$InfoFieldList[1]});
							}
							if ($translabel != $obj->{$InfoFieldList[1]}) {
								$toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories" style="background: #bbb">' . dol_trunc($translabel, 18) . '</li>';
							} else {
								$toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories" style="background: #bbb">' . $obj->{$InfoFieldList[1]} . '</li>';
							}
						}
					}
				}
				$value = '<div class="select2-container-multi-dolibarr" style="width: 90%;"><ul class="select2-choices-dolibarr">' . implode(' ', $toprint) . '</ul></div>';
			} else {
				dol_syslog(get_class($this) . '::showOutputField error ' . $this->presta->db->lasterror(), LOG_WARNING);
			}
		} elseif ($type == 'link') {
			// only if something to display (perf)
			if ($value) {
				$param_list = array_keys($param['options']); // $param_list='ObjectName:classPath'

				$InfoFieldList = explode(":", $param_list[0]);
				$classname = $InfoFieldList[0];
				$classpath = $InfoFieldList[1];
				$getnomurlparam = (empty($InfoFieldList[2]) ? 3 : $InfoFieldList[2]);
				$getnomurlparam2 = (empty($InfoFieldList[4]) ? '' : $InfoFieldList[4]);
				if (!empty($classpath)) {
					dol_include_once($InfoFieldList[1]);
					if ($classname && class_exists($classname)) {
						$object = new $classname($this->db);
						if ($object->element === 'product') {    // Special cas for product because default valut of fetch are wrong
							$result = $object->fetch($value, '', '', '', 0, 1, 1);
						} else {
							$result = $object->fetch($value);
						}
						if ($result > 0) {
							$value = $object->getNomUrl($getnomurlparam, $getnomurlparam2);
						} else {
							$value = '';
						}
					}
				} else {
					dol_syslog('Error bad setup of extrafield', LOG_WARNING);
					return 'Error bad setup of extrafield';
				}
			} else {
				$value = '';
			}
		} elseif ($type == 'password') {
			$value = preg_replace('/./i', '*', $value);
		} elseif ($type == 'array') {
			$value = implode('<br>', $value);
		} else {    // text|html|varchar
			$value = dol_htmlentitiesbr($value);
		}

		return $value;
	}

	public function getCardFieldLine($field, $class = '', $params = [])
	{
		global $langs;
		$defaultParams = [
			'canEdit' => false,
			'edit' => 'auto',
			'editUrl' => '',
			'formActionUrl' => $_SERVER['PHP_SELF'],
		];

		foreach ($defaultParams as $pK => $pv) {
			if (!array_key_exists($pK, $params)) {
				$params[$pK] = $pv;
			}
		}

		if (empty($params['editUrl'])) {
			$params['editUrl'] = static::rebuildCurrentUrl([
															   'edit-field' => $field,
															   'token' => newToken(),
														   ]);
		}

		if ($params['edit'] === 'auto') {
			$params['edit'] = $params['canEdit'] && GETPOST('edit-field') === $field;
		}

		$out = '<tr class="field_label ' . $field . '" >';
		$out .= '<td class="titlefield">';
		$out .= $this->fields[$field]['label'];
		$out .= '</td>';
		$out .= '<td class="right">';
		if (!$params['edit'] && $params['canEdit'] && !empty($params['editUrl'])) {
			$out .= '<a class="classfortooltip editfielda" href="' . $params['editUrl'] . '" >';
			$out .= '<span class="fas fa-pencil-alt" style=" color: #444; float: right" title="' . dol_htmlentities($langs->trans('Edit')) . '" ></span></a>';
			$out .= '</a>';
		}
		$out .= '</td>';

		// <a class="editfielda" href="/thersane/gestion/htdocs/product/card.php?action=editbarcode&amp;id=9259&amp;token=7fdf5d21ea10e33a8c00e9810220e3cc"><span class="fas fa-pencil-alt" style=" color: #444; float: right" title="Éditer"></span></a>

		if (isset($this->fields[$field]['type']) && $this->fields[$field]['type'] == 'price') {
			$class .= ' right';
		}

		$out .= '<td class="valuefield wordbreak ' . $class . '" >';
		if ($params['edit'] && $params['canEdit']) {
			$out .= '<form action="' . dol_htmlentities($params['formActionUrl']) . '" method="post" >';
			$out .= '<input type="hidden" name="token" value="' . newToken() . '">';
			$out .= '<input type="hidden" name="presta_id" value="' . $this->id . '">';
			$out .= '<input type="hidden" name="id" value="' . $this->presta->id . '">';
			$out .= '<input type="hidden" name="field-name" value="' . $field . '">';
			$out .= $this->showInputFieldQuick($field);

			$out .= '<button class="button presta-sync-btn presta-sync-btn-success" type="submit" name="action" value="update-field" ><span class="fa fa-check"></span></button>';
			$out .= '<button class="button presta-sync-btn presta-sync-btn-cancel"  type="submit" name="cancel" value="1" ><span class="fa fa-times" title="' . $langs->trans("Cancel") . '"></span></button>';

			$out .= '</form>';
		} else {
			$out .= $this->showOutputFieldQuick($field);
		}
		$out .= '</td>';

		return $out;
	}

	/**
	 * Return HTML string to put an input field into a page
	 * Code very similar with showInputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $keysuffix Prefix string to add into name and id of field (can be used to avoid duplicate names)
	 * @param string $keyprefix Suffix string to add into name and id of field (can be used to avoid duplicate names)
	 *
	 * @return string
	 */
	public function showInputFieldQuick($key, $keysuffix = '', $keyprefix = '')
	{
		$out = '';

		return $out;
	}

	/**
	 * @param $newParams
	 *
	 * @return string
	 */
	static public function rebuildCurrentUrl($newParams = [])
	{
		$curentUrl = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		$curentUrlParsed = parse_url($curentUrl);

		$curentUrlParams = [];
		if (isset($curentUrlParsed['query'])) {
			parse_str($curentUrlParsed['query'], $curentUrlParams);
		}

		if (!empty($_POST)) {
			foreach ($_POST as $nk => $nv) {
				$curentUrlParams[$nk] = $nv;
			}
		}

		foreach ($newParams as $nk => $nv) {
			$curentUrlParams[$nk] = $nv;
		}

		$newUrlQuery = http_build_query($curentUrlParams);
		return $curentUrlParsed['scheme'] . '://' . $curentUrlParsed['host'] . $curentUrlParsed['path'] . (!empty($newUrlQuery) ? '?' . $newUrlQuery : '');
	}

	/**
	 * Will check if all element for link are ok
	 *
	 * @return bool
	 */
	public function checkCreateLinkReady()
	{
		if (empty($this->presta->id)) {
			$this->setError('Missing Presta Id');
			return false;
		}

		if (empty($this->resource)) {
			$this->setError('Missing Presta resource');
			return false;
		}

		if (empty($this->doliElement)) {
			$this->setError('Missing Dolibarr element');
			return false;
		}

		if (empty($this->doliElementId)) {
			$this->setError('Missing Dolibarr element id');
			return false;
		}

		return true;
	}

	public function varDumpMe()
	{
		$dump = new stdClass();
		foreach ($this->fields as $fieldK => $fieldConf) {
			$dump->$fieldK = $this->$fieldK;
		}
		$bt = debug_backtrace();
		$caller = array_shift($bt);

		print '<pre>';
		print $caller['file'] . ':' . $caller['line'] . "\n";
		var_dump($dump);
		print '</pre>';
	}

	/**
	 * @param       $attribute
	 * @param false $langId
	 * @param bool  $noFailMode
	 *
	 * @return false|mixed
	 */
	public function getTradValue($attribute, $langId = false, $noFailMode = true)
	{
		if (!is_array($attribute)) {
			// in this case, juste one lang activated
			return $attribute;
		}

		if ($langId === false) {
			$langId = $this->presta->language;
		}

		foreach ($attribute as $item) {
			if (isset($item->id) && (int) $item->id == (int) $langId) {
				return $item->value;
			}
		}

		if (!$noFailMode) {
			return false;
		}

		return reset($attribute)->value;
	}
}

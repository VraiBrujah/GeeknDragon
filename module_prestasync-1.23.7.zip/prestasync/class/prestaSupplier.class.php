<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaSupplier.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';

class PrestaSupplier extends PrestaCommonObject
{

	use PrestaCustomLinkInfo;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'suppliers';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'societe';

	public $fields = [
		'id' => [],
		'link_rewrite' => [],
		'name' => [],
		'active' => [],
		'date_add' => [],
		'date_upd' => [],
		'description' => [],
		'meta_title' => [],
		'meta_description' => [],
		'meta_keywords' => [],
	];

	public $id;
	public $link_rewrite;
	public $name;
	public $active;
	public $date_add;
	public $date_upd;
	public $description;
	public $meta_title;
	public $meta_description;
	public $meta_keywords;

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_supplier';
		$this->linkTableDoliCol = 'fk_soc';
		$this->linkTablePrestaCol = 'fk_supplier_presta';

		parent::__construct($presta);
	}

	/**
	 * @param User $user
	 *
	 * @return false|int|void
	 */
	public function syncToDolibarr($user, $notrigger = 0)
	{
		global $conf;

		// Check if synced
		$this->getDolLinkInfo();

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		require_once __DIR__ . '/mappingsupplier.class.php';
		$this->doliObject = new MappingSupplier($this->presta->db);
		$res = $this->doliObject->autoCreateMapping($user, $this);
		if ($res <= 0) {
			$this->setError($this->doliObject->errorsToString());
			return false;
		}
		return $res;
	}
}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaOrderDetail.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';
require_once __DIR__ . '/prestaTax.class.php';

class PrestaOrder extends PrestaCommonObject
{

	use PrestaCustomLinkInfo;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'orders';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'commande';

	/**
	 * the Dolibarr linked object
	 *
	 * @var Commande $doliObject ;
	 */
	public $doliObject;

	public $fields = [
		'id' => [],
		'id_address_delivery' => [],
		'id_address_invoice' => [],
		'id_cart' => [],
		'id_currency' => [],
		'id_lang' => [],
		'id_customer' => [],
		'id_carrier' => [],
		'current_state' => [],
		'module' => [
			'labelKey' => 'prestashopPaymentModule',
		],
		'invoice_number' => [],
		'invoice_date' => [],
		'delivery_number' => [],
		'delivery_date' => [],
		'valid' => [],
		'date_add' => [],
		'date_upd' => [],
		'shipping_number' => [],
		'note' => [],
		'id_shop_group' => [],
		'id_shop' => [],
		'secure_key' => [],
		'payment' => [
			'labelKey' => 'prestashopPayment',
		],
		'recyclable' => [],
		'gift' => [],
		'gift_message' => [],
		'mobile_theme' => [],
		'total_discounts' => [
			'type' => 'price',
		],
		'total_discounts_tax_incl' => [
			'type' => 'price',
		],
		'total_discounts_tax_excl' => [
			'type' => 'price',
		],
		'total_paid' => [
			'type' => 'price',
		],
		'total_paid_tax_incl' => [
			'type' => 'price',
		],
		'total_paid_tax_excl' => [
			'type' => 'price',
		],
		'total_paid_real' => [
			'type' => 'price',
		],
		'total_products' => [
			'type' => 'price',
		],
		'total_products_wt' => [
			'type' => 'price',
		],
		'total_shipping' => [
			'type' => 'price',
		],
		'total_shipping_tax_incl' => [
			'type' => 'price',
		],
		'total_shipping_tax_excl' => [
			'type' => 'price',
		],
		'carrier_tax_rate' => [
			'type' => 'price',
		],
		'total_wrapping' => [
			'type' => 'price',
		],
		'total_wrapping_tax_incl' => [
			'type' => 'price',
		],
		'total_wrapping_tax_excl' => [
			'type' => 'price',
		],
		'round_mode' => [],
		'round_type' => [],
		'conversion_rate' => [],
		'reference' => [],
		'associations' => [
			'visible' => 0,
		],
	];

	public function __construct(Presta $presta)
	{
		$this->linkTable = 'prestasync_order';
		$this->linkTableDoliCol = 'fk_commande_doli';
		$this->linkTablePrestaCol = 'fk_order_presta';

		return parent::__construct($presta);
	}

	public $id;
	public $id_address_delivery;

	/** Fetched elements with $id_address_delivery */
	public PrestaAddress $prestaAddressDelivery;

	public $id_address_invoice;

	/** Fetched elements with $id_address_invoice */
	public PrestaAddress $prestaAddressInvoice;
	public $id_cart;
	public $id_currency;
	public $id_lang;
	public $id_customer;

	/** Fetched elements with $id_customer */
	public PrestaCustomer $prestaCustomer;

	public $id_carrier;
	public $current_state;
	public $module;
	public $invoice_number;
	public $invoice_date;
	public $delivery_number;
	public $delivery_date;
	public $valid;
	public $date_add;
	public $date_upd;
	public $shipping_number;
	public $note;
	public $id_shop_group;
	public $id_shop;
	public $secure_key;
	public $payment;
	public $recyclable;
	public $gift;
	public $gift_message;
	public $mobile_theme;
	public $total_discounts;
	public $total_discounts_tax_incl;
	public $total_discounts_tax_excl;
	public $total_paid;
	public $total_paid_tax_incl;
	public $total_paid_tax_excl;
	public $total_paid_real;
	public $total_products;
	public $total_products_wt;
	public $total_shipping;
	public $total_shipping_tax_incl;
	public $total_shipping_tax_excl;
	public $carrier_tax_rate;
	public $total_wrapping;
	public $total_wrapping_tax_incl;
	public $total_wrapping_tax_excl;
	public $round_mode;
	public $round_type;
	public $conversion_rate;
	public $reference;
	public $associations = [];

	/**
	 * @var PrestaOrderDetail[] $prestaOrderDetails
	 */
	public $prestaOrderDetails = [];

	public function getNomUrlDolibarr()
	{
		if (!empty($this->doliObject)) {
			return $this->doliObject->getNomUrl();
		} elseif ($this->doliElement) {
			return false;
		}
	}

	/**
	 * Return HTML string to put an input field into a page
	 * Code very similar with showInputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $keysuffix Prefix string to add into name and id of field (can be used to avoid duplicate names)
	 * @param string $keyprefix Suffix string to add into name and id of field (can be used to avoid duplicate names)
	 *
	 * @return string
	 */
	public function showInputFieldQuick($key, $keysuffix = '', $keyprefix = '')
	{
		global $conf, $langs, $form;

		if (!is_object($form)) {
			require_once DOL_DOCUMENT_ROOT . '/core/class/html.form.class.php';
			$form = new Form($this->db);
		}

		$out = '';

		if ($key == 'current_state') {
			$out = $form->selectArray($keyprefix . $key . $keysuffix, $this->getSimpleListOfAvailableOrderStatus(), $this->current_state);
		}

		return $out;
	}

	/**
	 * Return HTML string to show a field into a page
	 * Code very similar with showOutputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $value     Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
	 * @param string $moreparam To add more parametes on html input tag
	 * @param mixed  $morecss   Value for css to define size. May also be a numeric.
	 *
	 * @return string
	 */
	public function showOutputFieldQuick($key, $moreparam = '', $morecss = '')
	{
		global $langs, $conf;
		if ($key == 'id_address_delivery') {
			if (!$this->fetchAddressDelivery()) {
				return '';
			}
			return $this->prestaAddressDelivery->getFullAddress()
				. ' '
				. $this->prestaAddressDelivery->getStatusBadge('dot')
				. ' '
				. $this->prestaAddressDelivery->getDolNomCardUrl(2);
		} elseif ($key == 'id_customer') {
			if (!$this->fetchCustomer()) {
				return '';
			}
			return $this->prestaCustomer->getFullName()
				. ' '
				. $this->prestaCustomer->getStatusBadge('dot')
				. ' '
				. $this->prestaCustomer->getDolNomCardUrl(2);
		} elseif ($key == 'id_address_invoice') {
			if (!$this->fetchAddressInvoice()) {
				return '';
			}
			return $this->prestaAddressInvoice->getFullAddress()
				. ' '
				. $this->prestaAddressInvoice->getStatusBadge('dot')
				. ' '
				. $this->prestaAddressInvoice->getDolNomCardUrl(2);
		} elseif (in_array($key, ['total_discounts', 'total_discounts_tax_incl', 'total_discounts_tax_excl'])) {
			return price(floatval($this->$key) * -1, 0, $langs, 0, 0, -1, $conf->currency);
		} elseif ($key == 'current_state') {
			return $this->getPrestaOrderStatusBadge();
		} elseif ($key == 'id_cart') {
			return '<a href="' . $this->presta->getPrestaAdminUrl('cart', ['id_cart' => $this->id_cart]) . '" target="_blank">' . $this->id_cart . '</a>';
		} else {
			return parent::showOutputFieldQuick($key, $moreparam, $morecss);
		}
	}

	public function fetchCustomer($cache = true)
	{
		if (empty($this->id_customer)) {
			return 0;
		}

		if ($cache && !empty($this->prestaCustomer)) {
			return true;
		}

		require_once __DIR__ . '/prestaCustomer.class.php';
		$this->prestaCustomer = new PrestaCustomer($this->presta);
		if (!$this->prestaCustomer->fetch($this->id_customer)) {
			$this->setError($this->prestaCustomer->getLastError());
			return false;
		}

		return true;
	}

	public function fetchAddressDelivery($cache = true)
	{
		if (empty($this->id_address_delivery)) {
			return false;
		}

		if ($cache && !empty($this->prestaAddressDelivery)) {
			return true;
		}

		require_once __DIR__ . '/prestaAddress.class.php';
		$this->prestaAddressDelivery = new PrestaAddress($this->presta);
		if (!$this->prestaAddressDelivery->fetch($this->id_address_delivery, $cache)) {
			$this->prestaAddressDelivery = null;
			return false;
		}

		return true;
	}

	public function fetchAddressInvoice($cache = true)
	{
		if (empty($this->id_address_invoice)) {
			return false;
		}

		if ($cache && !empty($this->prestaAddressInvoice)) {
			return true;
		}

		require_once __DIR__ . '/prestaAddress.class.php';
		$this->prestaAddressInvoice = new PrestaAddress($this->presta);
		if (!$this->prestaAddressInvoice->fetch($this->id_address_invoice, $cache)) {
			$this->prestaAddressInvoice = null;
			return false;
		}

		return true;
	}

	public function getAllPrestaOrderStatus()
	{
		return $this->presta->getAllResources('order_states');
	}

	/**
	 * return a list on prestashop order status
	 * TODO : if a class for order status is created move this method to new class
	 *
	 * @return array
	 */
	public function getSimpleListOfAvailableOrderStatus()
	{
		$array = [];
		$prestaOrderStates = $this->getAllPrestaOrderStatus();
		if (!empty($prestaOrderStates)) {
			foreach ($prestaOrderStates as $oSKey => $oSValue) {
				$array[$oSKey] = $this->getTradValue($oSValue->name);
			}
		}

		return $array;
	}


	/**
	 * @param bool $active
	 *
	 * @return array ex [
	 * 	{
	 * 		"id": 00000,
	 * 		"order_reference": "vvvevevzv",
	 * 		"id_currency": 1,
	 * 		"amount": "100.000000",
	 * 		"payment_method": "PayPal",
	 * 		"conversion_rate": "1.000000",
	 * 		"transaction_id": "5555555",
	 * 		"card_number": "",
	 * 		"card_brand": "",
	 * 		"card_expiration": "",
	 * 		"card_holder": "",
	 * 		"date_add": "2024-06-19 15:55:57"
	 * 	}
	 * ]
	 */
	public function getPrestaOrderPayments(): array
	{
		$filter = [];

		if(empty($this->reference)){
			return []; // unable to find payment without ref
		}

		$filter['order_reference'] = $this->reference;

		$objs = $this->presta->getFromWebService('order_payments', [], [], $filter);

		$list = [];
		if (!empty($objs) && is_array($objs)) {
			foreach ($objs as $obj) {
				$obj->date_add = $this->presta->db->jdate($obj->date_add);
				$list[$obj->id] = $obj;
			}
		}

		return $list;
	}


	public function getPrestaOrderStatusBadge($status = false, $returnIdOnFail = false)
	{
		$prestaOrderStates = $this->getAllPrestaOrderStatus();

		if ($status === false) {
			$status = $this->current_state;
		}

		$status = intval($status);
		if (!isset($prestaOrderStates[$status])) {
			if ($returnIdOnFail) {
				return '<span class="badge badge-warning">' . $status . '</span>';
			} else {
				return '';
			}
		}
		$curOrderStatus = $prestaOrderStates[$status];

		$moreStyle = '';
		if (!colorIsLight($curOrderStatus->color)) {
			$moreStyle = 'color:#fff;';
		}

		return '<span class="badge" style="background-color:' . $curOrderStatus->color . ';' . $moreStyle . '" >' . $this->getTradValue($curOrderStatus->name) . '</span>';
	}

	/**
	 * @param string $mode 'populate' | 'get'
	 *
	 * @return void
	 */
	public function fetchLines($mode = 'populate', $useCache = false)
	{
		if (empty($this->associations->order_rows)) {
			$this->prestaOrderDetails = [];
			return false;
		}

		require_once __DIR__ . '/prestaOrderDetail.class.php';

		if ($mode == 'populate') {
			foreach ($this->associations->order_rows as $row) {
				$prestaOrderDetail = new PrestaOrderDetail($this->presta);
				$prestaOrderDetail->populate($row);
				$this->prestaOrderDetails[$row->id] = $prestaOrderDetail;
			}

//			ksort($this->prestaOrderDetails);

			return true;
		} else {
			$prestaOrderDetail = new PrestaOrderDetail($this->presta);
			$prestaOrderDetails = $prestaOrderDetail->fetchAll([], ['id' => 'ASC'], ['id_order' => $this->id], 99999, 0, [], $useCache);
//			ksort($prestaOrderDetails);

			if ($prestaOrderDetails) {
				$this->prestaOrderDetails = $prestaOrderDetails;
				return true;
			}

			return false;
		}
	}

	/**
	 * @param User $user
	 *
	 * @return false|int|void
	 */
	public function syncToDolibarr($user, $notrigger = 0)
	{
		global $conf, $langs;

		// TODO : Manage update

		if (empty($conf->global->PRESTASYNC_SHIPPING_SERVICE) && floatval($this->total_shipping_tax_incl) > 0) {
			$this->setError('Error shipping service not defined');
			return false;
		}

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		// Check if synced
		$this->getDolLinkInfo();

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		if (empty($this->prestaOrderDetails) && !$this->fetchLines('get')) {
			$this->setError('Error fetching order detail from prestashop');
			return false;
		}

		$this->fetchAddressDelivery();
		$this->fetchAddressInvoice();

		if (!$this->fetchCustomer(true)) {
			return false;
		}

		/*
		 * Step 01 - Get Customer and sync him if needed
		 */

		$addressForThirdParty = $this->prestaAddressInvoice;
		$updateThirdPartyAddress = getDolGlobalString('PRESTASYNC_UPDATE_THIRDPARTY_ADDRESS');
		if(in_array($updateThirdPartyAddress, ['INVOICE', 'SHIPPING'])) {
			if ($updateThirdPartyAddress === 'INVOICE') {
				$addressForThirdParty = $this->prestaAddressInvoice;
			} elseif ($updateThirdPartyAddress === 'SHIPPING') {
				$addressForThirdParty = $this->prestaAddressDelivery;
			}
		}else{
			$updateThirdPartyAddress = false;
		}


		$resSyncPrestaCustomer = $this->prestaCustomer->syncToDolibarr($user, $addressForThirdParty, (bool) $updateThirdPartyAddress);
		if (!$resSyncPrestaCustomer) {
			$this->setError('Sync customer error :' . $this->prestaCustomer->getLastError());
			return false;
		}

		if (empty($this->prestaCustomer->doliObject->id)) {
			$this->setError('Error presta customer link not found');
			return false;
		}

		$fk_soc = $this->prestaCustomer->doliObject->id;

		/*
		 * Step 2 - Get Adresses
		 */

		if (!$this->prestaAddressDelivery->syncToDolibarr($user, $fk_soc)) {
			$this->setError('Sync address Delivery error :' . $this->prestaAddressDelivery->getLastError());
			return false;
		}

		if (!$this->prestaAddressInvoice->syncToDolibarr($user, $fk_soc)) {
			$this->setError('Sync address Invoice error :' . $this->prestaAddressInvoice->getLastError());
			return false;
		}

		if (!$this->checkLinesForImport()) {
			$this->setError('Abort import, invalid line(s) detected');
			return false;
		}

		require_once DOL_DOCUMENT_ROOT . '/commande/class/commande.class.php';
		$this->doliObject = new Commande($this->presta->db);
		$this->doliObject->socid = $fk_soc;
		$this->doliObject->entity = $this->presta->entity;
		$this->doliObject->fetch_thirdparty();

		$this->doliObject->import_key = 'P' . sprintf('%02d', $this->presta->id) . '-' . $this->id;
		$this->doliObject->date_commande = $this->presta->db->jdate($this->date_add);
		$this->doliObject->date = $this->presta->db->jdate($this->date_add);
		$this->doliObject->note_private = $this->note; // TODO voir si a mettre en note publique
		$this->doliObject->note_public = '';
		$this->doliObject->model_pdf = getDolGlobalString('COMMANDE_ADDON_PDF');

		$resSearchRef = $this->presta->db->getRow('SELECT rowid id FROM ' . $this->presta->db->prefix() . $this->doliObject->table_element . ' WHERE ref = \'' . $this->presta->db->escape($this->reference) . '\' ');
		if ($resSearchRef === false) {
			$this->setError('Create order error unable to check ref in database : ' . $this->presta->db->error());
			return false;
		}

		if ($resSearchRef) {
			$this->setError('Create order error unable to check ref in database : ' . $this->presta->db->error());
			return false;
		}

		if ($resSearchRef === 0) {
			$this->doliObject->ref = $this->reference;
		}

		$this->doliObject->ref_client = $this->id . ' / ' . $this->reference;
		$this->doliObject->fk_project = $this->presta->fk_project;
		$this->doliObject->demand_reason_id = $this->presta->fk_c_input_reason;

		$this->doliObject->module_source = 'prestasync';
//		$this->doliObject->source = GETPOST('source_id'); // n'est pour l'instant pas vraiment géré par dolibarr
//		$this->doliObject->date_livraison = $date_delivery; // deprecated
//		$this->doliObject->delivery_date = $date_delivery;
//		$this->doliObject->shipping_method_id = ;
//		$this->doliObject->warehouse_id = ;
//		$this->doliObject->deposit_percent = ;
//		$this->doliObject->availability_id = ;
//		$this->doliObject->fk_account = ;
//		$this->doliObject->fk_incoterms = ;
//		$this->doliObject->location_incoterms = ;
//		$this->doliObject->multicurrency_code = ;
//		$this->doliObject->multicurrency_tx = ;
//		$this->doliObject->contact_id = GETPOST('contactid'); useless ?

		// Check wrapping Config
		if (empty($conf->global->PRESTASYNC_WRAPPING_SERVICE) && floatval($this->total_wrapping_tax_excl) > 0) {
			$this->setError($langs->trans('MissingWrappingServiceConfiguration'));
			return false;
		}

		/**
		 * SHIPMENT
		 */
		$this->doliObject->shipping_method_id = !empty($conf->global->PRESTASYNC_SHIPPING_DEFAULT_MODE) ? intval($conf->global->PRESTASYNC_SHIPPING_DEFAULT_MODE) : 0;
		if (empty($this->doliObject->shipping_method_id)) {
			$this->setError('Missing shipping default configuration ');
			return false;
		}

		require_once __DIR__ . '/prestaCarrier.class.php';
		$carrierDesc = '';
		$prestaCarrier = new PrestaCarrier($this->presta);
		if ($prestaCarrier->fetch($this->id_carrier)) {
			$prestaCarrier->syncToDolibarr($user); // don't trow error because it use default value
			// Check if synced
			if ($prestaCarrier->getDolLinkInfo()) {
				if ($prestaCarrier->linkObject->fk_shipment_mode > 0) {
					$this->doliObject->shipping_method_id = $prestaCarrier->linkObject->fk_shipment_mode;
					$carrierDesc = $prestaCarrier->name;
				}
			}
		}

		require_once __DIR__ . '/mappingpayment.class.php';
		$mappingPaiement = new MappingPayment($this->presta->db);
		$paiementConditions = $mappingPaiement->getPaiementConditions($user, $this->presta, $this->payment, $this->doliObject->thirdparty);
		if (!$paiementConditions) {
			$this->setError('Error while getting paiement conditions : ' . $mappingPaiement->errorsToString());
			return false;
		}
		$this->doliObject->cond_reglement_id = $paiementConditions->fk_cond_reglement_id;
		$this->doliObject->mode_reglement_id = $paiementConditions->fk_mode_reglement_id;
		$this->doliObject->fk_account = $paiementConditions->fk_bank_account;

		/**
		 * CREATE COMMANDE IN DATABASE
		 */
		$this->presta->db->begin();
		$resCreate = $this->doliObject->create($user, $notrigger);
		if ($resCreate < 0) {
			$this->setError($this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		// Update import_key because create doesn't set it
		$this->doliObject->db->query('UPDATE ' . MAIN_DB_PREFIX . "commande SET import_key='" . $this->doliObject->db->escape($this->doliObject->import_key) . "' WHERE rowid=" . ((int) $this->doliObject->id));

		// Create link
		$this->doliElementId = $this->doliObject->id;
		if (!$this->setDolLink()) {
			$this->presta->db->rollback();
			return false;
		}

		if ($this->doliObject->add_contact($this->prestaAddressInvoice->doliObject->id, $conf->global->PRESTASYNC_ORDER_CONTACT_BILLING, 'external', $notrigger) < 0) {
			$this->setError('Error while add billing contact : ' . $this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		if ($this->doliObject->add_contact($this->prestaAddressDelivery->doliObject->id, $conf->global->PRESTASYNC_ORDER_CONTACT_SHIPPING, 'external', $notrigger) < 0) {
			$this->setError('Error while add shipping contact : ' . $this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		$contactOrderType = getDolGlobalString('PRESTASYNC_ORDER_CONTACT_ORDER');
		if($contactOrderType) {
			$contactOrderSource = getDolGlobalString('PRESTASYNC_ORDER_CONTACT_ORDER_SOURCE');
			if ($contactOrderSource === 'INVOICE') {
				$contactOrderId = $this->prestaAddressInvoice->doliObject->id;
			} elseif ($contactOrderSource === 'SHIPPING') {
				$contactOrderId = $this->prestaAddressDelivery->doliObject->id;
			}

			if (!empty($contactOrderId) && $this->doliObject->add_contact($contactOrderId, $contactOrderType, 'external', $notrigger) < 0) {
				$this->setError('Error while add order contact : ' . $this->doliObject->errorsToString());
				$this->presta->db->rollback();
				return false;
			}
		}


		// Check remise
		$remisePercent = 0;

		$taxList = [];

		foreach ($this->prestaOrderDetails as $line) {
			$prestaTax = new PrestaTax($this->presta);

			if($line->id_tax_rules_group > 0) {
				if (!$prestaTax->fetchTaxFromRuleGroup($line->id_tax_rules_group, $this->prestaAddressDelivery->id_country, $this->prestaAddressDelivery->id_state)) {
					$prestaTax = new PrestaTax($this->presta);
					if (!$prestaTax->fetchTaxFromRuleGroup($line->id_tax_rules_group, $this->prestaAddressDelivery->id_country)) {
						$this->setError('Error while get prestashop line Tax');
						$this->presta->db->rollback();
						return false;
					}
				}
			}

			if (!class_exists('PrestaProduct')) { require_once __DIR__ . '/prestaProduct.class.php'; }
			$dolProductId = PrestaProduct::checkProductRefExistsInDolibarr($line->product_reference, $line->presta->entity);
			if ($dolProductId === false) {
				$this->setError('Error while searching product in database');
				return false;
			}

			if ($dolProductId === 0 && empty($conf->global->PRESTASYNC_ALLOW_IMPORT_FREE_LINE) && empty($conf->global->PRESTASYNC_ALLOW_IMPORT_MISSING_PRODUCT)) {
				$this->setError('Error product not found in database');
				return false;
			}

			// CREATE PRODUCT IN DOLIBARR
			if ((int)$dolProductId === 0) {
				$prestaProduct = new PrestaProduct($this->presta);
				if(!$prestaProduct->fetch($line->product_id)){
					$this->setError('Error fetching prestashop product');
					return false;
				}

				if (!empty($line->product_attribute_id)) {
					$prestaCombination = new PrestaCombination($this->presta);
					if(!$prestaCombination->fetch($line->product_attribute_id)){
						$this->setError('Error fetching prestashop product combination');
						return false;
					}

					if(!$prestaProduct->importCombinationToDolibarr($user, $prestaCombination)){
						$this->setError('Error create product combination in Dolibarr');
						$this->setError($prestaProduct->getErrors());
						return false;
					}

					$dolProductId = $prestaCombination->doliElementId;

				} else {
					$dolProductId = $prestaProduct->syncToDolibarr($user);
					if(!$prestaProduct->doliElementId){
						$this->setError('Error import prestashop product');
						$this->setError($prestaProduct->getErrors());
						return false;
					}
				}
			}

			if (!array_key_exists($prestaTax->rate, $taxList)) {
				$taxList[$prestaTax->rate] = 0;
			}
			$taxList[$prestaTax->rate] += $line->total_price_tax_excl - $line->total_price_tax_incl;

			$desc = '';
			$type = 0;
			$buyPrice = $this->calcDefaultBuyPrice($line->unit_price_tax_excl);
			if ($dolProductId === 0) {
				$desc = $line->product_reference;
				$desc .= ' - ' . $line->product_name;
			} else {
				require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
				$product = new Product($this->presta->db);
				if ($product->fetch($dolProductId, $line->product_reference) <= 0) {
					$this->setError('Error fetching product');
					return false;
				}

				$type = $product->type;
				$buyPrice = $this->getProductBuyPrice($product);
				if ($buyPrice === false) {
					$this->setError('Error fetching buy price');
					return false;
				}
			}

			$lineUnitPriceTaxeExcl = $line->unit_price_tax_excl;
			$lineUnitPriceTaxeIncl = $line->unit_price_tax_incl;

			// to have exacte same amount with taxe use hack to retrive amount du to round method
			if (!empty($line->product_quantity) && $line->total_price_tax_excl) {
				$lineUnitPriceTaxeExcl = $line->total_price_tax_excl / $line->product_quantity;
				$lineUnitPriceTaxeIncl = $line->total_price_tax_incl / $line->product_quantity;
			}

			$addLineResult = $this->doliObject->addline(
				$desc,
				$lineUnitPriceTaxeExcl,
				$line->product_quantity,
				$prestaTax->rate,
				0, //$txlocaltax1
				0, // $txlocaltax2
				$dolProductId,
				$remisePercent, // $remise_percent
				0, //$info_bits
				0, //$fk_remise_except
				'HT', //$price_base_type
				$lineUnitPriceTaxeIncl, // $pu_ttc
				'', // $date_start
				'', // $date_end
				$type,
				-1, // $rang
				0, //$special_code
				0, // $fk_parent_line
				null, // $fk_fournprice
				$buyPrice,
				'', // $label  /* => deprecated */
				0, //$array_options
				null, // $fk_unit
				'', // $origin
				0, // $origin_id
				0, // $pu_ht_devise
				'', // $ref_ext
				0 // $noupdateafterinsertline
			);

			if ($addLineResult < 0) {
				$this->setError('Error adding order line : ' . $this->doliObject->errorsToString());
				return false;
			}

			// In some version of Prestasho WebService could fail due to unpached bug in Prestashop
			// TODO manage error according to Prestashop version
			$this->importCustomizationInOrderLine($user, $line, $addLineResult);
		}

		// Manage discount // c'est pas la bonne métode
//		if(floatval($this->total_discounts_tax_excl) > 0 && floatval($this->total_paid_tax_excl) > 0){
//			$remiseFixeTva = static::closestValue(array_keys($taxList), $this->total_discounts_tax_excl - $this->total_discounts_tax_incl);
//			$this->doliObject->thirdparty->set_remise_except($this->total_discounts_tax_excl, $user, $this->doliObject->ref, $remiseFixeTva);
//		}

		if (!empty($conf->global->PRESTASYNC_SHIPPING_SERVICE) && floatval($this->total_shipping_tax_incl) > 0) {
			require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
			$shippingProduct = new Product($this->presta->db);
			if ($shippingProduct->fetch($conf->global->PRESTASYNC_SHIPPING_SERVICE) <= 0) {
				$this->setError('Error fetching shipping product');
				return false;
			}

//			$TotalTaxExcl = floatval($prestaOrder->total_products) + floatval($prestaOrder->total_shipping_tax_excl) + floatval($prestaOrder->total_wrapping_tax_excl) - floatval($prestaOrder->total_discounts_tax_excl);
//			$TotalTaxIncl = floatval($prestaOrder->total_products_wt) + floatval($prestaOrder->total_shipping_tax_incl) + floatval($prestaOrder->total_wrapping_tax_incl) - floatval($prestaOrder->total_discounts_tax_incl);

			$addShippingLineResult = $this->doliObject->addline(
				$carrierDesc,
				$this->total_shipping_tax_excl, // See pu_ttc
				1,
				$this->carrier_tax_rate,
				0, //$txlocaltax1
				0, // $txlocaltax2
				$conf->global->PRESTASYNC_SHIPPING_SERVICE,
				$remisePercent, // $remise_percent
				0, //$info_bits
				0, //$fk_remise_except
				'HT', //$price_base_type
				$this->total_shipping_tax_incl, // $pu_ttc
				'', // $date_start
				'', // $date_end
				$shippingProduct->type,
				-1, // $rang
				0, //$special_code
				0, // $fk_parent_line
				null, // $fk_fournprice
				$this->total_shipping_tax_excl // For transport no margin is set so we use 100% of price
			);

			if ($addShippingLineResult < 0) {
				$this->setError('Error adding shipping order line : ' . $this->doliObject->errorsToString());
				return false;
			}
		}

		// Check wrapping Config
		if (floatval($this->total_wrapping_tax_excl) > 0) {
			require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
			$wrappingProduct = new Product($this->presta->db);
			if ($wrappingProduct->fetch($conf->global->PRESTASYNC_WRAPPING_SERVICE) <= 0) {
				$this->setError('Error fetching shipping product');
				return false;
			}

			$buyPrice = $this->getProductBuyPrice($wrappingProduct);
			if ($buyPrice === false) {
				$this->setError('Error fetching buy price for wrapping service');
				return false;
			}

			$addWrappingLineResult = $this->doliObject->addline(
				'',
				$this->total_wrapping_tax_excl, // See pu_ttc
				1,
				static::calcVATVariationPercent($this->total_wrapping_tax_excl, $this->total_wrapping_tax_incl) ?: $wrappingProduct->tva_tx, // il faut calculer car la taxe n'est pas transmise...
				0, //$txlocaltax1
				0, // $txlocaltax2
				$wrappingProduct->id,
				$remisePercent, // $remise_percent
				0, //$info_bits
				0, //$fk_remise_except
				'HT', //$price_base_type
				$this->total_wrapping_tax_incl, // $pu_ttc
				'', // $date_start
				'', // $date_end
				$wrappingProduct->type,
				-1, // $rang
				0, //$special_code
				0, // $fk_parent_line
				null, // $fk_fournprice
				$buyPrice
			);

			if ($addWrappingLineResult < 0) {
				$this->setError('Error adding wrapping order line : ' . $this->doliObject->errorsToString());
				return false;
			}
		}

		/**
		 * REMISE
		 */
		if (floatval($this->total_discounts_tax_excl) > 0 && floatval($this->total_paid_tax_excl) > 0) {
			// see above use fixe remise
//			$remisePercent = ($this->total_discounts_tax_excl / $this->total_paid_tax_excl ) * 100;

			// je me base sur les autre produit preésent pour déterminer la tva
			$remiseFixeTva = static::closestValue(array_keys($taxList), $this->total_discounts_tax_excl - $this->total_discounts_tax_incl);

			$addRemiseLineResult = $this->doliObject->addline(
				'',
				$this->total_wrapping_tax_excl, // See pu_ttc
				1,
				$remiseFixeTva, // il faut calculer car la taxe n'est pas transmise...
				0, //$txlocaltax1
				0, // $txlocaltax2
				getDolGlobalInt('PRESTASYNC_DISCOUNT_SERVICE', 0),
				0, // $remise_percent
				0, //$info_bits
				0, //$fk_remise_except
				'TTC', //$price_base_type
				(floatval($this->total_discounts_tax_incl) * -1), // $pu_ttc
				'', // $date_start
				'', // $date_end
				1,
				-1, // $rang
				0, //$special_code
				0, // $fk_parent_line
				null, // $fk_fournprice
				0
			);

			if ($addRemiseLineResult < 0) {
				$this->setError('Error adding remise order line : ' . $this->doliObject->errorsToString());
				return false;
			}
		}

		$this->presta->db->commit();

		// to avoid trigger object not loaded i reload object before valid
		$commande = new Commande($this->presta->db);
		$commande->fetch($this->doliObject->id);

		/** Before Valid need amount correction to fit Prestashop paiement */
		$fixAmount = true;
		if (abs($commande->total_ttc - $this->total_paid_tax_incl) >= 0.1) {
			// IF diff more than 10 cent
			$this->setError($langs->trans('ErrorAmountDiffX', price(abs($commande->total_ttc - $this->total_paid_tax_incl))));
			$fixAmount = false;
		} elseif ($commande->total_ttc != $this->total_paid_tax_incl && $this->fixTotalToAmount($this->total_paid_tax_incl, $commande, true, false) === false) {
			$fixAmount = false;
			$this->setError('Error import : total price ' . $this->total_paid_tax_incl . ' != ' . $commande->total_ttc);
		}

		// Valid and génerate document
		if ($fixAmount) {
			// For unknow reasons invoice and Order amout are differents if not reload after fixTotalToAmount
			$commande = new Commande($this->presta->db);
			$commande->fetch($this->doliObject->id);
			$commande->fetch_thirdparty();
			$idWarehouse = getDolGlobalInt('MAIN_DEFAULT_WAREHOUSE', 0);
			$commande->valid($user, $idWarehouse);

			if (getDolGlobalString('COMMANDE_ADDON_PDF')) {
				$commande->generateDocument(getDolGlobalString('COMMANDE_ADDON_PDF'), $langs);
			}
		}

		$this->doliObject = $commande;

		if ($this->presta->order_status_on_sync > 0) {
			$this->setPrestaStatus($this->presta->order_status_on_sync);
		}

		/* CREATION DE LA FACTURE */
		if (getDolGlobalInt('PRESTASYNC_INVOICE_GENERATE') && getDolGlobalInt('PRESTASYNC_INVOICE_BANK_ACCOUNT')) {
			include_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
			$facture = new Facture($this->presta->db);
			if ($facture->createFromOrder($commande, $user) > 0) {
				$facture->setBankAccount($this->doliObject->fk_account);
				if (getDolGlobalInt('PRESTASYNC_INVOICE_VALIDATE')) {
					// need reload because missing entity after createFromOrder
					$factureIdCreate = $facture->id;
					$facture = new Facture($this->presta->db);
					if ($facture->fetch($factureIdCreate) <= 0) {
						$this->setError('Invoice created can\'t be fetch fetch');
						return false;
					}

					$resValidateInvoice =$facture->validate($user);
					$commande->classifyBilled($user);
					$facture->generateDocument(getDolGlobalString('FACTURE_ADDON_PDF'), $langs);

					// Check for paiements
					if ($resValidateInvoice > 0 && getDolGlobalInt('PRESTASYNC_INVOICE_CHECK_FOR_PAIEMENTS') && !empty($paiementConditions->flag_create_payment)) {
						$prestaPayments = $this->getPrestaOrderPayments();
						if ($prestaPayments) {

							if(!class_exists('Paiement')){
								require_once DOL_DOCUMENT_ROOT . '/compta/paiement/class/paiement.class.php';
							}

							foreach ($prestaPayments as $prestaPayment){
								// Creation of payment line
								$paiement = new Paiement($facture->db);
								$paiement->fk_account = $facture->fk_account;
								$paiement->datepaye = $prestaPayment->date_add;
								$paiement->num_payment = $prestaPayment->transaction_id;

								$paiement->paiementid = $this->doliObject->mode_reglement_id;
								$cPaymentCodeObj = $facture->db->getRow('SELECT code FROM ' . $facture->db->prefix() . 'c_paiement WHERE rowid = ' . ((int) $paiement->paiementid));
								if ($cPaymentCodeObj) {
									$paiement->paiementcode = $cPaymentCodeObj->code;
								}

								// Build private note
								$paiement->note_private = $langs->trans('Prestashop');
								$paiement->note_private .= 'ID : ' . (int) $prestaPayment->id . "\n\r";
								$paiement->note_private .= 'Order : ' . $prestaPayment->order_reference . "\n\r";
								$paiement->note_private .= 'id_currency : ' . (int) $prestaPayment->id_currency . "\n\r";
								$paiement->note_private .= 'conversion_rate : ' . (double) $prestaPayment->conversion_rate . "\n\r";
								$paiement->note_private .= 'amount : ' . (double) $prestaPayment->amount . "\n\r";
								$paiement->note_private .= 'payment_method : ' . $prestaPayment->payment_method . "\n\r";
								$paiement->note_private .= 'date_add : ' . dol_print_date($prestaPayment->date_add) . "\n\r";

								// $paiement->amounts is an Array with all payments dispatching with invoice id
								$paiement->amounts = [
									$facture->id => round((double) $prestaPayment->amount * (double) $prestaPayment->conversion_rate, 3),
								];

								// TODO : add multi currency support ? need currency mapping between Dolibarr and Prestashop ? or use iso code for comparing ?
//								$paiement->multicurrency_amounts = $multicurrency_amounts; // Array with all payments dispatching
//								$paiement->multicurrency_code = $multicurrency_code; // Array with all currency of payments dispatching
//								$paiement->multicurrency_tx = $multicurrency_tx; // Array with all currency tx of payments dispatching

								// Create payment and update this->multicurrency_amounts if this->amounts filled or
								// this->amounts if this->multicurrency_amounts filled.
								// This also set ->amount and ->multicurrency_amount
								$paymentId = $paiement->create($user, 1, $facture->thirdparty); // This include closing invoices and regenerating documents
								if ($paymentId < 0) {
									// On error dont't stop
									$this->setError('Create payment fail for invoice ' . $facture->ref);
								}

								if ($paymentId > 0) {
									$label = '(CustomerInvoicePayment)';
									$result = $paiement->addPaymentToBank($user, 'payment', $label, $facture->fk_account, '', '');
									if ($result < 0) {
										// On error dont't stop
										$this->setError($paiement->error);
										$this->setError($paiement->errors);
									}
								}
							}
						}
					}
				}
			}
		}

		return true;
	}

	/**
	 * @param PrestaOrderDetail $prestaOrderDetail
	 * @param int $dolibarrOrderLineId
	 */
	protected function importCustomizationInOrderLine(User $user, $prestaOrderDetail, $dolibarrOrderLineId){
		global $langs;

		if((int)$prestaOrderDetail->id_customization == 0) {
			return true;
		}

		if(empty($dolibarrOrderLineId)) {
			$this->setError('Missing dolibarrOrderLineId for importCustomizationInOrderLine');
			return false;
		}

		if(!class_exists('PrestaCustomization')) {
			require_once __DIR__ . '/prestaCustomization.class.php';
		}
		if(!class_exists('PrestaProductCustomizationField')) {
			require_once __DIR__ . '/prestaProductCustomizationFields.class.php';
		}
		if(!class_exists('PrestaImage')) {
			require_once __DIR__ . '/prestaImage.class.php';
		}

		$dLine = new OrderLine($this->presta->db);
		if($dLine->fetch($dolibarrOrderLineId) < 1){
			$this->setError('No fetch line for importCustomizationInOrderLine');
			return false;
		}

		// Initialize technical object to manage hooks. Note that conf->hooks_modules contains array
		$hookmanager = new HookManager($this->presta->db); // re create hook manager to avoid hookCeption
		$params = [
			'prestaOrderDetail' => $prestaOrderDetail,
			'PrestaOrder' => $this,
		];
		$hookmanager->initHooks(array('prestaorderclass'));
		$reshook = $hookmanager->executeHooks('importCustomizationInOrderLine', $params, $dLine);
		if ($reshook < 0) {
			// error
			return false;
		}

		if ($reshook > 0) {
			// Hook replace behavior
			return true;
		}

		$customization= new PrestaCustomization($this->presta);
		if(!$customization->fetch((int)$prestaOrderDetail->id_customization)) {
			$this->setError('Prestashop Customization not found : '.$customization->getLastError());
			return false;
		}

		$idsOfCustomizationField = [];
		if(!empty($customization->associations->customized_data_text_fields)) {
			foreach ($customization->associations->customized_data_text_fields as $customizedDataTextFields) {
				$idsOfCustomizationField[] = $customizedDataTextFields->id_customization_field;
			}
		}

		if(!empty($customization->associations->customized_data_images)) {
			foreach ($customization->associations->customized_data_images as $customizedDataImages) {
				$idsOfCustomizationField[] = $customizedDataImages->id_customization_field;
			}
		}

		$idsOfCustomizationField = array_unique($idsOfCustomizationField);
		$filters = [
			'id' => [
				'operator' => 'or',
				'search' => $idsOfCustomizationField
			]
		];

		$customizationFields = new PrestaProductCustomizationField($this->presta);
		$allCustomizationFields = $customizationFields->fetchAll([], [], $filters, 999,  0, [], false);
		if(!$allCustomizationFields){
			$this->setError('Prestashop Customization field not found : '.$customizationFields->getLastError());
			return false;
		}

		$descUseHtml = isModEnabled('fckeditor') && getDolGlobalInt('FCKEDITOR_ENABLE_DETAILS');
		$lineBreak = $descUseHtml ? '<br/>' : "\r\n";

		// Pour respecter l'ordre de Prestashop on se base sur les résultats de $allCustomizationFields
		foreach ($allCustomizationFields as $customizationFieldId => $customizationField) {

			$customizationName = dol_escape_htmltag($customizationField->getTradValue($customizationField->name));

			if (!empty($dLine->desc)) {
				$dLine->desc.= $lineBreak;
			}

			if($descUseHtml){
				$dLine->desc.= '<strong>' . $customizationName . ':</strong> ';
			} else {
				$dLine->desc.= $customizationName.': ';
			}


			if((int)$customizationField->type === 0) {
				// IMAGE
				if(!empty($customization->associations->customized_data_images)) {
					foreach ($customization->associations->customized_data_images as $customizedDataImageFields) {
						if((int)$customizedDataImageFields->id_customization_field != (int)$customizationFieldId) {
							continue;
						}

						$image = new PrestaImage($this->presta);
						$photoName = $image->importImageCustomizationDolOrderLine($this->doliObject,  $dLine,$customization, $customizedDataImageFields);
						if(!$photoName){
							$this->setError($image->getErrors());
							$dLine->desc.= $langs->trans('ErrorGettingImageFromShop');
							break;
						}

						if($descUseHtml){
							$dLine->desc.= '<span class="prestasync-line-customization-photo-lazy-link" data-file="'.dol_escape_htmltag(dol_escape_htmltag($photoName)).'" data-order="'.$this->doliObject->id.'" >' . $photoName . '</span> ';
						} else {
							$dLine->desc.= $photoName;
						}
						break;
					}
				}
			}
			else{
				// TEXT
				if(!empty($customization->associations->customized_data_text_fields)) {
					foreach ($customization->associations->customized_data_text_fields as $customizedDataTextFields) {
						if((int)$customizedDataTextFields->id_customization_field != (int)$customizationFieldId) {
							continue;
						}

						$dLine->desc.= dol_escape_htmltag($customizedDataTextFields->value);
						break;
					}
				}
			}
		}

		$resUp = $dLine->update($user);
		if($resUp<1){
			return false;
		}

		return true;
	}

	public static function closestValue($array, $value)
	{
		// Vérifie que le tableau n'est pas vide
		if (empty($array)) {
			return false;
		}

		// Initialise la variable pour la valeur la plus proche
		$closest = null;
		$smallestDifference = PHP_INT_MAX;

		// Parcourt le tableau pour trouver la valeur la plus proche
		foreach ($array as $element) {
			$difference = abs($element - $value);
			if ($difference < $smallestDifference) {
				$smallestDifference = $difference;
				$closest = $element;
			}
		}

		return $closest;
	}

	public function fixTotalToAmount($newTotal, Commande &$commande, $modeTaxIncl = true, $globalPlane = false)
	{
		$coef = 1;
		$fieldTotal = 'total_ttc';
		if (!$modeTaxIncl) $fieldTotal = 'total_ht';

		$newTotal = floatval($newTotal);
		$commande->{$fieldTotal} = floatval($commande->{$fieldTotal});

		$commande->db->begin();
		$lastLine = false;
		if ($globalPlane) {
			if (!empty($commande->{$fieldTotal}) && $commande->{$fieldTotal} != 0) {
				$coef = $newTotal / $commande->{$fieldTotal};
			}

			if ($coef === 1) {
				return null;
			}

			$lastLine = false;
			foreach ($commande->lines as $line) {
				$line->tva_tx = floatval($line->tva_tx);
				$line->subprice = floatval($line->subprice);

				$tx_tva = 1 + ($line->tva_tx / 100);
				$puTTC = $line->subprice * $tx_tva; // calcul du ttc unitaire

				if (!$modeTaxIncl) {
					$tx_tva = 1;
					$puTTC = $line->subprice;
				}

				$puTTC = $puTTC * $coef; // on applique le coef de réduction
				$puHT = $puTTC / $tx_tva; // calcul du nouvel ht unitaire

				self::updateDolOrderLine($commande, $line, $puHT);
				$lastLine = $line;
			}
		} elseif (!empty($commande->lines)) {
			$lastLine = end($commande->lines);
		}

		if ($lastLine) {
			// on ajoute à la dernière ligne la différence de centime
			$lastLine->fetch($lastLine->id);

			if (!$modeTaxIncl) $tx_tva = 1;
			else $tx_tva = 1 + ($lastLine->tva_tx / 100);

			$diffComptaTot = $newTotal - $commande->{$fieldTotal}; // diff entre le total voulu et le nouveau total calculé (décalage de centimes)
			$diffComptaUnit = $diffComptaTot / $lastLine->qty; // diff à diviser par la qty car on doit obtenir au final un prix unitaire
			$newLineTotTTCToGet = $lastLine->total_ttc + $diffComptaTot; // Le nouveau total TTC de la ligne à obtenir

			$puTTC = $lastLine->subprice * $tx_tva + $diffComptaUnit; // calcul du ttc unitaire
			$puHT = $puTTC / $tx_tva; // calcul du nouvel ht unitaire

			// Détermine la précision attendue si supérieur à 2 chiffres
			$newTotalPrecision = max(static::getNumPrecision($newLineTotTTCToGet), 2);

			for ($precision = 2; $precision <= 6; $precision++) {
				$roundedPuHT = round($puHT, $precision);
				if (round($roundedPuHT * $lastLine->qty * $tx_tva, $newTotalPrecision) == round($newLineTotTTCToGet, $newTotalPrecision)) {
					$puHT = $roundedPuHT;
					break;
				}
			}

			self::updateDolOrderLine($commande, $lastLine, $puHT);
		}

		if (round($commande->{$fieldTotal}, 2) != round($newTotal, 2)) {
			$commande->db->rollback();
			return false;
		}

		$commande->db->commit();
		return true;
	}

	public static function getNumPrecision($floatNum, $removeTraillingZero = true)
	{
		$floatNum = strval($floatNum);

		if ($removeTraillingZero) {
			$floatNum = rtrim($floatNum, "0");
		}
		$length = strlen($floatNum);
		$pos = strpos($floatNum, "."); // zero-based counting.
		return ($length - $pos) - 1; // -1 to compensate for the zero-based count in strpos()
	}

	/**
	 * @param Commande  $object
	 * @param OrderLine $line
	 * @param float     $puHT
	 *
	 * @return int
	 */
	public static function updateDolOrderLine(Commande $object, OrderLine $line, float $puHT)
	{
		return $object->updateline($line->id, $line->desc, $puHT, $line->qty, $line->remise_percent, $line->tva_tx, $line->localtax1_tx, $line->localtax2_tx, 'HT', $line->info_bits, $line->date_start, $line->date_end, $line->product_type, $line->fk_parent_line, $line->skip_update_total, 0, $line->pa_ht, $line->label, $line->special_code, $line->array_options, $line->fk_unit);
	}

	public function checkLinesForImport()
	{
		global $conf;

		if (empty($this->prestaOrderDetails)) {
			$this->setError('Order has no line');
			return false;
		}

		foreach ($this->prestaOrderDetails as $line) {
			if (!class_exists('PrestaProduct')) { require_once __DIR__ . '/prestaProduct.class.php'; }
			$checkProductRefExists = PrestaProduct::checkProductRefExistsInDolibarr($line->product_reference, $this->presta->entity);
			if ($checkProductRefExists === false || ($checkProductRefExists === 0 && empty($conf->global->PRESTASYNC_ALLOW_IMPORT_FREE_LINE) && empty($conf->global->PRESTASYNC_ALLOW_IMPORT_MISSING_PRODUCT))) {
				$this->setError($line->product_reference . ' Not found in Dolibarr');
				return false;
			}

			if($line->id_tax_rules_group > 0) {
				$prestaTax = new PrestaTax($this->presta);
				if (!$prestaTax->fetchTaxFromRuleGroup($line->id_tax_rules_group, $this->prestaAddressDelivery->id_country, $this->prestaAddressDelivery->id_state)) {
					$prestaTax = new PrestaTax($this->presta);
					if (!$prestaTax->fetchTaxFromRuleGroup($line->id_tax_rules_group, $this->prestaAddressDelivery->id_country)) {
						$this->setError('Fail fetchTaxFromRuleGroup for id_tax_rules_group = '.$line->id_tax_rules_group .' and id_country = '.$this->prestaAddressDelivery->id_country);
						return false;
					}
				}
			}
		}

		return true;
	}

	/**
	 * @param Product $product
	 *
	 * @return false|float
	 */
	public function getProductBuyPrice(Product $product)
	{
		global $conf, $hookmanager, $action;

		$hookmanager->initHooks(['prestasyncOrderDao']);

		$parameters = ['productId' => $product->id, 'product' => $product];
		$reshook = $hookmanager->executeHooks('prestassync_getProductBuyPrice', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) {
			return $hookmanager->resPrint;
		}

		$daysOffset = !empty($conf->global->PRESTASYNC_BUY_PRICE_DAYS_OFFSET) ? intval($conf->global->PRESTASYNC_BUY_PRICE_DAYS_OFFSET) : 0;
		$mode = !empty($conf->global->PRESTASYNC_BUY_PRICE_CALC_MODE) ? $conf->global->PRESTASYNC_BUY_PRICE_CALC_MODE : 'avg';
		if (!in_array($mode, ['avg', 'max', 'min', 'percent'])) {
			$mode = 'avg';
		}

		if ($mode != 'percent') {
			$sql = 'SELECT AVG(price) avg_price, MAX(price) max_price, MIN(price) min_price';
			$sql .= ' FROM ' . MAIN_DB_PREFIX . 'product_fournisseur_price WHERE  fk_product = \'' . intval($product->id) . '\' AND entity IN (' . getEntity('product') . ') ';
			$sql .= ' AND price > 0 '; // to avoid missing prices

			if ($daysOffset > 0) {
				$sql .= 'AND tms > NOW() - INTERVAL ' . $daysOffset . ' DAY';
			}

			$obj = $this->presta->db->getRow($sql);
			if ($obj === false) {
				return false;
			}
			if ($obj) {
				if ($mode == 'avg' && floatval($obj->avg_price) > 0) {
					return floatval($obj->avg_price);
				}

				if ($mode == 'max' && floatval($obj->max_price) > 0) {
					return floatval($obj->max_price);
				}

				if ($mode == 'min' && floatval($obj->min_price) > 0) {
					return floatval($obj->min_price);
				}
			}

			if ($product->cost_price > 0) {
				return $product->cost_price;
			}
		}

		if (empty($product->cost_price) && !empty($product->pmp)) {
			return $product->pmp;
		}

		return $this->calcDefaultBuyPrice($product->price);
	}

	/**
	 * @param float $price
	 *
	 * @return false|float
	 */
	public function calcDefaultBuyPrice($price)
	{
		global $conf;
		$percent = !empty($conf->global->PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT) ? intval($conf->global->PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT) : 0;
		return floatval($price) * $percent / 100;
	}

	/**
	 * @param float $oldNumb
	 * @param float $newNum
	 *
	 * @return false|float
	 */
	public static function calcVATVariationPercent(float $oldNumb, float $newNum)
	{
		// TODO : add result check against database
		// 	to be sure VAT exist

		if ($oldNumb == 0) {
			return false;
		}

		return round(($newNum - $oldNumb) / $oldNumb * 100, 2);
	}

	/**
	 * @param $statusId
	 *
	 * @return bool
	 */
	public function setPrestaStatus($statusId)
	{
		if (empty($this->id)) {
			return false;
		}

		$result = $this->presta->addToWebService('order_histories', [
			'id_order_state' => $statusId,
			'id_order' => $this->id,
//			'id_employee' => 1,
		], 'sendemail=1');

		if (!$result && !empty($this->presta->errors)) {
			$this->setError($this->presta->errors);
		}
		return $result;
	}
}

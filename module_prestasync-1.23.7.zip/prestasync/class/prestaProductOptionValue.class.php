<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';
require_once __DIR__ . '/prestaCombination.class.php';
require_once __DIR__ . '/prestaProductOption.class.php';

class PrestaProductOptionValue extends PrestaCommonObject
{
	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'product_option_values';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = false;

	public $fields = [
		'id' => [],
		'id_attribute_group' => [],
		'position' => [],
		'name' => [],
	];

	public $id;
	public $id_attribute_group;
	public $position;
	public $name;

	public function getProductOptionName()
	{
		if (empty($this->id_attribute_group)) {
			$this->setError('id_attribute_group is empty');
			return false;
		}

		$productOption = new PrestaProductOption($this->presta);
		if (!$productOption->fetch($this->id_attribute_group)) {
			return false;
		}

		return $this->getTradValue($productOption->public_name);
	}
}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCartRow.class.php';
require_once __DIR__ . '/prestaCustomLinkInfo.trait.php';
require_once __DIR__ . '/prestaTax.class.php';

class PrestaCart extends PrestaCommonObject
{

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'carts';

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'propal';

	/**
	 * the Dolibarr linked object
	 *
	 * @var Propal $doliObject ;
	 */
	public $doliObject;

	public $fields = [
		'id' => [],
		'id_address_delivery' => [],
		'id_address_invoice' => [],
		'id_currency' => [],
		'id_customer' => [],
		"id_guest"=> [], // new
		'id_lang' => [],
		'id_shop_group' => [],
		'id_shop' => [],
		'id_carrier' => [],
		'recyclable' => [],
		'gift' => [],
		'gift_message' => [],
		'mobile_theme' => [],
		'delivery_option' => [], // new
		'secure_key' => [],
		'allow_seperated_package' => [], // new
		'date_add' => [],
		'date_upd' => [],
		'associations' => [
			'subObjectMapping' => [
				'cart_rows' => [],
			]
		],
	];

	public function __construct(Presta $presta)
	{
		return parent::__construct($presta);
	}

	public $id;
	public $id_address_delivery;

	/** Fetched elements with $id_address_delivery */
	public PrestaAddress $prestaAddressDelivery;

	public $id_address_invoice;

	/** Fetched elements with $id_address_invoice */
	public PrestaAddress $prestaAddressInvoice;

	public $id_currency;
	public $id_lang;
	public $id_customer;

	/** Fetched elements with $id_customer */
	public PrestaCustomer $prestaCustomer;

	public $id_shop_group;
	public $id_shop;
	public $id_carrier;
	public $recyclable;
	public $gift;
	public $gift_message;
	public $mobile_theme;
	public $delivery_option;
	public $secure_key;
	public $allow_seperated_package;
	public $date_add;
	public $date_upd;

	/**
	 * @var stdClass{
	 *     cart_rows: array<int, stdClass{
	 *         id_product: int,
	 *         id_product_attribute: int,
	 *         id_address_delivery: int,
	 *         id_customization: int,
	 *         quantity: int
	 *     }>
	 * }
	 */
	public $associations = [];

	/**
	 * @var PrestaCartRow[] $prestaPropalDetails
	 */
	public $prestaPropalDetails = [];

	/**
	 * TODO : this is a duplicated method present in prestaOrder.class.php : create trait ?
	 *
	 * @return false|string
	 */
	public function getNomUrlDolibarr()
	{
		if (!empty($this->doliObject)) {
			return $this->doliObject->getNomUrl();
		} elseif ($this->doliElement) {
			return false;
		}
	}

	/**
	 * Return HTML string to show a field into a page
	 * Code very similar with showOutputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $value     Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
	 * @param string $moreparam To add more parametes on html input tag
	 * @param mixed  $morecss   Value for css to define size. May also be a numeric.
	 *
	 * @return string
	 */
	public function showOutputFieldQuick($key, $moreparam = '', $morecss = '')
	{
		global $langs, $conf;
		if ($key == 'id_address_delivery') {
			if (!$this->fetchAddressDelivery()) {
				return '';
			}
			return $this->prestaAddressDelivery->getFullAddress()
				. ' '
				. $this->prestaAddressDelivery->getStatusBadge('dot')
				. ' '
				. $this->prestaAddressDelivery->getDolNomCardUrl(2);
		} elseif ($key == 'id_customer') {
			if (!$this->fetchCustomer()) {
				return '';
			}
			return $this->prestaCustomer->getFullName()
				. ' '
				. $this->prestaCustomer->getStatusBadge('dot')
				. ' '
				. $this->prestaCustomer->getDolNomCardUrl(2);
		} elseif ($key == 'id_address_invoice') {
			if (!$this->fetchAddressInvoice()) {
				return '';
			}
			return $this->prestaAddressInvoice->getFullAddress()
				. ' '
				. $this->prestaAddressInvoice->getStatusBadge('dot')
				. ' '
				. $this->prestaAddressInvoice->getDolNomCardUrl(2);
		} elseif (in_array($key, ['total_discounts', 'total_discounts_tax_incl', 'total_discounts_tax_excl'])) {
			return price(floatval($this->$key) * -1, 0, $langs, 0, 0, -1, $conf->currency);
		} elseif ($key == 'id_cart') {
			return '<a href="' . $this->presta->getPrestaAdminUrl('cart', ['id_cart' => $this->id_cart]) . '" target="_blank">' . $this->id_cart . '</a>';
		} else {
			return parent::showOutputFieldQuick($key, $moreparam, $morecss);
		}
	}

	/**
	 * TODO créer un trait
	 * @param bool $cache
	 *
	 * @return bool|int
	 */
	public function fetchCustomer($cache = true)
	{
		if (empty($this->id_customer)) {
			return 0;
		}

		if ($cache && !empty($this->prestaCustomer)) {
			return true;
		}

		require_once __DIR__ . '/prestaCustomer.class.php';
		$this->prestaCustomer = new PrestaCustomer($this->presta);
		if (!$this->prestaCustomer->fetch($this->id_customer)) {
			$this->setError($this->prestaCustomer->getLastError());
			return false;
		}

		return true;
	}

	/**
	 * TODO créer un trait
	 * @param bool $cache
	 *
	 * @return bool
	 */
	public function fetchAddressDelivery($cache = true)
	{
		if (empty($this->id_address_delivery)) {
			return false;
		}

		if ($cache && !empty($this->prestaAddressDelivery)) {
			return true;
		}

		require_once __DIR__ . '/prestaAddress.class.php';
		$this->prestaAddressDelivery = new PrestaAddress($this->presta);
		if (!$this->prestaAddressDelivery->fetch($this->id_address_delivery, $cache)) {
			$this->prestaAddressDelivery = null;
			return false;
		}

		return true;
	}

	/**
	 * TODO créer un trait
	 * @param bool $cache
	 *
	 * @return bool
	 */
	public function fetchAddressInvoice($cache = true)
	{
		if (empty($this->id_address_invoice)) {
			return false;
		}

		if ($cache && !empty($this->prestaAddressInvoice)) {
			return true;
		}

		require_once __DIR__ . '/prestaAddress.class.php';
		$this->prestaAddressInvoice = new PrestaAddress($this->presta);
		if (!$this->prestaAddressInvoice->fetch($this->id_address_invoice, $cache)) {
			$this->prestaAddressInvoice = null;
			return false;
		}

		return true;
	}


	/**
	 *
	 * @return void
	 */
	public function fetchLines()
	{
		if (empty($this->associations->cart_rows)) {
			$this->prestaPropalDetails = [];
			return false;
		}

		$this->prestaPropalDetails = $this->associations->cart_rows;
		return true;
	}

	/**
	 * @param User $user
	 *
	 * @return false|int|void
	 */
	public function syncToDolibarr($user, $notrigger = 0)
	{
		global $conf, $langs,$mysoc;

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		// Check if synced
		$this->getDolLinkInfo();

		// skip if already sync
		if (!empty($this->linkObject)) {
			return true;
		}

		if (empty($this->prestaPropalDetails) && !$this->fetchLines('get')) {
			$this->setError('Error fetching cart detail from prestashop : no item');
			return false;
		}

		$this->fetchAddressDelivery();
		$this->fetchAddressInvoice();

		if (!$this->fetchCustomer(true)) {
			return false;
		}

		/*
		 * Step 01 - Get Customer and sync him if needed
		 */

		$resSyncPrestaCustomer = $this->prestaCustomer->syncToDolibarr($user, $this->prestaAddressInvoice);
		if (!$resSyncPrestaCustomer) {
			$this->setError('Sync customer error :' . $this->prestaCustomer->getLastError());
			return false;
		}

		if (empty($this->prestaCustomer->doliObject->id)) {
			$this->setError('Error presta customer link not found');
			return false;
		}

		$fk_soc = $this->prestaCustomer->doliObject->id;

		/*
		 * Step 2 - Get Adresses
		 */

		if (!$this->prestaAddressDelivery->syncToDolibarr($user, $fk_soc)) {
			$this->setError('Sync adress Delivery error :' . $this->prestaAddressDelivery->getLastError());
			return false;
		}

		if (!$this->prestaAddressInvoice->syncToDolibarr($user, $fk_soc)) {
			$this->setError('Sync adress Invoice error :' . $this->prestaAddressInvoice->getLastError());
			return false;
		}

		if (!$this->checkLinesForImport()) {
			$this->setError('Abort import, invalid line(s) detected');
			return false;
		}

		require_once DOL_DOCUMENT_ROOT . '/comm/propal/class/propal.class.php';
		$this->doliObject = new Propal($this->presta->db);
		$this->doliObject->socid = $fk_soc;
		$this->doliObject->entity = $this->presta->entity;
		$this->doliObject->fetch_thirdparty();

		$this->doliObject->import_key = 'P' . sprintf('%02d', $this->presta->id) . '-' . $this->id;
		$this->doliObject->date = $this->presta->db->jdate($this->date_add);
		$this->doliObject->note_private = '';
		$this->doliObject->note_public = '';
		$this->doliObject->model_pdf = getDolGlobalString('PROPALE_ADDON_PDF');

		$this->doliObject->ref_customer = 'Cart ' . $this->id;
		$this->doliObject->fk_project = $this->presta->fk_project;
		$this->doliObject->demand_reason_id = $this->presta->fk_c_input_reason;

		$this->doliObject->module_source = 'prestasync';
//		$this->doliObject->source = GETPOST('source_id'); // n'est pour l'instant pas vraiment géré par dolibarr
//		$this->doliObject->date_livraison = $date_delivery; // deprecated
//		$this->doliObject->delivery_date = $date_delivery;
//		$this->doliObject->shipping_method_id = ;
//		$this->doliObject->warehouse_id = ;
//		$this->doliObject->deposit_percent = ;
//		$this->doliObject->availability_id = ;
//		$this->doliObject->fk_account = ;
//		$this->doliObject->fk_incoterms = ;
//		$this->doliObject->location_incoterms = ;
//		$this->doliObject->multicurrency_code = ;
//		$this->doliObject->multicurrency_tx = ;
//		$this->doliObject->contact_id = GETPOST('contactid'); useless ?


		/**
		 * CREATE QUOTATION IN DATABASE
		 */
		$this->presta->db->begin();
		$resCreate = $this->doliObject->create($user, $notrigger);
		if ($resCreate < 0) {
			$this->setError($this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		// Update import_key because create doesn't set it
		$this->doliObject->db->query('UPDATE ' . $this->presta->db->prefix() . $this->doliObject->table_element . " SET import_key='" . $this->doliObject->db->escape($this->doliObject->import_key) . "' WHERE rowid=" . ((int) $this->doliObject->id));

		// Create link
		$this->doliElementId = $this->doliObject->id;
		if (!$this->setDolLink()) {
			$this->presta->db->rollback();
			return false;
		}

		if ($this->doliObject->add_contact($this->prestaAddressInvoice->doliObject->id, getDolGlobalString('PRESTASYNC_ORDER_CONTACT_BILLING'), 'external', $notrigger) < 0) {
			$this->setError('Error while add billing contact : ' . $this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		if ($this->doliObject->add_contact($this->prestaAddressDelivery->doliObject->id, getDolGlobalString('PRESTASYNC_ORDER_CONTACT_SHIPPING'), 'external', $notrigger) < 0) {
			$this->setError('Error while add shipping contact : ' . $this->doliObject->errorsToString());
			$this->presta->db->rollback();
			return false;
		}

		// Check remise
		$remisePercent = 0;

		foreach ($this->prestaPropalDetails as $line) {
			$dolProductId = 0;
			$productRef = '';
			$unitPrice = 0;
			$productName = '';
			if($line->id_product > 0 ){
				$prestaProduct = new PrestaProduct($this->presta);
				if(!$prestaProduct->fetch($line->id_product)){
					$this->setError('Unable to fecth product in prestashop');
					return false;
				}
				$productRef = $prestaProduct->reference;
				$unitPrice = $prestaProduct->price;
				$productName = $prestaProduct->getTradValue($prestaProduct->name);
			}

			if($line->id_product_attribute > 0 ) {
				if (!class_exists('PrestaCombination')) { require_once __DIR__ . '/prestaCustomization.class.php'; }
				$prestaCombination = new PrestaCombination($this->presta);
				if(!$prestaCombination->fetch($line->id_product_attribute)){
					$this->setError('Unable to fetch product combination in prestashop');
					return false;
				}

				$productName = $prestaCombination->getProductCombinationName();
				$productRef = $prestaCombination->reference;
				$unitPrice+= $prestaCombination->price; // TODO : Price impact ?
			}

			// TODO : utiliser la liaison, ou conserver cette méthode qui permet de détecter les erreurs de référence ?
			if(!empty($productRef)){
				$dolProductId = PrestaProduct::checkProductRefExistsInDolibarr($productRef, $this->presta->entity);
				if ($dolProductId === false) {
					$this->setError('Error while searching product in database');
					return false;
				}
			}

			if ($dolProductId === 0 && empty($conf->global->PRESTASYNC_ALLOW_IMPORT_FREE_LINE)) {
				$this->setError('Error product not found in database');
				return false;
			}

			$desc = '';
			$type = 0;
			$buyPrice = 0;
			$tvaTx = get_default_tva($mysoc, $this->prestaCustomer->doliObject);
			if ($dolProductId === 0) {
				$desc = !empty($productRef) ? $productRef . ' - ' : '' ;
				$desc .= $productName;
				$unitPrice = $prestaProduct->price;
			} else {
				require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
				$product = new Product($this->presta->db);
				if ($product->fetch($dolProductId) <= 0) {
					$this->setError('Error fetching product');
					return false;
				}

				$type = $product->type;
				$buyPrice = $this->getProductBuyPrice($product);
				if ($buyPrice === false) {
					$this->setError('Error fetching buy price');
					return false;
				}

				// TODO : Ajouter une config pour le choix du comportement par defaut
				if(empty($unitPrice)){
					// on part de la base prestashop et c'est seulement si pas de prix que l'on utilise la dase dolibarr
					$unitPrice = $product->price;
				}

				$tvaTx = $product->tva_tx;
			}

			$addLineResult = $this->doliObject->addline(
				$desc,
				(float)$unitPrice,
				(float)$line->quantity,
				$tvaTx,
				0.0,
				0.0,
				$dolProductId,
				$remisePercent,
				'HT',
				round($unitPrice + $unitPrice * $tvaTx / 100,2),
				0,
				$type,
				-1,
				 0,
				 0,
				0,
				$buyPrice,
				'',
				'',
				'',
				[],
				null,
				'',
				0,
				0,
				0,
				0
			);

			if ($addLineResult < 0) {
				$this->setError('Error adding propal line : ' . $this->doliObject->errorsToString());
				return false;
			}

			// In some version of Prestasho WebService could fail due to unpached bug in Prestashop
			// TODO manage error according to Prestashop version
			$this->importCustomizationInPropalLine($user, $line, $addLineResult);
		}

		$this->presta->db->commit();

		// to avoid trigger object not loaded i reload object before valid
		$propal = new Propal($this->presta->db);
		$propal->fetch($this->doliObject->id);
		$this->doliObject = $propal;

		return true;
	}

	/**
	 * @param PrestaCartRow $prestaPropalDetail
	 * @param int               $dolibarrPropalLineId
	 */
	protected function importCustomizationInPropalLine(User $user, $prestaPropalDetail, $dolibarrPropalLineId){
		global $langs;


		if((int)$prestaPropalDetail->id_customization == 0) {
			return true;
		}

		if(empty($dolibarrPropalLineId)) {
			$this->setError('Missing dolibarrPropalLineId for importCustomizationInPropalLine');
			return false;
		}

		if(!class_exists('PrestaCustomization')) {
			require_once __DIR__ . '/prestaCustomization.class.php';
		}
		if(!class_exists('PrestaProductCustomizationField')) {
			require_once __DIR__ . '/prestaProductCustomizationFields.class.php';
		}
		if(!class_exists('PrestaImage')) {
			require_once __DIR__ . '/prestaImage.class.php';
		}

		$dLine = new PropaleLigne($this->presta->db);
		if($dLine->fetch($dolibarrPropalLineId) < 1){
			$this->setError('No fetch line for importCustomizationInPropalLine');
			return false;
		}

		// Initialize technical object to manage hooks. Note that conf->hooks_modules contains array
		$hookmanager = new HookManager($this->presta->db); // re create hook manager to avoid hookCeption
		$params = [
			'prestaPropalDetail' => $prestaPropalDetail,
			'PrestaPropal' => $this,
		];
		$hookmanager->initHooks(array('prestacardclass'));
		$reshook = $hookmanager->executeHooks('importCustomizationInPropalLine', $params, $dLine);
		if ($reshook < 0) {
			// error
			return false;
		}

		if ($reshook > 0) {
			// Hook replace behavior
			return true;
		}

		$customization= new PrestaCustomization($this->presta);
		if(!$customization->fetch((int)$prestaPropalDetail->id_customization)) {
			$this->setError('Prestashop Customization not found : '.$customization->getLastError());
			return false;
		}

		$idsOfCustomizationField = [];
		if(!empty($customization->associations->customized_data_text_fields)) {
			foreach ($customization->associations->customized_data_text_fields as $customizedDataTextFields) {
				$idsOfCustomizationField[] = $customizedDataTextFields->id_customization_field;
			}
		}

		if(!empty($customization->associations->customized_data_images)) {
			foreach ($customization->associations->customized_data_images as $customizedDataImages) {
				$idsOfCustomizationField[] = $customizedDataImages->id_customization_field;
			}
		}

		$idsOfCustomizationField = array_unique($idsOfCustomizationField);
		$filters = [
			'id' => [
				'operator' => 'or',
				'search' => $idsOfCustomizationField
			]
		];

		$customizationFields = new PrestaProductCustomizationField($this->presta);
		$allCustomizationFields = $customizationFields->fetchAll([], [], $filters, 999,  0, [], false);
		if(!$allCustomizationFields){
			$this->setError('Prestashop Customization field not found : '.$customizationFields->getLastError());
			return false;
		}

		$descUseHtml = isModEnabled('fckeditor') && getDolGlobalInt('FCKEDITOR_ENABLE_DETAILS');
		$lineBreak = $descUseHtml ? '<br/>' : "\r\n";

		// Pour respecter l'ordre de Prestashop on se base sur les résultats de $allCustomizationFields
		foreach ($allCustomizationFields as $customizationFieldId => $customizationField) {

			$customizationName = dol_escape_htmltag($customizationField->getTradValue($customizationField->name));

			if (!empty($dLine->desc)) {
				$dLine->desc.= $lineBreak;
			}

			if($descUseHtml){
				$dLine->desc.= '<strong>' . $customizationName . ':</strong> ';
			} else {
				$dLine->desc.= $customizationName.': ';
			}


			if((int)$customizationField->type === 0) {
				// IMAGE
				if(!empty($customization->associations->customized_data_images)) {
					foreach ($customization->associations->customized_data_images as $customizedDataImageFields) {
						if((int)$customizedDataImageFields->id_customization_field != (int)$customizationFieldId) {
							continue;
						}

						$image = new PrestaImage($this->presta);
						$photoName = $image->importImageCustomizationDolPropalLine($this->doliObject,  $dLine,$customization, $customizedDataImageFields);
						if(!$photoName){
							$this->setError($image->getErrors());
							$dLine->desc.= $langs->trans('ErrorGettingImageFromShop');
							break;
						}

						if($descUseHtml){
							$dLine->desc.= '<span class="prestasync-line-customization-photo-lazy-link" data-file="'.dol_escape_htmltag(dol_escape_htmltag($photoName)).'" data-propal="'.$this->doliObject->id.'" >' . $photoName . '</span> ';
						} else {
							$dLine->desc.= $photoName;
						}
						break;
					}
				}
			}
			else{
				// TEXT
				if(!empty($customization->associations->customized_data_text_fields)) {
					foreach ($customization->associations->customized_data_text_fields as $customizedDataTextFields) {
						if((int)$customizedDataTextFields->id_customization_field != (int)$customizationFieldId) {
							continue;
						}

						$dLine->desc.= dol_escape_htmltag($customizedDataTextFields->value);
						break;
					}
				}
			}
		}

		$resUp = $dLine->update($user);
		if($resUp<1){
			return false;
		}

		return true;
	}

	/**
	 * TODO : this is a duplicated method present in prestaOrder.class.php : create trait ?
	 *
	 * @param $array
	 * @param $value
	 *
	 * @return false|null
	 */
	public static function closestValue($array, $value)
	{
		// Vérifie que le tableau n'est pas vide
		if (empty($array)) {
			return false;
		}

		// Initialise la variable pour la valeur la plus proche
		$closest = null;
		$smallestDifference = PHP_INT_MAX;

		// Parcourt le tableau pour trouver la valeur la plus proche
		foreach ($array as $element) {
			$difference = abs($element - $value);
			if ($difference < $smallestDifference) {
				$smallestDifference = $difference;
				$closest = $element;
			}
		}

		return $closest;
	}

	/**
	 * TODO : Convert to Propale
	 * @param          $newTotal
	 * @param Commande $commande
	 * @param bool     $modeTaxIncl
	 * @param false    $globalPlane
	 *
	 * @return bool|null
	 */
	public function fixTotalToAmount($newTotal, Commande &$commande, $modeTaxIncl = true, $globalPlane = false)
	{
		$coef = 1;
		$fieldTotal = 'total_ttc';
		if (!$modeTaxIncl) $fieldTotal = 'total_ht';

		$newTotal = floatval($newTotal);
		$commande->{$fieldTotal} = floatval($commande->{$fieldTotal});

		$commande->db->begin();
		$lastLine = false;
		if ($globalPlane) {
			if (!empty($commande->{$fieldTotal}) && $commande->{$fieldTotal} != 0) {
				$coef = $newTotal / $commande->{$fieldTotal};
			}

			if ($coef === 1) {
				return null;
			}

			$lastLine = false;
			foreach ($commande->lines as $line) {
				$line->tva_tx = floatval($line->tva_tx);
				$line->subprice = floatval($line->subprice);

				$tx_tva = 1 + ($line->tva_tx / 100);
				$puTTC = $line->subprice * $tx_tva; // calcul du ttc unitaire

				if (!$modeTaxIncl) {
					$tx_tva = 1;
					$puTTC = $line->subprice;
				}

				$puTTC = $puTTC * $coef; // on applique le coef de réduction
				$puHT = $puTTC / $tx_tva; // calcul du nouvel ht unitaire

				self::updateDolPropalLine($commande, $line, $puHT);
				$lastLine = $line;
			}
		} elseif (!empty($commande->lines)) {
			$lastLine = end($commande->lines);
		}

		if ($lastLine) {
			// on ajoute à la dernière ligne la différence de centime
			$lastLine->fetch($lastLine->id);

			if (!$modeTaxIncl) $tx_tva = 1;
			else $tx_tva = 1 + ($lastLine->tva_tx / 100);

			$diffComptaTot = $newTotal - $commande->{$fieldTotal}; // diff entre le total voulu et le nouveau total calculé (décalage de centimes)
			$diffComptaUnit = $diffComptaTot / $lastLine->qty; // diff à diviser par la qty car on doit obtenir au final un prix unitaire
			$newLineTotTTCToGet = $lastLine->total_ttc + $diffComptaTot; // Le nouveau total TTC de la ligne à obtenir

			$puTTC = $lastLine->subprice * $tx_tva + $diffComptaUnit; // calcul du ttc unitaire
			$puHT = $puTTC / $tx_tva; // calcul du nouvel ht unitaire

			// Détermine la précision attendue si supérieur à 2 chiffres
			$newTotalPrecision = max(static::getNumPrecision($newLineTotTTCToGet), 2);

			for ($precision = 2; $precision <= 6; $precision++) {
				$roundedPuHT = round($puHT, $precision);
				if (round($roundedPuHT * $lastLine->qty * $tx_tva, $newTotalPrecision) == round($newLineTotTTCToGet, $newTotalPrecision)) {
					$puHT = $roundedPuHT;
					break;
				}
			}

			self::updateDolPropalLine($commande, $lastLine, $puHT);
		}

		if (round($commande->{$fieldTotal}, 2) != round($newTotal, 2)) {
			$commande->db->rollback();
			return false;
		}

		$commande->db->commit();
		return true;
	}

	public static function getNumPrecision($floatNum, $removeTraillingZero = true)
	{
		$floatNum = strval($floatNum);

		if ($removeTraillingZero) {
			$floatNum = rtrim($floatNum, "0");
		}
		$length = strlen($floatNum);
		$pos = strpos($floatNum, "."); // zero-based counting.
		return ($length - $pos) - 1; // -1 to compensate for the zero-based count in strpos()
	}

	/**
	 * TODO : A modifier pour les Propales
	 * @param Propal  $object
	 * @param PropaleLigne $line
	 * @param float     $puHT
	 *
	 * @return int
	 */
	public static function updateDolPropalLine(Propal $object, PropaleLigne $line, float $puHT)
	{
		return $object->updateline($line->id, $line->desc, $puHT, $line->qty, $line->remise_percent, $line->tva_tx, $line->localtax1_tx, $line->localtax2_tx, 'HT', $line->info_bits, $line->date_start, $line->date_end, $line->product_type, $line->fk_parent_line, $line->skip_update_total, 0, $line->pa_ht, $line->label, $line->special_code, $line->array_options, $line->fk_unit);
	}


	public function checkLinesForImport()
	{
		global $conf;

		if (empty($this->prestaPropalDetails)) {
			$this->setError('cart has no line');
			return false;
		}

		foreach ($this->prestaPropalDetails as $line) {

			if (!class_exists('PrestaProduct')) { require_once __DIR__ . '/prestaProduct.class.php'; }
			$prestaProduct = new PrestaProduct($this->presta);
			$productRef = $prestaProduct->getProductRefFromPresta((int)$line->id_product, (int)$line->id_product_attribute);
			if(empty($productRef)){
				$this->setError($prestaProduct->getErrors());
				return false;
			}

			$checkProductRefExists = PrestaProduct::checkProductRefExistsInDolibarr($productRef, $this->presta->entity);
			if ($checkProductRefExists === false || ($checkProductRefExists === 0 && empty($conf->global->PRESTASYNC_ALLOW_IMPORT_FREE_LINE))) {
				$this->setError(($line->product_reference??'Product ') . ' not found in Dolibarr');
				return false;
			}
		}

		return true;
	}

	/**
	 * TODO : this is a duplicated method present in prestaOrder.class.php : create trait ?
	 * @param Product $product
	 *
	 * @return false|float
	 */
	public function getProductBuyPrice(Product $product)
	{
		global $conf, $hookmanager, $action;

		$hookmanager->initHooks(['prestasyncCardDao']);

		$parameters = ['productId' => $product->id, 'product' => $product];
		$reshook = $hookmanager->executeHooks('prestassync_getProductBuyPrice', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) {
			return $hookmanager->resPrint;
		}

		$daysOffset = !empty($conf->global->PRESTASYNC_BUY_PRICE_DAYS_OFFSET) ? intval($conf->global->PRESTASYNC_BUY_PRICE_DAYS_OFFSET) : 0;
		$mode = !empty($conf->global->PRESTASYNC_BUY_PRICE_CALC_MODE) ? $conf->global->PRESTASYNC_BUY_PRICE_CALC_MODE : 'avg';
		if (!in_array($mode, ['avg', 'max', 'min', 'percent'])) {
			$mode = 'avg';
		}

		if ($mode != 'percent') {
			$sql = 'SELECT AVG(price) avg_price, MAX(price) max_price, MIN(price) min_price';
			$sql .= ' FROM ' . MAIN_DB_PREFIX . 'product_fournisseur_price WHERE  fk_product = \'' . intval($product->id) . '\' AND entity IN (' . getEntity('product') . ') ';
			$sql .= ' AND price > 0 '; // to avoid missing prices

			if ($daysOffset > 0) {
				$sql .= 'AND tms > NOW() - INTERVAL ' . $daysOffset . ' DAY';
			}

			$obj = $this->presta->db->getRow($sql);
			if ($obj === false) {
				return false;
			}
			if ($obj) {
				if ($mode == 'avg' && floatval($obj->avg_price) > 0) {
					return floatval($obj->avg_price);
				}

				if ($mode == 'max' && floatval($obj->max_price) > 0) {
					return floatval($obj->max_price);
				}

				if ($mode == 'min' && floatval($obj->min_price) > 0) {
					return floatval($obj->min_price);
				}
			}

			if ($product->cost_price > 0) {
				return $product->cost_price;
			}
		}

		if (empty($product->cost_price) && !empty($product->pmp)) {
			return $product->pmp;
		}

		return $this->calcDefaultBuyPrice($product->price);
	}

	/**
	 * TODO : this is a duplicated method present in prestaOrder.class.php : create trait ?
	 * @param float $price
	 *
	 * @return false|float
	 */
	public function calcDefaultBuyPrice($price)
	{
		global $conf;
		$percent = !empty($conf->global->PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT) ? intval($conf->global->PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT) : 0;
		return floatval($price) * $percent / 100;
	}

	/**
	 * TODO : this is a duplicated method present in prestaOrder.class.php : create trait ?
	 * @param float $oldNumb
	 * @param float $newNum
	 *
	 * @return false|float
	 */
	public static function calcVATVariationPercent(float $oldNumb, float $newNum)
	{
		// TODO : add result check against database
		// 	to be sure VAT exist

		if ($oldNumb == 0) {
			return false;
		}

		return round(($newNum - $oldNumb) / $oldNumb * 100, 2);
	}


}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
require_once __DIR__ . '/prestaCommonObject.class.php';

class PrestaProductCategory extends PrestaCommonObject
{

	/**
	 * The Dolibarr element to sync with
	 *
	 * @var string
	 */
	public $doliElement = 'category_product';

	/**
	 * the Dolibarr linked object
	 *
	 * @var Societe $doliObject ;
	 */
	public $doliObject;

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'categories';

	public $fields = [
		'id' => [],
		'id_parent' => [],
		'level_depth' => [],
		'nb_products_recursive' => [],
		'active' => [],
		'id_shop_default' => [],
		'is_root_category' => [],
		'position' => [],
		'date_add' => [],
		'date_upd' => [],
		'name' => [
			'langs' => true,
		],
		'link_rewrite' => [
			'langs' => true,
		],
		'description' => [
			'langs' => true,
		],
		'additional_description' => [
			'langs' => true,
		],
		'meta_title' => [
			'langs' => true,
		],
		'meta_description' => [
			'langs' => true,
		],
		'meta_keywords' => [
			'langs' => true,
		],
		'associations' => [
			'subObjectMapping' => [
				'categories' => [
					'id' => [],
				],
				'products' => [
					'id' => [],
				],
			],
		],
	];


	public $defaultDisplayFields = [
		'id', 'id_parent', 'level_depth', 'nb_products_recursive', 'active', 'id_shop_default', 'is_root_category', 'position', 'date_add', 'date_upd', 'name', 'description'
	];

	public $id;
	public $id_parent;
	public $level_depth;
	public $nb_products_recursive;
	public $active;
	public $id_shop_default;
	public $is_root_category;
	public $position;
	public $date_add;
	public $date_upd;

	// Variables avec support multilingue
	public $name;
	public $link_rewrite;
	public $description;
	public $additional_description;
	public $meta_title;
	public $meta_description;
	public $meta_keywords;

	// Associations
	public $associations;

	public function fetchAllFromParent($id_parent, $fields = [], $useCache = true)
	{
		if (empty($fields)) {
			$fields = $this->defaultDisplayFields;
		}

		return $this->fetchAll($fields, [], ['id_parent' => $id_parent], 0, 0, [], $useCache, 300);
	}

	public function fetchAllRoot($fields = [], $useCache = true)
	{
		if (empty($fields)) {
			$fields = $this->defaultDisplayFields;
		}

		return $this->fetchAll($fields, [], ['id_parent' => 0, 'level_depth' => 0], 0, 0, [], $useCache, 300);
	}


	/**
	 * Return HTML string to show a field into a page
	 * Code very similar with showOutputField of extra fields
	 *
	 * @param string $key       Key of attribute
	 * @param string $value     Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
	 * @param string $moreparam To add more parametes on html input tag
	 * @param mixed  $morecss   Value for css to define size. May also be a numeric.
	 *
	 * @return string
	 */
	public function showOutputFieldQuick($key, $moreparam = '', $morecss = '')
	{
		global $langs;

		if ($key == 'active') {
			if (!empty($this->active)) {
				return dolGetBadge($langs->trans('Activated'), '', 'success');
			} else {
				return dolGetBadge($langs->trans('Disabled'), '', 'status9');
			}
		}

		if ($key == 'link_rewrite') {
			return '<a href="' . $this->getUrl() . '" target="_blank">' . $this->getUrl() . '</a>';
		}


		return parent::showOutputFieldQuick($key, $moreparam, $morecss);
	}

	public function getUrl()
	{
		return rtrim($this->presta->shop_url, '/') . '/index.php?id_category=' . $this->id . '&rewrite=' . $this->getTradValue($this->link_rewrite) . '&controller=categories';
	}

	/**
	 * @param User $user
	 *
	 * @return false|int|void
	 */
	public function syncToDolibarr($user, $syncDeeper = false, $syncParent = false, $notrigger = 0)
	{
		global $conf, $langs;

		// Check if synced
		$this->getDolLinkInfo();


		$category = new Categorie($this->presta->db);

		$createMode = true;
		if (!empty($this->linkObject)) {
			$createMode = false;
			if (!$this->fetchDolibarrObject()) {
				return false;
			}
			$fetchRes = $category->fetch($this->doliElementId);
			if ($fetchRes < 0) {
				return false;
			}

			if ($fetchRes == 0) {
				$this->getDolibarrIdFromPrestaId($this->id, true); // not found use auto clean function
				$createMode = true;
			}
		}

		/**
		 * IMPORT / UPDATE CATEGORY
		 */

		$category->label = $this->getTradValue($this->name);
		if (empty($category->label)) {
			$this->setError('Invalid category name');
			return false;
		}

		if ((int) $this->id === 1) { // Because is_root_category can be 0 for root but root is only id 1 in presta
			$category->label = $this->presta->label . ' : ' . $category->label;
		}

		$category->type = Categorie::TYPE_PRODUCT;

		// Import du parent
		if (!empty($this->id_parent) ) {
			$parentDolibarrCat = $this->getDolibarrIdFromPrestaId($this->id_parent, true);
			if ($parentDolibarrCat === 0 && $syncParent) {
				$parentCat = new self($this->presta);
				if (!$parentCat->fetch($this->id_parent)) {
					$this->setError('FailToFetchParentPrestashopCategory');
					return false;
				}

				$resParent = $parentCat->syncToDolibarr($user, false, true, $notrigger);
				if (!$resParent) {
					$this->setError($parentCat->getErrors());
					return false;
				}

				$category->fk_parent = $parentCat->doliElementId;
			} else {
				// TODO Update parent ?

				$category->fk_parent = $parentDolibarrCat;
			}
		}

		$category->description = $this->getTradValue($this->description);

		if ($createMode) {
			/**
			 * CREATE
			 */
			$resCreate = $category->create($user, $notrigger);
			if ($resCreate <= 0) {
				$errMsg = [
					-1 => 'SQL error',
					-2 => 'new ID unknown',
					-3 => 'Invalid category',
					-4 => 'category already exists',
				];

				if (isset($errMsg[$resCreate])) {
					$this->setError($errMsg[$resCreate]);
				} else {
					$this->setError('Error create category');
				}

				return false;
			}

			if ($category->fetch($resCreate) <= 0) {
				$this->setError('Category id : [' . $resCreate . '] not found');
				return false;
			}

			// ADD link
			$this->doliElementId = $category->id;
			$this->doliObject = $category;
			if (!$this->setDolLink()) {
				return false;
			}
		} else {
			/**
			 * UPDATE
			 */
			if ($category->update($user) <= 0) {
				$this->setError($category->errorsToString());
				return false;
			}
		}

		if ($syncDeeper) {
			$filters = [];
			$filters['id_parent'] = [
				'operator' => 'literal',
				'search' => $this->id,
			];

			$listLimit = 100;
			$opt = [];

			$opt['limit'] = $listLimit + 1;
			$page = 0;

			while ($subCats = $this->presta->getFromWebService($this->resource, $this->defaultDisplayFields, ['id' => 'ASC'], $filters, false, false, $opt)) {

				foreach ($subCats as $subCat){
					$prestaProductSubCategory = new PrestaProductCategory($this->presta);
					$prestaProductSubCategory->populate($subCat);
					$prestaProductSubCategory->getDolLinkInfo();
					if (!$prestaProductSubCategory->syncToDolibarr($user, true, false, $notrigger)) {
						$this->setError('Fail sync children of : ' . $this->getTradValue($this->name));
						if ($prestaProductSubCategory->getErrors()) {
							$this->setError($prestaProductSubCategory->getErrors());
						}
					}
				}

				$page++;
				$opt['limit'] = intval(($listLimit * intval($page))) . ',' . ($listLimit + 1);
			}
		}

		return true;
	}

	/**
	 * @param int $id
	 *	Return id of dolibarr category
	 *
	 * @return int
	 */
	public function getDolibarrIdFromPrestaId($id, $autoClean = false){

		$sql = 'SELECT rowid id, fk_presta, presta_resource, presta_resource_id, dol_element,dol_element_id, date_creation, tms
					FROM ' . $this->presta->db->prefix() . 'prestasync_resource_element
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND presta_resource = \'' . $this->presta->db->escape($this->resource) . '\'
						AND presta_resource_id = ' . (int)$id . '
    			';

		$obj = $this->presta->db->getRow($sql);
		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj == 0) {
			return 0;
		}


		$sql = 'SELECT rowid id FROM ' . $this->presta->db->prefix() . 'categorie WHERE rowid = ' . (int) $obj->dol_element_id;
		$objCheckDolCat = $this->presta->db->getRow($sql);
		if ($objCheckDolCat === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($objCheckDolCat === 0) {
			if($autoClean){
				if(!$this->presta->db->query('DELETE FROM ' . $this->presta->db->prefix() . 'prestasync_resource_element WHERE rowid = ' . (int) $obj->dol_element_id)){
					$this->setError($this->presta->db->error());
					return false;
				}else{
					return 0;
				}
			}else{
				$this->setError('Link break for cat id '. (int)$obj->dol_element_id);
				return false;
			}
		}

		return (int) $obj->dol_element_id;
	}
}

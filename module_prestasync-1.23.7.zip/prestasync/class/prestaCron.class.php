<?php

class PrestasCron
{

	public $output;

	/**
	 * @return    int    0 if OK, < 0 if KO (this function is used also by cron so only 0 is OK)
	 */
	function exportProductStockAndPrice($offset = '', $useLastExportTimestamp = false, $forceUnlimitedStock = false)
	{
		global $db, $conf;

		$lastExportTimestamp = 0;
		if (!empty($conf->global->lastExportProductStockAndPrice)) {
			$lastExportTimestamp = intval($conf->global->lastExportProductStockAndPrice);
		}

		$supplierWithStockOverride = [
			// TODO add a query or setup to add soc for stock override
		];

		$folderPath = DOL_DATA_ROOT .($conf->entity > 1 ? '/'.$conf->entity : ''). '/prestasync';
		$filePath = $folderPath . '/export-stock.csv';

		if (!is_dir($folderPath)) {
			dol_mkdir($folderPath, DOL_DATA_ROOT);
		}

		if (file_exists($filePath)) {
			unlink($filePath); // on supprime le fichier à chaque appel pour être sur
		}

		if (empty($offset)) {
			$offset = 0;
		}

		$sql = 'SELECT p.rowid, p.ref, p.stock, p.price, p.price_ttc, p.price_base_type, p.tva_tx, p.tosell, p.fk_product_type, p.pmp';

		if (!empty($supplierWithStockOverride)) {
			$sql .= ', (SELECT count(pf.rowid) FROM ' . MAIN_DB_PREFIX . 'product_fournisseur_price pf WHERE pf.fk_product = p.rowid AND pf.fk_soc IN(' . implode(',', $supplierWithStockOverride) . ')) as stockOverride ';
		}

		$sql .= ' , p.url ';
		$sql .= ' FROM ' . MAIN_DB_PREFIX . 'product p ';
		$sql .= ' WHERE entity IN ('.getEntity('product').') ';

		if ($useLastExportTimestamp && !empty($lastExportTimestamp)) {
			$sql .= ' AND p.tms >= \'' . $db->idate($lastExportTimestamp) . '\' ';
		} elseif (!empty($offset)) {
			$sql .= ' AND p.tms > \'' . $db->idate(time() - $offset) . '\' ';
		}
		$separator = ";";
		$resql = $db->query($sql);
		if ($resql) {
			$i = 0;
			$fp = fopen($filePath, 'w');
			while ($obj = $db->fetch_object($resql)) {
				if (
					intval($obj->fk_product_type) == 1  // Unlimited stock for services
					|| $forceUnlimitedStock
					|| !empty($obj->stockOverride)
				) {
					$obj->stock = 99999;
				}

				if (empty($obj->tosell)) {
					$obj->stock = 0;
				}

				// Pour éviter les stats complétement pétées ... un calcul du pmp même aproximatif et préférable
				if (empty($obj->pmp)) {
					$sqlFournPrice = 'SELECT AVG(fp.unitprice) as avg_price FROM ' . MAIN_DB_PREFIX . 'product_fournisseur_price as fp WHERE fp.fk_product = ' . $obj->rowid . ' AND fp.unitprice > 0 ';
					$supliyerQuery = $db->getRow($sqlFournPrice);
					if ($supliyerQuery && $supliyerQuery->avg_price > 0) {
						$obj->pmp = $supliyerQuery->avg_price;
					}
				}

				$fields = [
					'ref' => $obj->ref,
					'stock' => intval(floor($obj->stock)),
					'price' => $obj->price,
					'price_ttc' => $obj->price_ttc,
					'price_base_type' => $obj->price_base_type,
					'tva_tx' => $obj->tva_tx,
					'tosell' => $obj->tosell,
					'wholesale_price' => round($obj->pmp, 3),
					'presta' => !empty($obj->url),
				];

				if ($i == 0) {
					fputcsv($fp, array_keys($fields), $separator);
				}

				$i++;
				fputcsv($fp, $fields, $separator);
			}
			fclose($fp);

			$this->output = $i . ' products exported';

			return 0;
		} else {
			$this->error = $db->lasterror();
			return -1;
		}
	}
}

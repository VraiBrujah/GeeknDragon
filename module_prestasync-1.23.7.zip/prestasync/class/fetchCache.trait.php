<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

namespace prestasync;

trait fetchCache
{

	/**
	 * @var self[]
	 */
	public static $fetchCache = [];

	/**
	 * Load object in memory from the database
	 *
	 * @param int    $id  Id object
	 * @param string $ref Ref
	 *
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	static public function fetchCache($id)
	{
		global $db;
		if (!empty(static::$fetchCache[$id])) {
			return static::$fetchCache[$id];
		}

		$object = new static($db);
		if ($object->fetch($id) > 0) {
			static::$fetchCache[$id] = $object;
			return $object;
		}

		return false;
	}

}

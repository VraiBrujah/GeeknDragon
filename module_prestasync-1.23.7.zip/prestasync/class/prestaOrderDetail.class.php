<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

require_once __DIR__ . '/prestaCommonObject.class.php';
require_once __DIR__ . '/prestaCustomization.class.php';

class PrestaOrderDetail extends PrestaCommonObject
{

	/**
	 * The Prestashop WebService resource
	 *
	 * @var string
	 */
	public $resource = 'order_details';

	public $fields = [
		'id' => [],
		'id_order' => [],
		'product_id' => [],
		'product_attribute_id' => [],
		'product_quantity_reinjected' => [],
		'group_reduction' => [],
		'discount_quantity_applied' => [],
		'download_hash' => [],
		'download_deadline' => [],
		'id_order_invoice' => [],
		'id_warehouse' => [],
		'id_shop' => [],
		'id_customization' => [],
		'product_name' => [],
		'product_quantity' => [],
		'product_quantity_in_stock' => [],
		'product_quantity_return' => [],
		'product_quantity_refunded' => [],
		'product_price' => [],
		'reduction_percent' => [],
		'reduction_amount' => [],
		'reduction_amount_tax_incl' => [],
		'reduction_amount_tax_excl' => [],
		'product_quantity_discount' => [],
		'product_ean13' => [],
		'product_isbn' => [],
		'product_upc' => [],
		'product_mpn' => [],
		'product_reference' => [],
		'product_supplier_reference' => [],
		'product_weight' => [],
		'tax_computation_method' => [],
		'id_tax_rules_group' => [],
		'ecotax' => [],
		'ecotax_tax_rate' => [],
		'download_nb' => [],
		'unit_price_tax_incl' => [],
		'unit_price_tax_excl' => [],
		'total_price_tax_incl' => [],
		'total_price_tax_excl' => [],
		'total_shipping_price_tax_excl' => [],
		'total_shipping_price_tax_incl' => [],
		'purchase_supplier_price' => [],
		'original_product_price' => [],
		'original_wholesale_price' => [],
		'total_refunded_tax_excl' => [],
		'total_refunded_tax_incl' => [],
		'associations' => [],
	];

	public $id;
	public $id_order;
	public $product_id;
	public $product_attribute_id;
	public $product_quantity_reinjected;
	public $group_reduction;
	public $discount_quantity_applied;
	public $download_hash;
	public $download_deadline;
	public $id_order_invoice;
	public $id_warehouse;
	public $id_shop;
	public $id_customization;
	public $product_name;
	public $product_quantity;
	public $product_quantity_in_stock;
	public $product_quantity_return;
	public $product_quantity_refunded;
	public $product_price;
	public $reduction_percent;
	public $reduction_amount;
	public $reduction_amount_tax_incl;
	public $reduction_amount_tax_excl;
	public $product_quantity_discount;
	public $product_ean13;
	public $product_isbn;
	public $product_upc;
	public $product_mpn;
	public $product_reference;
	public $product_supplier_reference;
	public $product_weight;
	public $tax_computation_method;
	public $id_tax_rules_group;
	public $ecotax;
	public $ecotax_tax_rate;
	public $download_nb;
	public $unit_price_tax_incl;
	public $unit_price_tax_excl;
	public $total_price_tax_incl;
	public $total_price_tax_excl;
	public $total_shipping_price_tax_excl;
	public $total_shipping_price_tax_incl;
	public $purchase_supplier_price;
	public $original_product_price;
	public $original_wholesale_price;
	public $total_refunded_tax_excl;
	public $total_refunded_tax_incl;
	public $associations;
}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

trait PrestaCustomLinkInfo
{

	public $linkTable;
	public $linkTableDoliCol;
	public $linkTablePrestaCol;

	public function setCustomDolLink()
	{
		if (method_exists($this, 'checkCreateLinkReady') && !$this->checkCreateLinkReady()) {
			return false;
		}

		$sql = 'INSERT INTO ' . $this->presta->db->prefix() . $this->linkTable . '
					 ( fk_presta, ' . $this->linkTablePrestaCol . ',' . $this->linkTableDoliCol . ', date_creation, tms)
					 VALUES
					 ( ' . intval($this->presta->id) . ', ' . intval($this->id) . ', ' . intval($this->doliElementId) . ', NOW(), NOW())
    			';

		if (!$this->presta->db->query($sql)) {
			$this->setError('Error setLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->getDolLinkInfo();

		return true;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	protected function getCustomTableDolLinkInfo()
	{
		$this->linkObject = null;

		$sql = 'SELECT rowid id, fk_presta, ' . $this->linkTableDoliCol . ', ' . $this->linkTablePrestaCol . ', date_creation, tms
					FROM ' . $this->presta->db->prefix() . $this->linkTable . '
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND ' . $this->linkTablePrestaCol . ' = ' . intval($this->id) . '
    			';

		$this->doliElementId = false;
		$obj = $this->presta->db->getRow($sql);

		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj === 0) {
			$this->doliElementId = 0;
			return 0;
		}

		$this->doliElementId = intval($obj->{$this->linkTableDoliCol});
		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->tms);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	protected function getCustomTablePrestaLinkInfo()
	{
		$this->linkObject = null;

		$sql = 'SELECT rowid id, fk_presta, ' . $this->linkTableDoliCol . ', ' . $this->linkTablePrestaCol . ', date_creation, tms
					FROM ' . $this->presta->db->prefix() . $this->linkTable . '
					WHERE
						fk_presta = ' . $this->presta->id . '
						AND ' . $this->linkTableDoliCol . ' = ' . intval($this->doliElementId) . '
    			';

		$obj = $this->presta->db->getRow($sql);

		if ($obj === false) {
			$this->setError($this->presta->db->error());
			return false;
		}

		if ($obj == 0) {
			return 0;
		}

		$obj->tms = $this->presta->db->jdate($obj->tms);
		$obj->date_creation = $this->presta->db->jdate($obj->tms);
		$this->linkObject = $obj;
		return $this->linkObject;
	}

	/**
	 * @param CommonObject $object
	 *
	 * @return false|int|static false on fail, 0 on not found object on result
	 * @deprecated see loadFromDolObject
	 */
	public static function loadFormDolObject($object)
	{
		return static::loadFromDolObject($object);
	}

	/**
	 * @param CommonObject $object
	 *
	 * @return false|int|static false on fail, 0 on not found object on result
	 */
	public static function loadFromDolObject($object)
	{
		require_once __DIR__ . '/presta.class.php';
		$presta = new Presta($object->db);
		$prestaObject = new static($presta);
		$sql = 'SELECT rowid id, fk_presta, ' . $prestaObject->linkTableDoliCol . ', ' . $prestaObject->linkTablePrestaCol . '
					FROM ' . $object->db->prefix() . $prestaObject->linkTable . '
					WHERE
						' . $prestaObject->linkTableDoliCol . ' = ' . intval($object->id) . '
    			';

		$obj = $presta->db->getRow($sql);

		if ($obj === false) {
			return false;
		}

		if ($obj == 0) {
			return 0;
		}

		/* Now clean $object and load linked */
		$presta = Presta::fetchCache($obj->fk_presta);
		if (!$presta) {
			return false;
		}

		$prestaObject = new static($presta);
		$res = $prestaObject->fetch($obj->{$prestaObject->linkTablePrestaCol});
		if ($res <= 0) {
			return false;
		}

		return $prestaObject;
	}

	/**
	 * @return bool
	 */
	public function delCustomTablePrestaLinkInfo()
	{
		if (empty($this->linkObject)) {
			$this->getDolLinkInfo();
		}

		if (empty($this->linkObject)) {
			return false;
		}

		$sql = 'DELETE FROM ' . $this->presta->db->prefix() . $this->linkTable . ' WHERE rowid = ' . intval($this->linkObject->id);
		if (!$this->presta->db->query($sql)) {
			$this->setError('Error delLink of ' . get_class($this) . ' : ' . $this->presta->db->error());
			return false;
		}

		$this->linkObject = null;
		$this->doliElementId = 0;
		return true;
	}

	public function setDolLink()
	{
		return $this->setCustomDolLink();
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getDolLinkInfo()
	{
		return $this->getCustomTableDolLinkInfo();
	}

	/**
	 * @return bool|int|object   false on fail, 0 on not found object on result
	 */
	public function getPrestaLinkInfo()
	{
		return $this->getCustomTablePrestaLinkInfo();
	}

	/**
	 * @return bool
	 */
	public function delDolLink()
	{
		return $this->delCustomTablePrestaLinkInfo();
	}
}

<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *  \file       presta_note.php
 *  \ingroup    prestasync
 *  \brief      Tab for notes on Presta
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB', '1');				// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER', '1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC', '1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN', '1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION', '1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION', '1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK', '1');				// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL', '1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK', '1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU', '1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML', '1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX', '1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN", '1');					// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK', '1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT', 'auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule');	// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN', 1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP', 'none');				// Disable all Content Security Policies
//if (! defined('CSRFCHECK_WITH_TOKEN'))     define('CSRFCHECK_WITH_TOKEN', '1');		// Force use of CSRF protection with tokens even for GET
//if (! defined('NOBROWSERNOTIF'))     		 define('NOBROWSERNOTIF', '1');				// Disable browser notification

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once __DIR__ . '/class/presta.class.php';
require_once __DIR__ . '/class/prestaProduct.class.php';
require_once __DIR__ . '/class/prestaProductOptionValue.class.php';
require_once __DIR__ . '/lib/prestasync_presta.lib.php';
require_once __DIR__ . '/lib/prestasync.lib.php';
require_once __DIR__ . '/class/prestaTax.class.php';
require_once __DIR__ . '/class/prestaLib.class.php';
require_once __DIR__ . '/core/modules/modPrestasync.class.php';

// Load translation files required by the page
$langs->loadLangs(["prestasync@prestasync", "companies"]);

// Get parameters
$id = GETPOST('id', 'int');
$prestaId = GETPOST('presta_id', 'int');
$ref = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$cancel = GETPOST('cancel', 'aZ09');
$confirm = GETPOST('confirm', 'int');
$showmeattribute = GETPOST('showmeattribute', 'int');
$backtopage = GETPOST('backtopage', 'alpha');
$presta_combination_id = GETPOST('presta_combination_id', 'array:aZ09');
$thisDefaultUrl = dol_buildpath('prestasync/presta_product.php', 1) . '?id=' . $id . '&presta_id=' . $prestaId;

// Initialize technical objects
$object = new Presta($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->prestasync->dir_output . '/temp/massgeneration/' . $user->id;
$hookmanager->initHooks(['prestaproduct', 'globalcard']); // Note that conf->hooks_modules contains array
// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

// Load object
include DOL_DOCUMENT_ROOT . '/core/actions_fetchobject.inc.php'; // Must be include, not include_once  // Must be include, not include_once. Include fetch and fetch_thirdparty but not fetch_optionals
if ($id > 0 || !empty($ref)) {
	$upload_dir = $conf->prestasync->multidir_output[!empty($object->entity) ? $object->entity : $conf->entity] . "/" . $object->id;
}

if (empty($object->id)) {
	dol_print_error($db);
	exit();
}

// There is several ways to check permission.
// Set $enablepermissioncheck to 1 to enable a minimum low level of checks

$enablepermissioncheck = 1;
$permissiontoread = $user->hasRight('prestasync', 'presta', 'read');
$permissiontoadd = $user->hasRight('prestasync', 'presta', 'write');
$permissiontodelete = $user->hasRight('prestasync', 'presta', 'delete');

// Security check (enable the most restrictive one)
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->status == $object::STATUS_DRAFT) ? 1 : 0);
//restrictedArea($user, $object->element, $object->id, $object->table_element, '', 'fk_soc', 'rowid', $isdraft);
if (empty($conf->prestasync->enabled)) accessforbidden();
if (!$permissiontoread) accessforbidden();

if ($object->id > 0) {
	$prestaProduct = new PrestaProduct($object);
	if (!$prestaProduct->fetch($prestaId)) {
		dol_print_error('', $prestaProduct->getLastError());
		exit;
	}

	$prestaProduct->fetchCombinations();
}

/*
 * Actions
 */
$confToJs = [
	'MAIN_MAX_DECIMALS_TOT' => getDolGlobalInt('MAIN_MAX_DECIMALS_TOT'),
	'MAIN_MAX_DECIMALS_UNIT' => getDolGlobalInt('MAIN_MAX_DECIMALS_UNIT'),
	'interfaceUrl' => dol_buildpath('prestasync/interface.php', 1),
	'token' => newToken(),
//	'userRight'					=> array(
//		'read' => intval($permissionToView),
//		'write' => intval($permissionToAdd),
//	)
];

$jsLangs = [
	'Saved' => $langs->trans('Saved'),
	'errorAjaxCall' => $langs->trans('ErrorAjaxCall'),
	'CloseDialog' => $langs->trans('Close'),
	'errorAjaxCallDisconnected' => $langs->trans('Disconnected'),
];

// Display error message when conf is missing
$confsToCheck = [

];

$parameters = [
	'jsLangs' => &$jsLangs,
	'confToJs' => &$confToJs,
	'confsToCheck' => &$confsToCheck,
];
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) {
	setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
}
if (empty($reshook)) {
	if ($action == 'startSync') {
		$object->clearWebServiceCache(false, true);
		$prestaProduct->clearErrors();
		if ($prestaProduct->syncToDolibarr($user)) {
			setEventMessage($langs->trans('Success'));
		} else {
			setEventMessage($prestaProduct->getErrors(), 'errors');
		}

		header("Location: " . $thisDefaultUrl); // Default behaviour is redirect to index.php page
		exit;
	}

	if ($action == 'startSyncCombination') {
		$object->clearWebServiceCache(false, true);
		if (!empty($presta_combination_id)) {
			$prestaProduct->clearErrors();
			if ($prestaProduct->syncCombinationsIdsToDolibarr($user, $presta_combination_id)) {
				setEventMessage($langs->trans('Success'));
			} else {
				setEventMessage($prestaProduct->getErrors(), 'errors');
			}
		} else {
			setEventMessage($langs->trans("PleaseSelectAtLeastOneLine"), 'errors');
		}

		$action = '';
	}

	if ($action == 'linkcombinationwithproduct') {
		$prestaProduct->clearErrors();
		$dolibarr_product_id = GETPOSTINT('doli_product_id');

		if (empty($presta_combination_id)) {
			$prestaCombinationIdNotArray = GETPOSTINT('presta_combination_id');
			if ($prestaCombinationIdNotArray > 0) {
				$presta_combination_id = [$prestaCombinationIdNotArray];
			}
		}

		if (!empty($presta_combination_id) && is_array($presta_combination_id)) {
			foreach ($presta_combination_id as $combination_id) {
				if (isset($prestaProduct->combinations[$combination_id])) {
					$dolProduct = new Product($db);
					if ($dolProduct->fetch(null, $prestaProduct->combinations[$combination_id]->reference) > 0) {
						if (!$prestaProduct->combinations[$combination_id]->linkToExistingDolibarrProduct($dolProduct->id)) {
							setEventMessage($prestaProduct->getErrors(), 'errors');
						}
					}
				} else {
					setEventMessage($langs->trans('CombinationNotFound') . ' : ' . $combination_id);
				}
			}
		} else {
			setEventMessage($langs->trans('InvalidDataSend'), 'warnings');
		}

		$action = '';
	}

	if ($action == 'removelinkcombinationwithproduct') {
		$prestaProduct->clearErrors();
		$dolibarr_product_id = GETPOSTINT('doli_product_id');

		if (empty($presta_combination_id)) {
			$prestaCombinationIdNotArray = GETPOSTINT('presta_combination_id');
			if ($prestaCombinationIdNotArray > 0) {
				$presta_combination_id = [$prestaCombinationIdNotArray];
			}
		}

		if (!empty($presta_combination_id) && is_array($presta_combination_id)) {
			foreach ($presta_combination_id as $combination_id) {
				if (isset($prestaProduct->combinations[$combination_id])) {
					if (!$prestaProduct->combinations[$combination_id]->delDolLink()) {
						setEventMessage($prestaProduct->getErrors(), 'errors');
					}
				} else {
					setEventMessage($langs->trans('CombinationNotFound') . ' : ' . $combination_id);
				}
			}
		} else {
			setEventMessage($langs->trans('InvalidDataSend'), 'warnings');
		}

		$action = '';
	}

	if ($action == 'linkwithproduct') {
		$prestaProduct->clearErrors();
		$dolibarr_product_id = GETPOSTINT('doli_product_id');

		if ($prestaProduct->linkToExistingDolibarrProduct($dolibarr_product_id)) {
			setEventMessage($langs->trans('Success'));
		} else {
			setEventMessage($prestaProduct->getErrors(), 'errors');
		}

		header("Location: " . $thisDefaultUrl); // Default behaviour is redirect to index.php page
		exit;
	}

	if ($action == 'updateCombinationFormPrestashop' && $cancel == 1) {
		header("Location: " . $thisDefaultUrl); // Default behaviour is redirect to index.php page
		exit;
	} elseif ($action == 'updateCombinationFormPrestashop' && $confirm == 1) {
		if (!empty($presta_combination_id)) {
			$object->clearWebServiceCache(false, true);

			$fieldsAvailable = [
				'confirm-label' => 'label',
				'confirm-sell-price' => 'price',
				'confirm-barcode' => 'barcode',
				'confirm-weight' => 'weight',
				'confirm-image' => 'image',
				'confirm-clear_images' => 'clear_images',
			];

			$fieldsToUpdate = [];
			foreach ($fieldsAvailable as $field => $type) {
				$checked = GETPOST($field, 'int');
				if (!empty($checked)) {
					$fieldsToUpdate[] = $type;
				}
			}

			$buyPriceBehavior = GETPOST('confirm-buy-price', 'alphanohtml');
			if ($buyPriceBehavior && in_array($buyPriceBehavior, ['buy-price-no-update', 'buy-price-no-zero', 'buy-price-new-only', 'buy-price-force'])) {
				$fieldsToUpdate[] = $buyPriceBehavior;
			}

			if (!empty($fieldsToUpdate)) {
				$prestaProduct->clearErrors();

				if ($prestaProduct->syncCombinationsIdsToDolibarr($user, $presta_combination_id, 0, $fieldsToUpdate)) {
					setEventMessage($langs->trans('Success'));
				} else {
					setEventMessage($prestaProduct->getErrors(), 'errors');
				}
			} else {
				setEventMessage($langs->trans("PleaseSelectAtLeastOneFieldToUpdate"), 'errors');
			}
		} else {
			setEventMessage($langs->trans("PleaseSelectAtLeastOneLine"), 'errors');
		}

		$action = '';

		header("Location: " . $thisDefaultUrl); // Default behaviour is redirect to index.php page
		exit;
	}
}

if (!empty($confsToCheck)) {
	foreach ($confsToCheck as $confToCheck) {
		if (!isset($conf->global->$confToCheck)) {
			setEventMessage($langs->trans('MissingSetupStepConfiguration') . ' : ' . $langs->trans($confToCheck), 'errors');
		}
	}
}

/*
 * View
 */

$form = new Form($db);

//$help_url='EN:Customers_Orders|FR:Commandes_Clients|ES:Pedidos de clientes';
$help_url = modPrestasync::webPageHelp;
$title = $langs->trans('Presta') . ' - ' . $prestaProduct->reference . ' ' . $prestaProduct->showOutputFieldQuick('name');

llxHeader('', $title, $help_url, '', 0, 0, [
	'prestasync/js/product.js',
	'prestasync/js/ps-live-webservice.js',
], [
	'prestasync/css/prestasync.css',
]);

/**
 * Init Live edit
 */
print '<script nonce="' . getNonce() . '" >psLiveEdit.init(' . json_encode($confToJs) . ', ' . json_encode($jsLangs) . ');</script>';

if ($object->id > 0) {
	$object->fetch_thirdparty();

	$head = prestaPrepareHead($object);

	print dol_get_fiche_head($head, 'products', $langs->trans("Presta"), -1, $object->picto);

	presta_product_ressourc_banner_generic($object, $prestaProduct);

	$head = prestaProductPrepareHead($object, $prestaProduct);
	$picto = ($prestaProduct->useCombinations() ? 'fa-cubes' : 'product');
	print dol_get_fiche_head($head, 'card', $langs->trans("Presta"), 1, $picto);

	print '<div class="fichecenter">';
	print '	<div class="fichehalfleft">';

	print '		<div class="underbanner clearboth"></div>';

	print '		<table class="border centpercent tableforfield"><tbody>';

	$fields = [

		'name',
//		'description_short',
		'date_add',
		'date_upd',
		'link_rewrite',
		'active',
	];
	foreach ($fields as $fieldKey) {
		$fieldParam = $prestaProduct->fields[$fieldKey];

		if (in_array($fieldParam['visible'], [0])) {
			continue;
		}

		print $prestaProduct->getCardFieldLine($fieldKey);
	}


	print '				</tbody></table>';

	print '	</div>' . "\n";

	print '	<div class="fichehalfright">';

	print '		<div class="underbanner clearboth"></div>';

	print '		<table class="border centpercent tableforfield"><tbody>';

	$fields = [
		'manufacturer_name',
		'reference',
		'ean13',
		'is_virtual',
//		'state', // useless it a flag set when product is open on admin panel
//		'additional_delivery_times',
//		'product_type',
		'on_sale',
//		'online_only',
		'ecotax',
		'minimal_quantity',
		'price',
		'wholesale_price',
//		'unity', TODO : seem to be not used in prestashop but...
//		'unit_price',
//		'unit_price_ratio',
//		'additional_shipping_cost',
//		'customizable',
//		'text_fields',
//		'available_for_order'
	];
	foreach ($fields as $fieldKey) {
		print $prestaProduct->getCardFieldLine($fieldKey);
	}

	print '		</tbody></table>';

	print '	</div>';

	print '</div>';

	print '<div style="clear: both; min-height: 1em;"></div>';

	if (!empty($prestaProduct->combinations)) {

		// TODO : Improve UX using Ajax and lazy loading, transform all action to JS and AJAX

		print '<form method="post" action="' . $_SERVER['PHP_SELF'] . '?id=' . $object->id . '&presta_id=' . $prestaId . '">';
		print '<input type="hidden" name="token" value="' . newToken() . '"/>';
//		print '<input type="hidden" name="id" value="'.$object->id.'"/>';
//		print '<input type="hidden" name="presta_id" value="'.$prestaId.'"/>';

		$actionsGroup = '<div id="mass-action-block" >'; // style="display: none;"
		$actionsGroup .= '<strong>' . $langs->trans("MassActions") . ' </strong>';

		$actionList = [
			'startSyncCombination' => $langs->trans('SyncPrestaProductInDolibarr'),
			'linkcombinationwithproduct' => $langs->trans('CreateAPrestaDoliLink'),
			'updateCombinationFormPrestashop' => $langs->trans('UpdateCombinationFormPrestashop'),
		];

		$actionsGroup .= $form->selectArray('action', $actionList, $action);

		$actionsGroup .= ' <button class="button" type="submit">' . $langs->trans("Confirm") . '</button>';

		$actionsGroup .= '</div>';

		// disable select
		if (isset($actionList[$action])) {
			$actionsGroup = '';
		}

		print load_fiche_titre($langs->trans('ProductsCombinations'), count($prestaProduct->combinations) . ' / ' . count($prestaProduct->associations->combinations), 'product', '', 'title-combination-id', '', $actionsGroup);

		if ($action == 'updateCombinationFormPrestashop') {
			print '<fieldset id="update-combination-confirmform" class="confirm-field-set" >';
			print '<legend>' . $langs->trans('ConfirmUpdate') . '</legend>';

			print '<input type="hidden" name="action" value="updateCombinationFormPrestashop" />';

			print '<label class="form-group --all" >';
			print '<input type="checkbox" name="confirm-all" id="toggle-check-all-mass-action" /> ' . $langs->trans('All');
			print '</label>';

			print '<label class="form-group" >';
			print '<input class="toggle-check" type="checkbox" name="confirm-label" value="1" /> ' . $langs->trans('Label');
			print '</label>';

			print '<label class="form-group" >';
			print '<input class="toggle-check" type="checkbox" name="confirm-sell-price" value="1" /> ' . $langs->trans('SellPrice');
			print '</label>';

			print '<div class="form-group" >';
			print '		<label >';
			print '			<input class="toggle-check" type="checkbox" name="confirm-image" value="1" /> ' . $langs->trans('Images');
			print '		</label>';

			print '		<label  >';
			print '			<small>( <input  type="checkbox" name="confirm-clear_images" value="1" /> ' . $langs->trans('ClearImagesOnImport') . ' )</small>';
			print '		</label>';
			print '</div>';

			print '<label class="form-group" >';
			print '<input class="toggle-check" type="checkbox" name="confirm-weight" value="1" /> ' . $langs->trans('Weight');
			print '</label>';

			print '<label class="form-group" >';
			print '<input class="toggle-check" type="checkbox" name="confirm-barcode" value="1" /> ' . $langs->trans('Barcode');
			print '</label>';

			print '<br/>';

			print '<div class="" >';
			print $langs->trans('BuyPrice') . ' : ';

			print '	<label class="form-group" >';
			print '		<input class="toggle-check" type="radio" name="confirm-buy-price" value="buy-price-no-update" checked="checked" /> ' . $langs->trans('BuyPriceNoUpdate');
			print '	</label>';

			print '	<label class="form-group" >';
			print '		<input class="toggle-check" type="radio" name="confirm-buy-price" value="buy-price-new-only" /> ' . $langs->trans('BuyPriceNewOnly');
			print '	</label>';

			print '	<label class="form-group" >';
			print '		<input class="toggle-check" type="radio" name="confirm-buy-price" value="buy-price-force" /> ' . $langs->trans('BuyPriceForce');
			print '	</label>';

			print '	<label class="form-group" >';
			print '		<input class="toggle-check" type="radio" name="confirm-buy-price" value="buy-price-no-zero" /> ' . $langs->trans('BuyPriceNoZero');
			print '	</label>';
			print '</div>';

			print '<hr/>';
			print '<button class="button" type="submit" name="cancel" value="1">' . $langs->trans('Cancel') . '</button>';
			print '<button class="button" type="submit" name="confirm" value="1"  >' . $langs->trans('Confirm') . '</button>';
			print '</fieldset>';

			print '<script nonce="' . getNonce() . '" >$(document).ready(function(){ $(\'html, body\').animate({scrollTop:$("#update-combination-confirmform").offset().top}, 300, \'easeInSine\');});</script>';
		}

		print '<table id="tablelines" class="noborder noshadow ui-sortable" >';
		print '<thead>';

		$colNb = 0;
		print '<tr class="liste_titre nodrag nodrop">';

		print '	<td class="linecolreference" colspan="2">';
		print $langs->trans('Reference');
		print '	</td>';
		$colNb++;

		print '	<td class="linecolcombinationname">';
		print $langs->trans('ProductCombination');
		print '	</td>';
		$colNb++;

		print '	<td class="linecolpriceimpact right">';
		print $langs->trans('PriceImpact');
		print '	</td>';
		$colNb++;

		print '	<td class="linecolprice right">';
		print $langs->trans('Price');
		print '	</td>';
		$colNb++;

		print '	<td class="linecolweightImpact right">';
		print $langs->trans('WeightImpact');
		print '	</td>';
		$colNb++;

		print '	<td class="linecolweight right">';
		print $langs->trans('Weight');
		print '	</td>';
		$colNb++;

//		print '	<td class="linecolsupplierRef">';
//		print $langs->trans('SupplierReference');
//		print '	</td>';
//		$colNb++;
//
//		print '	<td class="linecolsupplierPrice">';
//		print $langs->trans('PrestaSupplierPrice');
//		print '	</td>';
//		$colNb++;

		print '	<td class="linecolsyncstate" >';
		print $langs->trans('Dolibarr');
		print '	</td>';
		$colNb++;

		print '	<td class="linecoldolref" >';
		print $langs->trans('psyncDolibarrRef');
		print '	</td>';
		$colNb++;

		print '	<td class="linecoldolprice" >';
		print $langs->trans('DolibarrPrice');
		print '	</td>';
		$colNb++;

		print '	<td class="linecoldolaction" >';
		print '<input data-toggle-check-target=".toggle-checkbox-for-combination" type="checkbox" />';
		print '	</td>';
		$colNb++;

		print '</tr>';

		print '</thead>';
		print '<tbody>';

		$numInputFormat = function ($num) {
			$fmt = new NumberFormatter('en_US', NumberFormatter::DECIMAL);
			$fmt->setAttribute(NumberFormatter::MIN_FRACTION_DIGITS, 2);
			return $fmt->format($num);
		};

		$liveUpdateReady = true;
		if((int)$prestaProduct->presta->shop_version == 0 || (int)$prestaProduct->presta->shop_version < 8) {
			$liveUpdateReady = false;
		}

		$inputUpdateReadyDisabled = $liveUpdateReady ? '' : ' disabled="1" ';
		$inputUpdateReadyDisabledTitle = $liveUpdateReady ? '' : ' title="'.dol_escape_htmltag($langs->trans('LiveUpdateDisabledForPrestashopUnderV8')).'" ';

		$productToCreate = 0;
		foreach ($prestaProduct->combinations as $combination) {

			$doliProductCombination = false;
			$combination->getDolLinkInfo();

			// load product linked
			if (!$combination->doliObject && $combination->getLinkStatus() == $combination::STATUS_LINKED) {
				$combination->fetchDolibarrObject();
			}

			if ($combination->getLinkStatus() == $combination::STATUS_NOT_LINKED) {
				$productToCreate++;
			}

			$lineMoreClass = '';
			if (intval($showmeattribute) == intval($combination->id)) {
				$lineMoreClass = 'show-me-attribute';
			}

			print '<tr id="attribute-row-' . intval($combination->id) . '" class="nodrag nodrop ' . $lineMoreClass . '">';

			print '		<td class="linecolimg" style="width: 36px;">';
			$imageFound = false;
			if (!empty($combination->associations->images)) {
				$firstImg = reset($combination->associations->images);
				if(is_object($firstImg)) {
					$imgLink = $combination->getImageLink($firstImg->id);
					if ($imgLink) {
						print '<img style="max-width:100%; max-height:100%" src="' . $imgLink . '" />';
					}
				}
			}

			if (!$imageFound) {
				$imgLink = $prestaProduct->getDefaultImageLink();
				if (!empty($imgLink)) {
					print '<img style="max-width:32px; max-height:32px;" src="' . $imgLink . '" />';
				}
			}

			print '		</td>';

			print '		<td class="linecoldescription">';
			$attr = [
				'data-presta' => $object->id,
				'data-col' => 'reference',
				'data-webservice-resource' => $combination->resource,
				'data-webservice-resource-id' => $combination->id,
				'autocomplete' => 'off',
				'placeholder' => $langs->trans('Ref'),
				'type' => 'text',
				'value' => $combination->reference,
			];

			print '			<input ' . prestaLib::genHtmlAttr($attr) . ' '.$inputUpdateReadyDisabled.' '.$inputUpdateReadyDisabledTitle.' class="ps-live-edit-input ps-list-input "  />';
//			print '			<strong>'.$combination->showOutputFieldQuick('reference').'</strong>';
			print '		</td>';

			print '		<td class="linecolcombinationname">';
			print            $combination->getProductCombinationName(true);
			print '		</td>';

			print '		<td class="linecolpriceimpact">';
			$attr = [
				'data-presta' => $object->id,
				'data-col' => 'price',
				'data-webservice-resource' => $combination->resource,
				'data-webservice-resource-id' => $combination->id,
				'autocomplete' => 'off',
				'placeholder' => '0.00',
				'type' => 'number',
				'step' => 'any',
				'value' => $numInputFormat($combination->price),
			];

			print '			<input ' . prestaLib::genHtmlAttr($attr) . ' '.$inputUpdateReadyDisabled.' '.$inputUpdateReadyDisabledTitle.' class="ps-live-edit-input ps-list-input" />';
			print '		</td>';

			print '		<td class="linecolprice">';
			$finalPrice = floatval($combination->price) + floatval($prestaProduct->price);
			$attr = [
				'data-webservice-resource-id' => $combination->id,
				'autocomplete' => 'off',
				'type' => 'number',
				'step' => 'any',
				'placeholder' => '0.00',
				'data-price' => $prestaProduct->price,
				'value' => $numInputFormat($finalPrice),
			];

			print '			<input ' . prestaLib::genHtmlAttr($attr) . ' '.$inputUpdateReadyDisabled.' '.$inputUpdateReadyDisabledTitle.' class="linked-to-price-impact ps-list-input"   />';
			print '		</td>';

			print '		<td class="linecolweightImpact">';

			$attr = [
				'data-presta' => $object->id,
				'data-col' => 'weight',
				'data-webservice-resource' => $combination->resource,
				'data-webservice-resource-id' => $combination->id,
				'autocomplete' => 'off',
				'placeholder' => '0.00',
				'type' => 'number',
				'step' => 'any',
				'value' => $numInputFormat($combination->weight),
			];

			print '			<input ' . prestaLib::genHtmlAttr($attr) . ' '.$inputUpdateReadyDisabled.' '.$inputUpdateReadyDisabledTitle.' class="ps-live-edit-input ps-list-input"  />';
			print '		</td>';

			print '		<td class="linecolweight">';
			$attr = [
				'data-webservice-resource-id' => $combination->id,
				'autocomplete' => 'off',
				'type' => 'number',
				'placeholder' => '0.00',
				'step' => 'any',
				'data-weight' => $prestaProduct->weight,
				'value' => $numInputFormat(floatval($combination->weight) + floatval($prestaProduct->weight)),
			];
			print '			<input ' . prestaLib::genHtmlAttr($attr) . ' '.$inputUpdateReadyDisabled.' '.$inputUpdateReadyDisabledTitle.' class="linked-to-weight-impact ps-list-input" />';
			print '		</td>';

//			print '		<td class="linecolsupplierRef">';
//			print 		$combination->supplier_reference;
//			print '		</td>';
//
//			print '		<td class="linecolsupplierPrice">';
//			print 		price(floatval($combination->wholesale_price));
//			print '		</td>';

			print '		<td class="linecolsyncstate">';
			print        $combination->getStatusBadge();
			print '		</td>';

			print '		<td class="linecoldolref">';
			if ($combination->doliObject) {
				if ($combination->reference != $combination->doliObject->ref) {
					print ' <span class="classfortooltip fa fa-exclamation-triangle error" title="' . dol_escape_htmltag($langs->trans('RefIsDiferent')) . '" ></span>';
				}

				print ' ' . $combination->doliObject->getNomUrl();


				if(!getDolGlobalInt('PRESTASYNC_PRODUCT_AUTO_LINK')){

					$doliproductId = $prestaProduct->doliObject->id??0;

					$url = $_SERVER["PHP_SELF"] . '?action=removelinkcombinationwithproduct&amp;token=' . newToken() . '&amp;id=' . $object->id . '&amp;presta_id=' . $prestaId . '&amp;presta_combination_id=' . $combination->id . '&amp;doli_product_id=' . $doliproductId;

					// for js disabled compatibility set $url as call to confirm action and $params['confirm']['url'] to confirmed action
					$attr = [];
					$attr['data-confirm-url'] = $url;
					$attr['data-confirm-title'] = $langs->trans('ConfirmBtnCommonTitle', $langs->trans('RemoveAPrestaDoliLink', $combination->reference, $prestaProduct->doliObject->ref??''));
					$attr['data-confirm-content'] = $langs->trans('ConfirmBtnCommonContent', $langs->trans('RemoveAPrestaDoliLink', $combination->reference, $prestaProduct->doliObject->ref??''));
					$attr['data-confirm-content'] = preg_replace("/\r|\n/", "", $attr['data-confirm-content']);
					$attr['data-confirm-action-btn-label'] = $langs->trans('Confirm');
					$attr['data-confirm-cancel-btn-label'] = $langs->trans('CloseDialog');
					$attr['data-confirm-modal'] = true;

					print ' <span class="butActionConfirm classfortooltip small-link-btn --remove" ' . prestaLib::genHtmlAttr($attr) . ' title="' . dol_escape_htmltag($langs->trans('RemoveAPrestaDoliLink')) . '" href="' . $url . '" ><i class="fas fa-unlink"></i></span>';
				}

			} elseif ($combination->getLinkStatus() != $combination::STATUS_LINKED) {
				$doliProductCombination = new Product($db);
				if ($doliProductCombination->fetch(null, $combination->reference) > 0) {
					print ' <span class="classfortooltip fa fa-info-circle" title="' . dol_escape_htmltag($langs->trans('ProductWithSameRefFound')) . '" ></span>' . ' ' . $doliProductCombination->getNomUrl();
					$url = $_SERVER["PHP_SELF"] . '?action=linkcombinationwithproduct&amp;token=' . newToken() . '&amp;id=' . $object->id . '&amp;presta_id=' . $prestaId . '&amp;presta_combination_id=' . $combination->id . '&amp;doli_product_id=' . $doliProductCombination->id;

					// for js disabled compatibility set $url as call to confirm action and $params['confirm']['url'] to confirmed action
					$attr = [];
					$attr['data-confirm-url'] = $url;
					$attr['data-confirm-title'] = $langs->trans('ConfirmBtnCommonTitle', $langs->trans('CreateAPrestaDoliLink', $combination->reference, $doliProductCombination->ref));
					$attr['data-confirm-content'] = $langs->trans('ConfirmBtnCommonContent', $langs->trans('CreateAPrestaDoliLink', $combination->reference, $doliProductCombination->ref));
					$attr['data-confirm-content'] = preg_replace("/\r|\n/", "", $attr['data-confirm-content']);
					$attr['data-confirm-action-btn-label'] = $langs->trans('Confirm');
					$attr['data-confirm-cancel-btn-label'] = $langs->trans('CloseDialog');
					$attr['data-confirm-modal'] = true;

					print ' <span class="butActionConfirm classfortooltip small-link-btn" ' . prestaLib::genHtmlAttr($attr) . ' title="' . dol_escape_htmltag($langs->trans('CreateAPrestaDoliLink')) . '" href="' . $url . '" ><i class="fa fa-link"></i></span>';
				} else {
					$doliProductCombination = false;
				}
			}
			print '		</td>';

			print '		<td class="linecoldolprice">';

			if ($combination->doliObject) {
				$priceDiff = prestaLib::priceEvo($finalPrice, $combination->doliObject->price);
				if ($priceDiff != 0) {
					$evoHelp = '';
					print prestaLib::displayEvo($priceDiff, 'badge') . ' &nbsp;';
				}

				print price($combination->doliObject->price);
			} elseif ($doliProductCombination) {
				$priceDiff = prestaLib::priceEvo($finalPrice, $doliProductCombination->price);
				if ($priceDiff != 0) {
					$evoHelp = '';
					print prestaLib::displayEvo($priceDiff, 'badge') . ' &nbsp;';
				}

				/** @var Product $doliProductCombination */
				print price($doliProductCombination->price);
			}
			print '		</td>';

			print '	<td class="linecoldolaction" >';
			$checkStatus = !empty($presta_combination_id[$combination->id]) ? ' checked="checked" ' : '';
			print '<input class="toggle-checkbox-for-combination" name="presta_combination_id[' . $combination->id . ']" type="checkbox" value="' . $combination->id . '" ' . $checkStatus . ' />';
			print '	</td>';
			$colNb++;

			print '</tr>';
		}

		print '</tbody>';
		print '</table>';

		print '</form>';
	}

	print '<div class="tabsAction">';

	$parameters = [];
	// Note that $action and $object may be modified by hook
	$reshook = $hookmanager->executeHooks('prestasync_addMoreActionsButtons', $parameters, $prestaProduct, $action);
	if (empty($reshook)) {
		if (empty($prestaProduct->combinations)) {
			// import product to prestashop
			$parms = [
				'attr' => [
					'title' => $langs->trans('ImportPrestaProductInDolibarrHelp'),
				],
			];

			print dolGetButtonAction('', $langs->trans('SyncPrestaProductInDolibarr'), 'default', $_SERVER["PHP_SELF"] . '?action=startSync&amp;token=' . newToken() . '&amp;id=' . $object->id . '&amp;presta_id=' . $prestaId, '', 1, $parms);
		}
	}

	print '</div>';

	print dol_get_fiche_end();
}

// End of page
llxFooter();
$db->close();

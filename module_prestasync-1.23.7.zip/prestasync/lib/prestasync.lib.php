<?php
/* Copyright (C) 2024 THERSANE www.thersane.fr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    prestasync/lib/prestasync.lib.php
 * \ingroup prestasync
 * \brief   Library files with common functions for Prestasync
 */

/**
 * Prepare admin pages header
 *
 * @return array
 */
function prestasyncAdminPrepareHead()
{
	global $langs, $conf;

	$langs->load("prestasync@prestasync");

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/prestasync/admin/setup.php", 1);
	$head[$h][1] = $langs->trans("Settings");
	$head[$h][2] = 'settings';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/admin/setup_ai.php", 1);
	$head[$h][1] = $langs->trans("PrestaAiSetup");
	$head[$h][2] = 'settings_ai';
	$h++;

//	$head[$h][0] = dol_buildpath("/prestasync/admin/setup_fix.php", 1);
//	$head[$h][1] = $langs->trans("PrestaFixSetup");
//	$head[$h][2] = 'settings_fix';
//	$h++;


	$head[$h][0] = dol_buildpath("/prestasync/admin/presta_extrafields.php", 1);
	$head[$h][1] = $langs->trans("ExtraFields");
	$head[$h][2] = 'presta_extrafields';
	$h++;


	$head[$h][0] = dol_buildpath("/prestasync/admin/about.php", 1);
	$head[$h][1] = $langs->trans("About");
	$head[$h][2] = 'about';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, null, $head, $h, 'prestasync@prestasync');

	complete_head_from_modules($conf, $langs, null, $head, $h, 'prestasync@prestasync', 'remove');

	return $head;
}


function prestaCardLineTitle($titleLabel){
	$out = '<tr class="field_tite " >';
	$out.= '	<td class="titlefield" colspan="3">';
	$out.= '		<strong>'.$titleLabel.'</strong>';
	$out.= '	</td>';
	$out.= '</tr>';

	return $out;
}


function prestaCardLine($titleLabel, $label, $moreCss = 'wordbreak'){
	$out = '<tr class="field_tite " >';
	$out.= '	<td class="titlefield" colspan="2" >';
	$out.= $titleLabel;
	$out.= '	</td>';
	$out.= '	<td class="valuefield '.$moreCss.'" >';
	$out.= $label;
	$out.= '	</td>';
	$out.= '</tr>';

	return $out;
}

function prestaSyncIsDeeplInstalled(){
	return !empty(getPrestaSyncIsDeeplKey());
}

function getPrestaSyncIsDeeplKey(){
	$key = getDolGlobalString('PRESTASYNC_DEEPL_API_KEY');
	if(!empty($key)) { return $key; }

	if(defined('PRESTASYNC_DEEPL_API_KEY')) { return PRESTASYNC_DEEPL_API_KEY; }

	return false;
}

/**
 * @param          $html
 * @param          $htmlClassToNotTranslate
 * @param string   $noTranslateClass
 * @param string[] $attrToRemove
 *
 * @return array|false|string|string[]
 */
function addNotTranslateClass($html, $htmlClassToNotTranslate, $noTranslateClass = 'notranslate', $attrToRemove = ['data-start', 'data-end']) {
	$dom = new DOMDocument();
	$dom->formatOutput = true;
	$dom->preserveWhiteSpace = true;

	// Désactiver les erreurs pour éviter les warnings liés au HTML mal formé
	libxml_use_internal_errors(true);

	$addedHtmlPrefix = '<?xml encoding="utf-8" ?>';

	$html = prestaSyncRemoveAttributesFromHtml($html, $attrToRemove) ;

	// Convertir en UTF-8 et ajouter une déclaration <meta> pour éviter les problèmes d'encodage
	$dom->loadHTML($addedHtmlPrefix . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
	libxml_clear_errors();

	$xpath = new DOMXPath($dom);

	foreach ($htmlClassToNotTranslate as $class) {
		// Sélectionner les éléments qui contiennent la classe recherchée
		$nodes = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $class ')]");

		foreach ($nodes as $node) {
			$currentClasses = $node->getAttribute('class');

			// Vérifier si la classe 'notranslate' est déjà présente
			if (strpos($currentClasses, $noTranslateClass) === false) {
				$node->setAttribute('class', trim($currentClasses . ' ' . $noTranslateClass));
			}
		}
	}




	return str_replace($addedHtmlPrefix, '', $dom->saveHTML());
}

function prestaSyncRemoveAttributesFromHtml($html, $attributes) {
	foreach ($attributes as $attr) {
		$pattern = '/\s*' . preg_quote($attr, '/') . '\s*=\s*"[^"]*"|\s*' . preg_quote($attr, '/') . "\s*=\s*'[^']*'/i";
		$html = preg_replace($pattern, '', $html);
	}
	return $html;
}


function prestaSyncDefaultProductPromptTxt(){
	global $langs;

	$br = "\r\n";
	$lineSep = $br." --- ".$br;

	$langs->load('prestasyncAI@prestasync');
	$prompt = $langs->trans('ps_SEOPrePrompt').$br;

	$prompt.= $br;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentDetails').$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductName'). ' : __PrestaProductName__'.$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductMetaTitle'). ' : __PrestaProductMetaTitle__'.$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductMetaDescription'). ' : __PrestaProductMetaDescription__'.$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductKeywords'). ' : __PrestaProductKeywords__'.$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductShortDescription'). ' : __PrestaProductShortDescription__'.$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductFullDescription'). ' : __PrestaProductFullDescription__'.$lineSep;
	$prompt.= $langs->trans('ps_SEOPrePromptProductCurrentProductURLRewrite'). ' : __PrestaProductURLRewrite__'.$lineSep;

	$prompt.= $br;
	$prompt.= $br;
	$prompt.= $langs->trans('ps_SEOPrePromptGoal').$br;
	$prompt.= '__PrestaGoalCurrentField__'.$br;

	$prompt.= $br;
	$prompt.= $langs->trans('ps_SEOPostPromptInstruction').$br;

	$prompt.= $br;
	$prompt.= $langs->trans('ps_SEOPostPromptLanguage', '__PRESTAOutputLang__').$br;


	return $prompt;
}


function prestaSyncMakeSubstitutionProductPromptTxt(PrestaProduct $prestaProduct, $fieldTarget, $languageName, $fieldsVal){
	global $langs;

	$prompt = getDolGlobalString('PRESTASYNC_AI_PRODUCT_PROMPT', prestaSyncDefaultProductPromptTxt());

	$fieldName = '';
	if(isset($prestaProduct->fields[$fieldTarget]) && $prestaProduct->fields[$fieldTarget]['labelKey']){
		$fieldName = $langs->trans($prestaProduct->fields[$fieldTarget]['labelKey']);
	}

	$br = "\r\n";
	$listOfSubstitutions = [
		'__PrestaShopURL__' => $prestaProduct->presta->shop_url,
		'__PrestaProductName__' => $fieldsVal['name'] ?? '',
		'__PrestaProductMetaTitle__' => $fieldsVal['meta_title'] ?? '',
		'__PrestaProductMetaDescription__' => $fieldsVal['meta_description'] ?? '',
		'__PrestaProductKeywords__' => $fieldsVal['meta_keywords'] ?? '',
		'__PrestaProductShortDescription__' => $fieldsVal['description_short'] ?? '',
		'__PrestaProductFullDescription__' => $fieldsVal['description'] ?? '',
		'__PrestaProductURLRewrite__' => $fieldsVal['link_rewrite'] ?? '',
		'__PrestaGoalCurrentField__' => '',// see below
		'__PrestaCurrentField__' => $fieldName,
		'__PrestaCurrentFieldCode__' => $fieldTarget,
		'__PrestaOutputLang__' => $languageName,
	];

	if($fieldTarget == 'description') {
		$listOfSubstitutions['__PrestaGoalCurrentField__'] = getDolGlobalString('PRESTASYNC_AI_PRODUCT_GOAL_FIELD_FULL_DESC',$langs->trans('ps_SEOPrePromptGoalFieldFullDescription').$langs->trans('ps_SEOPostPromptTarget'));
	} elseif($fieldTarget == 'description_short') {
		$listOfSubstitutions['__PrestaGoalCurrentField__'] = getDolGlobalString('PRESTASYNC_AI_PRODUCT_GOAL_FIELD_SHORT_DESC',$langs->trans('ps_SEOPrePromptGoalFieldShortDescription'));
	} elseif($fieldTarget != 'all'){
		$listOfSubstitutions['__PrestaGoalCurrentField__'] = getDolGlobalString('PRESTASYNC_AI_PRODUCT_GOAL_FIELD',$langs->trans('ps_SEOPrePromptGoalField'));
	}if($fieldTarget == 'all'){
		$listOfSubstitutions['__PrestaGoalCurrentField__'] = getDolGlobalString('PRESTASYNC_AI_PRODUCT_GOAL_ALL_FIELD', '');
	}

	// to replace substitution in prompt part
	$listOfSubstitutions['__PrestaGoalCurrentField__'] = make_substitutions($listOfSubstitutions['__PrestaGoalCurrentField__'], $listOfSubstitutions, $langs);

	if($fieldTarget != 'all') {
		$prompt .= $br . $langs->trans('ps_SEOPostPromptTarget');
	}else{
		$jsonEx = new stdClass();
		$jsonEx->ProductName = '';
		$jsonEx->MetaTitle = '';
		$jsonEx->MetaDescription = '';
		$jsonEx->Keywords = '';
		$jsonEx->ShortDescription = '';
		$jsonEx->FullDescription = '';
		$jsonEx->URLRewrite = '';

		$prompt .= $br . 'Important : Answer me only with a json object containing each fields and values, the JSON format is : '.json_encode($jsonEx);
	}

	return make_substitutions($prompt, $listOfSubstitutions, $langs);
}

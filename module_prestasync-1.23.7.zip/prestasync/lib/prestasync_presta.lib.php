<?php
/* Copyright (C) 2024 THERSANE www.thersane.fr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    lib/prestasync_presta.lib.php
 * \ingroup prestasync
 * \brief   Library files with common functions for Presta
 */

/**
 * Prepare array of tabs for Presta
 *
 * @param Presta $object Presta
 *
 * @return    array                    Array of tabs
 */
function prestaPrepareHead($object)
{
	global $db, $langs, $conf;

	$langs->load("prestasync@prestasync");

	$showtabofpagecontact = 1;
	$showtabofpagenote = 1;
	$showtabofpagedocument = 1;
	$showtabofpageagenda = 1;

	$h = 0;
	$head = [];

	$head[$h][0] = dol_buildpath("/prestasync/presta_card.php", 1) . '?id=' . $object->id;
	$head[$h][1] = $langs->trans("Card");
	$head[$h][2] = 'card';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/mappingpayment_list.php", 1) . '?search_fk_presta=' . $object->id;
	$head[$h][1] = $langs->trans("Parametters");
	$head[$h][2] = 'Parametters';
	$h++;

	// Useless pour l'instant
//	if ($showtabofpagecontact) {
//		$head[$h][0] = dol_buildpath("/prestasync/presta_contact.php", 1).'?id='.$object->id;
//		$head[$h][1] = $langs->trans("Contacts");
//		$head[$h][2] = 'contact';
//		$h++;
//	}

	if ($showtabofpagenote) {
		if (isset($object->fields['note_public']) || isset($object->fields['note_private'])) {
			$nbNote = 0;
			if (!empty($object->note_private)) {
				$nbNote++;
			}
			if (!empty($object->note_public)) {
				$nbNote++;
			}
			$head[$h][0] = dol_buildpath('/prestasync/presta_note.php', 1) . '?id=' . $object->id;
			$head[$h][1] = $langs->trans('Notes');
			if ($nbNote > 0) {
				$head[$h][1] .= (empty($conf->global->MAIN_OPTIMIZEFORTEXTBROWSER) ? '<span class="badge marginleftonlyshort">' . $nbNote . '</span>' : '');
			}
			$head[$h][2] = 'note';
			$h++;
		}
	}

	if ($showtabofpagedocument) {
		require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';
		require_once DOL_DOCUMENT_ROOT . '/core/class/link.class.php';
		$upload_dir = $conf->prestasync->dir_output . "/presta/" . dol_sanitizeFileName($object->ref);
		$nbFiles = count(dol_dir_list($upload_dir, 'files', 0, '', '(\.meta|_preview.*\.png)$'));
		$nbLinks = Link::count($db, $object->element, $object->id);
		$head[$h][0] = dol_buildpath("/prestasync/presta_document.php", 1) . '?id=' . $object->id;
		$head[$h][1] = $langs->trans('Documents');
		if (($nbFiles + $nbLinks) > 0) {
			$head[$h][1] .= '<span class="badge marginleftonlyshort">' . ($nbFiles + $nbLinks) . '</span>';
		}
		$head[$h][2] = 'document';
		$h++;
	}

	if ($showtabofpageagenda) {
		$head[$h][0] = dol_buildpath("/prestasync/presta_agenda.php", 1) . '?id=' . $object->id;
		$head[$h][1] = $langs->trans("Events");
		$head[$h][2] = 'agenda';
		$h++;
	}

	$head[$h][0] = dol_buildpath("/prestasync/presta_customers.php", 1) . '?id=' . $object->id;
	$head[$h][1] = $langs->trans("Customers");
	$head[$h][2] = 'customers';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/presta_carts.php", 1) . '?id=' . $object->id;
	$head[$h][1] = $langs->trans("Carts");
	$head[$h][2] = 'carts';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/presta_orders.php", 1) . '?id=' . $object->id;
	$head[$h][1] = $langs->trans("Orders");
	$head[$h][2] = 'orders';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/presta_products.php", 1) . '?id=' . $object->id;
	$head[$h][1] = $langs->trans("Products");
	$head[$h][2] = 'products';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'presta@prestasync');

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'presta@prestasync', 'remove');

	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

	$head[$h][0] = dol_buildpath("/prestasync/presta_card.php", 1) . '?id=' . $object->id . '&action=clearprestasynccache&token=' . newToken() . '&fk_presta=' . $object->id . '&backurl=' . urlencode($actual_link);
	$head[$h][1] = '<i class="fa fa-recycle" ></i> ' . $langs->trans("ClearCache");
	$head[$h][2] = 'clearprestasynccache';
	$h++;

	return $head;
}

/**
 * Prepare array of tabs for Presta
 *
 * @param Presta $object Presta
 *
 * @return    array                    Array of tabs
 */
function prestaOptionsPrepareHead($object)
{
	global $db, $langs, $conf;

	$langs->load("prestasync@prestasync");

	$showtabofpagecontact = 1;
	$showtabofpagenote = 1;
	$showtabofpagedocument = 1;
	$showtabofpageagenda = 1;

	$h = 0;
	$head = [];

	$head[$h][0] = dol_buildpath("/prestasync/mappingpayment_list.php", 1) . '?search_fk_presta=' . $object->id;
	$head[$h][1] = $langs->trans("Paiements");
	$head[$h][2] = 'paiements';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/mappingcarrier_list.php", 1) . '?search_fk_presta=' . $object->id;
	$head[$h][1] = $langs->trans("Carriers");
	$head[$h][2] = 'carriers';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/mappingsupplier_list.php", 1) . '?search_fk_presta=' . $object->id;
	$head[$h][1] = $langs->trans("Suppliers");
	$head[$h][2] = 'suppliers';
	$h++;

	if (getDolGlobalInt('PRESTASYNC_ALLOW_IMPORT_PRODUCT_CATS') && isModEnabled('categorie')) {
		$head[$h][0] = dol_buildpath("/prestasync/presta_categories.php", 1) . '?id=' . $object->id;
		$head[$h][1] = $langs->trans("Categories");
		$head[$h][2] = 'categories';
		$h++;
	}

	if (isModEnabled('cyberoffice')) {
		$head[$h][0] = dol_buildpath("prestasync/cyberoffice-import-products.php", 1) . '?id=' . $object->id;
		$head[$h][1] = $langs->trans("ImportFromCyberOffice");
		$head[$h][2] = 'cyberoffice';
		$h++;
	}

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'presta@prestasync');

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'presta@prestasync', 'remove');

	return $head;
}

/**
 *  Show tab footer of a card.
 *  Note: $object->next_prev_filter can be set to restrict select to find next or previous record by $form->showrefnav.
 *
 * @param PrestaCommonObject $object         Object to show
 * @param string             $morehtml       More html content to output just before the nav bar
 * @param int                $shownav        Show Condition (navigation is shown if value is 1)
 * @param string             $fieldid        Nom du champ en base a utiliser pour select next et previous (we make the select max and min on this field). Use 'none' for no prev/next search.
 * @param string             $fieldref       Nom du champ objet ref (object->ref) a utiliser pour select next et previous
 * @param string             $morehtmlref    More html to show after the ref (see $morehtmlleft for before)
 * @param string             $moreparam      More param to add in nav link url.
 * @param int                $nodbprefix     Do not include DB prefix to forge table name
 * @param string             $morehtmlleft   More html code to show before the ref (see $morehtmlref for after)
 * @param string             $morehtmlstatus More html code to show under navigation arrows
 * @param int                $onlybanner     Put this to 1, if the card will contains only a banner (this add css 'arearefnobottom' on div)
 * @param string             $morehtmlright  More html code to show before navigation arrows
 *
 * @return    void
 */
function presta_resource_banner_tab($object, $morehtml = '', $shownav = 1, $fieldid = 'id', $fieldref = 'reference', $morehtmlref = '', $moreparam = '', $nodbprefix = 0, $morehtmlleft = '', $morehtmlstatus = '', $onlybanner = 0, $morehtmlright = '')
{
	global $conf, $langs, $hookmanager, $action;

	$phototoshow = true;
	if (method_exists($object, 'getDefaultImageLink')) {
		$img = $object->getDefaultImageLink();
		if ($img) {
			$phototoshow = false;
			$morehtmlleft .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref">';
			$morehtmlleft .= '<img style="max-width:100%; max-height:100%" src="' . $img . '" />';
			$morehtmlleft .= '</div></div>';
		}
	}

	if ($phototoshow) {      // Show No photo link (picto of object)
		$width = 14;
		$cssclass = 'photorefcenter';

		$picto = $object->presta->picto;
		$prefix = 'object_';
		if (strpos($picto, 'fontawesome_') !== false) {
			$prefix = '';
		}
		$nophoto = img_picto('No photo', $prefix . $picto);

		$morehtmlleft .= '<!-- No photo to show -->';
		$morehtmlleft .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref">';
		$morehtmlleft .= $nophoto;
		$morehtmlleft .= '</div></div>';
	}

	$tmptxt = '';
	if (method_exists($object, 'getStatusBadge')) {
		$tmptxt = $object->getStatusBadge(5);
	}
	$morehtmlstatus .= $tmptxt;

	if (!empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && ($conf->global->MAIN_SHOW_TECHNICAL_ID == '1' || preg_match('/' . preg_quote($object->element, '/') . '/i', $conf->global->MAIN_SHOW_TECHNICAL_ID)) && !empty($object->id)) {
		$morehtmlref .= '<div style="clear: both;"></div>';
		$morehtmlref .= '<div class="refidno">';
		$morehtmlref .= $langs->trans("TechnicalID") . ': ' . $object->id;
		$morehtmlref .= '</div>';
	}

	$parameters = ['morehtmlref' => $morehtmlref];
	$reshook = $hookmanager->executeHooks('formDolBanner', $parameters, $object, $action);
	if ($reshook < 0) {
		setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
	} elseif (empty($reshook)) {
		$morehtmlref .= $hookmanager->resPrint;
	} elseif ($reshook > 0) {
		$morehtmlref = $hookmanager->resPrint;
	}

	print '<div class="' . ($onlybanner ? 'arearefnobottom ' : 'arearef ') . 'heightref valignmiddle centpercent">';
	print prestaShowRefNav($object, $morehtml, $shownav, $fieldid, $fieldref, $morehtmlref, $morehtmlleft, $morehtmlstatus, $morehtmlright);
	print '</div>';
	print '<div class="underrefbanner clearboth"></div>';
}

/**
 * @param Presta $object
 * @param PrestaProduct $prestaProduct
 */
function presta_product_ressourc_banner_generic($object, $prestaProduct){
	global $db,$langs, $doliProduct;
	$prestaId = $prestaProduct->id;

	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="' . dol_buildpath('/prestasync/presta_products.php', 1) . '?restore_lastsearch_values=1&id=' . $object->id . (!empty($socid) ? '&socid=' . $socid : '') . '">' . $langs->trans("BackToList") . '</a>';

	if ($prestaProduct) {
		$resFetchDol = $prestaProduct->fetchDolibarrObject();
	}



	// Ref customer
	$morehtmlref = '<div class="refidno">';
	$morehtmlref .='<div id="head-prestashop-product-name">' .$prestaProduct->showOutputFieldQuick('name') . '</div>';
	$morehtmlref .='<small id="head-prestashop-product-link"><a href="' . $prestaProduct->getUrl() . '" target="_blank" ><span class="fa fa-link"></span> ' .$langs->trans('SeeOnWebSite') . '</a></small>';

	$prestaProduct->fetchDolibarrObject();
	if ($prestaProduct->doliObject) {
		$morehtmlref .= '<br>' . $langs->trans('ProductDolibarr') . ' : ';
		$morehtmlref .= $prestaProduct->getNomUrlDolibarr();
	} elseif ($prestaProduct->getLinkStatus() != $prestaProduct::STATUS_LINKED) {
		$doliProduct = new Product($db);
		if ($doliProduct->fetch(null, $prestaProduct->reference) > 0) {

			$morehtmlref .= '<br>' . $langs->trans('ProductDolibarr') . ' : ';
			$morehtmlref .= ' <span class="classfortooltip fa fa-exclamation-triangle" title="' . dol_escape_htmltag($langs->trans('ProductWithSameRefFound')) . '" ></span>' . ' ' . $doliProduct->getNomUrl();
			$url = $_SERVER["PHP_SELF"] . '?action=linkwithproduct&amp;token=' . newToken() . '&amp;id=' . $object->id . '&amp;presta_id=' . $prestaId . '&amp;doli_product_id=' . $doliProduct->id;

			// for js desabled compatibility set $url as call to confirm action and $params['confirm']['url'] to confirmed action
			$attr = [];
			$attr['data-confirm-url'] = $url;
			$attr['data-confirm-title'] = $langs->trans('ConfirmBtnCommonTitle', $langs->trans('CreateAPrestaDoliLink', $prestaProduct->reference, $doliProduct->ref));
			$attr['data-confirm-content'] = $langs->trans('ConfirmBtnCommonContent', $langs->trans('CreateAPrestaDoliLink', $prestaProduct->reference, $doliProduct->ref));
			$attr['data-confirm-content'] = preg_replace("/\r|\n/", "", $attr['data-confirm-content']);
			$attr['data-confirm-action-btn-label'] = $langs->trans('Confirm');
			$attr['data-confirm-cancel-btn-label'] = $langs->trans('CloseDialog');
			$attr['data-confirm-modal'] = true;

			$morehtmlref .= ' <span class="butActionConfirm classfortooltip small-link-btn" ' . prestaLib::genHtmlAttr($attr) . ' title="' . dol_escape_htmltag($langs->trans('CreateAPrestaDoliLink')) . '" href="' . $url . '" ><i class="fa fa-link"></i></span>';
		}
	}

	$morehtmlref .= '</div>';

	presta_resource_banner_tab($prestaProduct, $linkback, 1, 'id', 'reference', $morehtmlref);
}

/**
 *      lib extraite de la class form utilisée normalement sur du common object mais adapté pour des object presta webservice
 *      Je garde la signature dolibarr pour une question rapidité de dev
 *    TODO : adapter les manques
 *    Return a HTML area with the reference of object and a navigation bar for a business object
 *    Note: To complete search with a particular filter on select, you can set $object->next_prev_filter set to define SQL criterias.
 *
 * @param object $object         Object to show.
 * @param string $morehtml       More html content to output just before the nav bar.
 * @param int    $shownav        Show Condition (navigation is shown if value is 1).
 * @param string $fieldid        Name of field id into database to use for select next and previous (we make the select max and min on this field compared to $object->ref). Use 'none' to disable next/prev.
 * @param string $fieldref       Name of field ref of object (object->ref) to show or 'none' to not show ref.
 * @param string $morehtmlref    More html to show after ref.
 * @param string $moreparam      More param to add in nav link url. Must start with '&...'.
 * @param int    $nodbprefix     Do not include DB prefix to forge table name.
 * @param string $morehtmlleft   More html code to show before ref.
 * @param string $morehtmlstatus More html code to show under navigation arrows (status place).
 * @param string $morehtmlright  More html code to show after ref.
 *
 * @return    string                    Portion HTML with ref + navigation buttons
 */
function prestaShowRefNav($object, $morehtml = '', $shownav = 1, $fieldid = 'id', $fieldref = 'ref', $morehtmlref = '', $morehtmlleft = '', $morehtmlstatus = '', $morehtmlright = '')
{
	global $conf, $hookmanager;

	$ret = '';
	if (empty($fieldid)) $fieldid = 'id';
	if (empty($fieldref)) $fieldref = 'none';

	$previous_ref = $next_ref = '';

	//print "xx".$previous_ref."x".$next_ref;
	$ret .= '<!-- Start banner content --><div style="vertical-align: middle">';

	// Right part of banner
	if ($morehtmlright) $ret .= '<div class="inline-block floatleft">' . $morehtmlright . '</div>';

	if ($previous_ref || $next_ref || $morehtml) {
		$ret .= '<div class="pagination paginationref"><ul class="right">';
	}
	if ($morehtml) {
		$ret .= '<li class="noborder litext' . (($shownav && $previous_ref && $next_ref) ? ' clearbothonsmartphone' : '') . '">' . $morehtml . '</li>';
	}
	if ($shownav && ($previous_ref || $next_ref)) {
		$ret .= '<li class="pagination">' . $previous_ref . '</li>';
		$ret .= '<li class="pagination">' . $next_ref . '</li>';
	}
	if ($previous_ref || $next_ref || $morehtml) {
		$ret .= '</ul></div>';
	}

	$parameters = [];
	$reshook = $hookmanager->executeHooks('moreHtmlStatus', $parameters, $object); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $morehtmlstatus .= $hookmanager->resPrint;
	else $morehtmlstatus = $hookmanager->resPrint;
	if ($morehtmlstatus) $ret .= '<div class="statusref">' . $morehtmlstatus . '</div>';

	$parameters = [];
	$reshook = $hookmanager->executeHooks('moreHtmlRef', $parameters, $object); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $morehtmlref .= $hookmanager->resPrint;
	elseif ($reshook > 0) $morehtmlref = $hookmanager->resPrint;

	// Left part of banner
	if ($morehtmlleft) {
		if ($conf->browser->layout == 'phone') $ret .= '<!-- morehtmlleft --><div class="floatleft">' . $morehtmlleft . '</div>'; // class="center" to have photo in middle
		else $ret .= '<!-- morehtmlleft --><div class="inline-block floatleft">' . $morehtmlleft . '</div>';
	}

	//if ($conf->browser->layout == 'phone') $ret.='<div class="clearboth"></div>';
	$ret .= '<div class="inline-block floatleft valignmiddle maxwidth750 marginbottomonly refid' . (($shownav && ($previous_ref || $next_ref)) ? ' refidpadding' : '') . '">';

	if ($fieldref != 'none') {
		$ret .= dol_htmlentities($object->$fieldref);
	}

	if ($morehtmlref) {
		// don't add a additional space, when "$morehtmlref" starts with a HTML div tag
		if (substr($morehtmlref, 0, 4) != '<div') {
			$ret .= ' ';
		}

		$ret .= $morehtmlref;
	}

	$ret .= '</div>';

	$ret .= '</div><!-- End banner content -->';

	return $ret;
}

function prestaConfigBanner($prestaId, $active = '', $notab = 0)
{
	global $db, $langs;

	if (empty($prestaId)) {
		return;
	}

	$firstBannerNoTab = -1;

	dol_include_once('/prestasync/class/presta.class.php');
// Initialize technical objects
	$object = new Presta($db);
	$object->fetch($prestaId);

	$head = prestaPrepareHead($object);
	print dol_get_fiche_head($head, 'Parametters', $langs->trans("Presta"), $notab, $object->picto);

	prestaBanner($object);

	print dol_get_fiche_end($firstBannerNoTab);

	$head = prestaOptionsPrepareHead($object);
	print dol_get_fiche_head($head, $active, $langs->trans("Presta"), $notab, $object->picto);
}

function prestaBanner(Presta $object)
{
	global $langs;

	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="' . dol_buildpath('/prestasync/presta_list.php', 1) . '?restore_lastsearch_values=1' . (!empty($socid) ? '&socid=' . $socid : '') . '">' . $langs->trans("BackToList") . '</a>';

	$morehtmlref = '<div class="refidno">';
	$morehtmlref .= '<strong>' . $object->label . '</strong><br/>';
	$morehtmlref .= $object->shop_url;
	/*
	 // Ref customer
	 $morehtmlref.=$form->editfieldkey("RefCustomer", 'ref_client', $object->ref_client, $object, 0, 'string', '', 0, 1);
	 $morehtmlref.=$form->editfieldval("RefCustomer", 'ref_client', $object->ref_client, $object, 0, 'string', '', null, null, '', 1);
	 // Thirdparty
	 $morehtmlref.='<br>'.$langs->trans('ThirdParty') . ' : ' . (is_object($object->thirdparty) ? $object->thirdparty->getNomUrl(1) : '');
	 // Project
	 if (! empty($conf->project->enabled))
	 {
	 $langs->load("projects");
	 $morehtmlref.='<br>'.$langs->trans('Project') . ' ';
	 if ($permissiontoadd)
	 {
	 if ($action != 'classify')
	 //$morehtmlref.='<a class="editfielda" href="' . $_SERVER['PHP_SELF'] . '?action=classify&token='.newToken().'&id=' . $object->id . '">' . img_edit($langs->transnoentitiesnoconv('SetProject')) . '</a> : ';
	 $morehtmlref.=' : ';
	 if ($action == 'classify') {
	 //$morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'projectid', 0, 0, 1, 1);
	 $morehtmlref.='<form method="post" action="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'">';
	 $morehtmlref.='<input type="hidden" name="action" value="classin">';
	 $morehtmlref.='<input type="hidden" name="token" value="'.newToken().'">';
	 $morehtmlref.=$formproject->select_projects($object->socid, $object->fk_project, 'projectid', $maxlength, 0, 1, 0, 1, 0, 0, '', 1);
	 $morehtmlref.='<input type="submit" class="button valignmiddle" value="'.$langs->trans("Modify").'">';
	 $morehtmlref.='</form>';
	 } else {
	 $morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->socid, $object->fk_project, 'none', 0, 0, 0, 1);
	 }
	 } else {
	 if (! empty($object->fk_project)) {
	 $proj = new Project($db);
	 $proj->fetch($object->fk_project);
	 $morehtmlref .= ': '.$proj->getNomUrl();
	 } else {
	 $morehtmlref .= '';
	 }
	 }
	 }*/
	$morehtmlref .= '</div>';

	dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref);
}

/**
 * Prepare array of tabs for Presta
 *
 * @param Presta $object Presta
 * @param PrestaProduct $prestaProduct
 *
 * @return    array                    Array of tabs
 */
function prestaProductPrepareHead($object, $prestaProduct)
{
	global $db, $langs, $conf;

	$langs->load("prestasync@prestasync");


	$h = 0;
	$head = [];

	$head[$h][0] = dol_buildpath("/prestasync/presta_product.php", 1) . '?id=' . (int)$object->id.'&presta_id='.(int)$prestaProduct->id;
	$head[$h][1] = $langs->trans("Card");
	$head[$h][2] = 'card';
	$h++;

	$head[$h][0] = dol_buildpath("/prestasync/presta_product_desc.php", 1) . '?id=' . (int)$object->id.'&presta_id='.(int)$prestaProduct->id;
	$head[$h][1] = $langs->trans("Description");
	$head[$h][2] = 'desc';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@prestasync:/prestasync/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'prestaproduct@prestasync');

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'prestaproduct@prestasync', 'remove');

	return $head;
}

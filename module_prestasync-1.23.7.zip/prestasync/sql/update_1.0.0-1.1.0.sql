-- Copyright (C) 2018 John BOTELLA
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.


ALTER TABLE llx_prestasync_presta ADD fk_c_input_reason integer;
ALTER TABLE llx_prestasync_presta ADD fk_project integer;
ALTER TABLE llx_prestasync_presta ADD fk_cond_reglement_id integer;
ALTER TABLE llx_prestasync_presta ADD fk_mode_reglement_id integer;
ALTER TABLE llx_prestasync_presta ADD entity integer DEFAULT 1 NOT NULL;
TRUNCATE llx_prestasync_presta_query_cache;
ALTER TABLE llx_prestasync_presta_query_cache ADD resource varchar(65)  NOT NULL;
ALTER TABLE llx_prestasync_presta_query_cache DROP INDEX uk_prestasync_presta_cacheid;
ALTER TABLE llx_prestasync_presta_query_cache ADD UNIQUE INDEX uk_prestasync_presta_cacheid(fk_presta, resource, cacheid);

RENAME TABLE llx_prestasync_mappingcarrier TO llx_prestasync_carrier;
RENAME TABLE llx_prestasync_mappingcarrier_extrafields TO llx_prestasync_carrier_extrafields;
RENAME TABLE llx_prestasync_mappingpayment TO llx_prestasync_payment;
RENAME TABLE llx_prestasync_mappingpayment_extrafields TO llx_prestasync_payment_extrafields;


ALTER TABLE llx_prestasync_presta ADD order_status_on_sync integer;
ALTER TABLE llx_prestasync_presta ADD order_status_delivered varchar(255);
ALTER TABLE llx_prestasync_presta ADD order_status_to_sync varchar(255);

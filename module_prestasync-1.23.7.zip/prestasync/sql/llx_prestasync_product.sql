CREATE TABLE llx_prestasync_product(
  rowid integer AUTO_INCREMENT PRIMARY KEY NOT NULL,
  fk_presta integer NOT NULL,
  fk_product_doli integer NOT NULL,
  fk_product_presta integer NOT NULL,
  fk_product_presta_attribute integer NOT NULL default 0,
  date_creation datetime NOT NULL,
  tms timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=innodb;

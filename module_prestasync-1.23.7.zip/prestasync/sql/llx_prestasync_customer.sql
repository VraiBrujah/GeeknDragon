CREATE TABLE llx_prestasync_customer(
  rowid integer AUTO_INCREMENT PRIMARY KEY NOT NULL,
  fk_presta integer NOT NULL,
  fk_soc_doli integer NOT NULL,
  fk_customer_presta integer NOT NULL,
  date_creation datetime NOT NULL,
  tms timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=innodb;

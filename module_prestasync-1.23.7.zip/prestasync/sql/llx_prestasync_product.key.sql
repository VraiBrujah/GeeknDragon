
ALTER TABLE llx_prestasync_product ADD INDEX idx_prestasync_product_rowid (rowid);
ALTER TABLE llx_prestasync_product ADD UNIQUE INDEX uk_prestasync_product_fieldp(fk_presta, fk_product_doli, fk_product_presta, fk_product_presta_attribute );
ALTER TABLE llx_prestasync_product ADD CONSTRAINT uk_prestasync_product_fieldp FOREIGN KEY (fk_product_doli) REFERENCES llx_product(rowid) ON DELETE CASCADE;
ALTER TABLE llx_prestasync_product ADD CONSTRAINT uk_prestasync_presta_field FOREIGN KEY (fk_presta) REFERENCES llx_prestasync_presta(rowid) ON DELETE CASCADE;

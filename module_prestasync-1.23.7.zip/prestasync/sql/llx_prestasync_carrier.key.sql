-- Copyright (C) 2024 THERSANE www.thersane.fr
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


-- BEGIN MODULEBUILDER INDEXES
ALTER TABLE llx_prestasync_carrier ADD INDEX idx_prestasync_carrier_rowid (rowid);
ALTER TABLE llx_prestasync_carrier ADD CONSTRAINT llx_prestasync_carrier_fk_presta FOREIGN KEY (fk_presta) REFERENCES llx_prestasync_presta(rowid);
ALTER TABLE llx_prestasync_carrier ADD INDEX idx_prestasync_carrier_fk_shipment_mode (fk_shipment_mode);
ALTER TABLE llx_prestasync_carrier ADD CONSTRAINT llx_prestasync_carrier_fk_user_creat FOREIGN KEY (fk_user_creat) REFERENCES llx_user(rowid);
ALTER TABLE llx_prestasync_carrier ADD INDEX idx_prestasync_carrier_status (status);
-- END MODULEBUILDER INDEXES

ALTER TABLE llx_prestasync_carrier ADD UNIQUE INDEX uk_prestasync_carrier_prestaUniq(fk_presta, fk_carrier_presta);
ALTER TABLE llx_prestasync_carrier ADD CONSTRAINT llx_prestasync_carrier_dictionnary FOREIGN KEY (fk_shipment_mode) REFERENCES llx_c_shipment_mode(rowid) ON DELETE CASCADE;


-- Copyright (C) 2024 THERSANE www.thersane.fr
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


CREATE TABLE llx_prestasync_presta(
	-- BEGIN MODULEBUILDER FIELDS
	rowid integer AUTO_INCREMENT PRIMARY KEY NOT NULL, 
	ref varchar(128) DEFAULT '(PROV)' NOT NULL,
    entity integer DEFAULT 1 NOT NULL,
    shop_id integer,
    language integer DEFAULT 1,
    order_status_on_sync integer,
    order_status_delivered varchar(255),
    order_status_to_sync varchar(255),
	label varchar(255),
    fk_project integer,
    fk_cond_reglement_id integer,
    fk_mode_reglement_id integer,
    shop_url varchar(255),
	shop_admin_url varchar(255),
    shop_version varchar(5),
	api_key varchar(255),
	description text,
	note_public text, 
	note_private text, 
	date_creation datetime NOT NULL, 
	tms timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
	fk_user_creat integer NOT NULL, 
	fk_user_modif integer,
    fk_c_input_reason integer,
	last_main_doc varchar(255),
	import_key varchar(14), 
	model_pdf varchar(255), 
	status integer NOT NULL
	-- END MODULEBUILDER FIELDS
) ENGINE=innodb;

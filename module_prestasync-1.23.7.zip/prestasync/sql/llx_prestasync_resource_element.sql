-- This table is used to know

CREATE TABLE llx_prestasync_resource_element(
  rowid integer AUTO_INCREMENT PRIMARY KEY NOT NULL,
  fk_presta integer NOT NULL,
  presta_resource varchar(40),
  presta_resource_id int,

  dol_element varchar(60),
  dol_element_id int,

  date_creation datetime NOT NULL,
  tms timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=innodb;

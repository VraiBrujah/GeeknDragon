ALTER TABLE llx_prestasync_resource_element ADD INDEX idx_prestasync_resource_element_rowid (rowid);
ALTER TABLE llx_prestasync_resource_element ADD UNIQUE INDEX uk_prestasync_resource_field_presta(fk_presta, presta_resource, presta_resource_id);
ALTER TABLE llx_prestasync_resource_element ADD UNIQUE INDEX uk_prestasync_resource_field_dol(fk_presta, dol_element, dol_element_id);
ALTER TABLE llx_prestasync_resource_element ADD UNIQUE INDEX uk_prestasync_resource_field_dol_presta(fk_presta, dol_element, dol_element_id, presta_resource, presta_resource_id);
ALTER TABLE llx_prestasync_resource_element ADD CONSTRAINT uk_prestasync_resource_fieldp FOREIGN KEY (fk_presta) REFERENCES llx_prestasync_presta(rowid);

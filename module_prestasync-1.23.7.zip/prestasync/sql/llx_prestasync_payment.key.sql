-- Copyright (C) 2024 THERSANE www.thersane.fr
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


-- BEGIN MODULEBUILDER INDEXES
ALTER TABLE llx_prestasync_payment ADD INDEX idx_prestasync_payment_rowid (rowid);
ALTER TABLE llx_prestasync_payment ADD CONSTRAINT llx_prestasync_payment_fk_presta FOREIGN KEY (fk_presta) REFERENCES llx_prestasync_presta(rowid);
ALTER TABLE llx_prestasync_payment ADD INDEX idx_prestasync_payment_ref (ref);
ALTER TABLE llx_prestasync_payment ADD INDEX idx_prestasync_payment_fk_cond_reglement_id (fk_cond_reglement_id);
ALTER TABLE llx_prestasync_payment ADD INDEX idx_prestasync_payment_fk_mode_reglement_id (fk_mode_reglement_id);
ALTER TABLE llx_prestasync_payment ADD INDEX idx_prestasync_payment_flag_use_soc_cond (flag_use_soc_cond);
ALTER TABLE llx_prestasync_payment ADD INDEX idx_prestasync_payment_status (status);
ALTER TABLE llx_prestasync_payment ADD CONSTRAINT llx_prestasync_payment_fk_user_creat FOREIGN KEY (fk_user_creat) REFERENCES llx_user(rowid);
-- END MODULEBUILDER INDEXES


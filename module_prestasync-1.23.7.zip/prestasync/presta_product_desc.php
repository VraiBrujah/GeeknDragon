<?php
/* Copyright (C) 2024 John BOTELLA
 * Copyright (C) 2024 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *  \file       presta_note.php
 *  \ingroup    prestasync
 *  \brief      Tab for notes on Presta
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB', '1');				// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER', '1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC', '1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN', '1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION', '1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION', '1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK', '1');				// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
//if (! defined('NOTOKENRENEWAL'))           define('NOTOKENRENEWAL', '1');				// Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK', '1');				// Do not check style html tag into posted data
//if (! defined('NOREQUIREMENU'))            define('NOREQUIREMENU', '1');				// If there is no need to load and show top and left menu
//if (! defined('NOREQUIREHTML'))            define('NOREQUIREHTML', '1');				// If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX'))            define('NOREQUIREAJAX', '1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN", '1');					// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK', '1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT', 'auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule');	// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN', 1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP', 'none');				// Disable all Content Security Policies
//if (! defined('CSRFCHECK_WITH_TOKEN'))     define('CSRFCHECK_WITH_TOKEN', '1');		// Force use of CSRF protection with tokens even for GET
//if (! defined('NOBROWSERNOTIF'))     		 define('NOBROWSERNOTIF', '1');				// Disable browser notification

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once __DIR__ . '/class/presta.class.php';
require_once __DIR__ . '/class/prestaProduct.class.php';
require_once __DIR__ . '/class/prestaProductOptionValue.class.php';
require_once __DIR__ . '/lib/prestasync_presta.lib.php';
require_once __DIR__ . '/lib/prestasync.lib.php';
require_once __DIR__ . '/class/prestaTax.class.php';
require_once __DIR__ . '/class/prestaLib.class.php';
require_once __DIR__ . '/class/apiTranslatorTool.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/doleditor.class.php';
require_once __DIR__ . '/core/modules/modPrestasync.class.php';

// Load translation files required by the page
$langs->loadLangs(["prestasync@prestasync", "companies"]);

// Get parameters
$id = GETPOST('id', 'int');
$prestaId = GETPOST('presta_id', 'int');
$ref = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$cancel = GETPOST('cancel', 'aZ09');
$confirm = GETPOST('confirm', 'int');
$showmeattribute = GETPOST('showmeattribute', 'int');
$backtopage = GETPOST('backtopage', 'alpha');
$presta_combination_id = GETPOST('presta_combination_id', 'array:aZ09');
$thisDefaultUrl = dol_buildpath('prestasync/presta_product.php', 1) . '?id=' . $id . '&presta_id=' . $prestaId;

// Initialize technical objects
$object = new Presta($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->prestasync->dir_output . '/temp/massgeneration/' . $user->id;
$hookmanager->initHooks(['prestaproduct', 'globalcard']); // Note that conf->hooks_modules contains array
// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

// Load object
include DOL_DOCUMENT_ROOT . '/core/actions_fetchobject.inc.php'; // Must be include, not include_once  // Must be include, not include_once. Include fetch and fetch_thirdparty but not fetch_optionals
if ($id > 0 || !empty($ref)) {
	$upload_dir = $conf->prestasync->multidir_output[!empty($object->entity) ? $object->entity : $conf->entity] . "/" . $object->id;
}

if (empty($object->id)) {
	dol_print_error($db);
	exit();
}

// There is several ways to check permission.
// Set $enablepermissioncheck to 1 to enable a minimum low level of checks

$enablepermissioncheck = 1;
$permissiontoread = $user->hasRight('prestasync', 'presta', 'read');
$permissiontoadd = $user->hasRight('prestasync', 'presta', 'write');
$permissiontodelete = $user->hasRight('prestasync', 'presta', 'delete');

// Security check (enable the most restrictive one)
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
//$isdraft = (($object->status == $object::STATUS_DRAFT) ? 1 : 0);
//restrictedArea($user, $object->element, $object->id, $object->table_element, '', 'fk_soc', 'rowid', $isdraft);
if (empty($conf->prestasync->enabled)) accessforbidden();
if (!$permissiontoread) accessforbidden();

if ($object->id > 0) {
	$prestaProduct = new PrestaProduct($object);
	if (!$prestaProduct->fetch($prestaId)) {
		dol_print_error('', $prestaProduct->getLastError());
		exit;
	}

	$prestaProduct->fetchCombinations();
}

/*
 * Actions
 */
$confToJs = [
	'MAIN_MAX_DECIMALS_TOT' => getDolGlobalInt('MAIN_MAX_DECIMALS_TOT'),
	'MAIN_MAX_DECIMALS_UNIT' => getDolGlobalInt('MAIN_MAX_DECIMALS_UNIT'),
	'PRESTASYNC_AI_PRODUCT_GLOBAL_GENERATE_MODE' => getDolGlobalString('PRESTASYNC_AI_PRODUCT_GLOBAL_GENERATE_MODE', 'onceCall'),
	'interfaceUrl' => dol_buildpath('prestasync/interface.php', 1),
	'token' => newToken(),
//	'userRight'					=> array(
//		'read' => intval($permissionToView),
//		'write' => intval($permissionToAdd),
//	)
];

if(!in_array($confToJs['PRESTASYNC_AI_PRODUCT_GLOBAL_GENERATE_MODE'], ['onceCall', 'eachItemCall'])) {
	$confToJs['PRESTASYNC_AI_PRODUCT_GLOBAL_GENERATE_MODE'] = 'onceCall';
}

$jsLangs = [
	'Saved' => $langs->trans('Saved'),
	'errorAjaxCall' => $langs->trans('ErrorAjaxCall'),
	'CloseDialog' => $langs->trans('Close'),
	'errorAjaxCallDisconnected' => $langs->trans('Disconnected'),
];

// Display error message when conf is missing
$confsToCheck = [

];

$parameters = [
	'jsLangs' => &$jsLangs,
	'confToJs' => &$confToJs,
	'confsToCheck' => &$confsToCheck,
];
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) {
	setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
}
if (empty($reshook)) {

}

if (!empty($confsToCheck)) {
	foreach ($confsToCheck as $confToCheck) {
		if (!isset($conf->global->$confToCheck)) {
			setEventMessage($langs->trans('MissingSetupStepConfiguration') . ' : ' . $langs->trans($confToCheck), 'errors');
		}
	}
}

/*
 * View
 */

$form = new Form($db);

//$help_url='EN:Customers_Orders|FR:Commandes_Clients|ES:Pedidos de clientes';
$help_url = modPrestasync::webPageHelp;
$title = $langs->trans('Presta') . ' - ' . $prestaProduct->reference . ' ' . $prestaProduct->showOutputFieldQuick('name');

llxHeader('', $title, $help_url, '', 0, 0, [
	'prestasync/js/ps-live-webservice.js',
	'prestasync/js/product_desc.js',
	'prestasync/js/jsdiff.js',

	// Dol code editor
	'/includes/ace/src/ace.js',
	'/includes/ace/src/ext-statusbar.js',
	'/includes/ace/src/ext-language_tools.js',

], [
	'prestasync/css/prestasync.css',
	'prestasync/css/diff.css',
]);


if ($object->id > 0) {
	$object->fetch_thirdparty();

	/**
	 * Init Live edit
	 */
	print '<script nonce="' . getNonce() . '" >psLiveEdit.init(' . json_encode($confToJs) . ', ' . json_encode($jsLangs) . ');</script>';

	$head = prestaPrepareHead($object);

	print dol_get_fiche_head($head, 'products', $langs->trans("Presta"), -1, $object->picto);

	presta_product_ressourc_banner_generic($object, $prestaProduct);

	$head = prestaProductPrepareHead($object, $prestaProduct);
	$picto = ($prestaProduct->useCombinations() ? 'fa-cubes' : 'product');
	print dol_get_fiche_head($head, 'desc', $langs->trans("Presta"), 0, $picto);

	//  public 'meta_description' => string '' (length=0)
	//  public 'meta_keywords' => string '' (length=0)
	//  public 'meta_title' => string '' (length=0)
	//  public 'link_rewrite' => string 'carnet-de-notes-colibri' (length=23)
	//  public 'name' => string 'Carnet de notes Colibri' (length=23)
	//  public 'description' => string '<p>Le carnet de notes Renard est idéal pour consigner vos idées les plus ingénieuses. En voyage, au bureau ou à la maison, sa qualité de fabrication et son design attachant vous donneront l'envie d'écrire ! Papier 90g/m2, reliure double spirale.</p>' (length=255)
	//  public 'description_short' => string '<p>Carnet 120 pages avec couverture rigide en carton recyclé. 16x22cm</p>' (length=74)

	$isMultiLanguage = is_array($prestaProduct->name);

	$selectedLang = GETPOSTINT('presta_language', $object->language);
	$pListLangs = $object->getAllPrestaLanguages();
	$selectLang = [];
	$targetFlag = '';
	if ($pListLangs) {
		foreach ($pListLangs as $pLang) {
			$valuetoshow = \prestasync\ApiTranslatorTool::getFlag($pLang->locale,1).' ';
			$selectLang[$pLang->id] = $valuetoshow.$pLang->name;
			if(empty($selectedLang)) {
				$selectedLang = $pLang->id;
			}
		}
	}

	$noLangFound = empty($selectLang);
	if($noLangFound) {
		$selectLang[$object->language] = $langs->trans("NoData");
	}

	print '<div class="warning" >'.$langs->trans('WarningExperimentalFeatures').'</div>';
	print '<form id="select-language-desc-form" method="GET" action="' . $_SERVER["PHP_SELF"] . '">';
	print '<input type="hidden" name="token" value="' . newToken() . '">';
	print '<input type="hidden" name="presta_id" value="' . $prestaProduct->id . '">';
	print '<input type="hidden" name="id" value="' . $prestaProduct->presta->id . '">';
	print $form->selectarray('presta_language', $selectLang,$selectedLang);
	print '</form>';



//	$object->language

	print '<div id="languages-list" >';
	foreach ($selectLang as $langId => $langName){
		$deeplStatus = false;
		// (int)$selectedLang == (int)$langId
		print '<div class="prestasync-toggle-display '. ((int)$selectedLang == (int)$langId ? '--open' :'') .'" data-language="'. (int)$langId .'" >';

		print '	<form class="prestasync-seo-form" >';
		print '		<input type="hidden" name="language" value="'. (int)$langId .'" >';
		print '		<input type="hidden" name="language_name" value="'. dol_escape_htmltag($pListLangs[$langId]->name ?? '') .'" >';
		print '		<input type="hidden" name="token" value="' . newToken() . '">';
		print '		<input type="hidden" name="presta_id" value="' . $prestaProduct->id . '">';
		print '		<input type="hidden" name="id" value="' . $prestaProduct->presta->id . '">';

		$fields = [
			'name',
			'meta_title',
			'meta_description',
			'meta_keywords',
			'link_rewrite',
			'description_short',
			'description',
		];

		$picto = 'generic';
		$morehtmlcenter = '';
		$morehtmlrightbeforearrow = '';
		$morehtmlright = '';
		$morecss = '';

		/**
		 * Save to prestashop
		 */
		if($permissiontoadd){
			$morehtmlrightbeforearrow.= dolGetButtonTitle(
				$langs->trans('Save'),
				'',
				'fa fa-save',
				'#',
				'save-btn_'.(int)$langId,
				-3,
				[
					'forcenohideoftext' => 1,
					'attr' => [
						'data-presta-product-id' => (int)$prestaProduct->id,
						'data-presta-shop-id' => (int)$prestaProduct->presta->id,
						'class' => 'prestasync-save-desc-fields',
						'data-lang' => (int)$langId,
					]
				]
			);
		}


		/**
		 * TRANSLATE API
		 */
		$sourceFlag = '';
		$sourceLangName = '';
		if(!$noLangFound) {
			$deeplStatus = prestaSyncIsDeeplInstalled() ? 1 : -1; // -1 Functionality is disabled, 0 disable,  1 active , 2 Active and selected

			if(isset($pListLangs[$langId])){
				$picto = '';
				$targetLang = $pListLangs[$langId]->locale;
				$targetFlag = \prestasync\ApiTranslatorTool::getFlag($pListLangs[$langId]->locale,1).' ';
			}else{
				$deeplStatus = -1;
			}

			if(isset($pListLangs[$prestaProduct->presta->language])){
				$sourceLang = $pListLangs[$prestaProduct->presta->language]->locale;
				$sourceLangName = $pListLangs[$prestaProduct->presta->language]->name;
				$sourceFlag = \prestasync\ApiTranslatorTool::getFlag($pListLangs[$prestaProduct->presta->language]->locale,1).' ';
			}else{
				$deeplStatus = -1;
			}


			// disable if user has no right
			if(empty($permissiontoadd) && $deeplStatus > 0 ) {
				$deeplStatus = 0;
			}

			if((int)$langId !== (int)$prestaProduct->presta->language) {
				$morehtmlrightbeforearrow .= dolGetButtonTitle(
					$langs->trans('Translate'),
					'',
					'fa fa-language',
					'#',
					'',
					$deeplStatus, [
						'forcenohideoftext' => 1,
						'attr' => [
							'class' => 'prestasync-translate-all-fields',
							'data-language-id-dest' => (int)$langId,
						]
					]);
			}else{
				$deeplStatus = -1;
			}
		}

		/**
		 * ARTIFICIAL INTELLIGENCE
		 */

		$AIStatus = isModEnabled('ai') ? 1 : -1;
		// disable if user has no right
		if(empty($permissiontoadd) && $AIStatus > 0 ) {
			$AIStatus = 0;
		}
		$morehtmlrightbeforearrow.= dolGetButtonTitle($langs->trans('AI'), '', 'fa fa-magic', '#', '', $AIStatus, [
			'forcenohideoftext' => 1,
			'attr' => [
				'class' => 'prestasync-ai-all-fields',
				'data-language-id-dest' => (int)$langId,
				'data-presta-product-id' => (int)$prestaProduct->id,
				'data-presta-shop-id' => (int)$prestaProduct->presta->id,
			]
		]);


		/**
		 * TITLE
		 */
		$toggleCheckBox = '';
		if($permissiontoadd){
			$toggleCheckBox = '<input type="checkbox" class="prestasync-toggle" data-target=".update-field" data-lang="'.$langId.'" /> ';
		}
		print print_barre_liste($toggleCheckBox.$targetFlag.$langs->trans('PrestaProductsSeoLanguageX', $langName ), null, $_SERVER["PHP_SELF"], '', '', '', $morehtmlcenter, 0, '', $picto, 0, $morehtmlright, $morecss, -1, 0, 1, 0, $morehtmlrightbeforearrow);


		$editorMod = getDolGlobalString('PRESTASYNC_HTML_EDITOR', 'simple-wysiwyg');
		$editor = 1 ;
		if ($editorMod == 'ace') {
			$editor = 'ace';
		}
		elseif ($editorMod == 'simple-wysiwyg') {
			$editor = '1';
		}
		else {
			$editor = 'textarea';
		}

		foreach ($fields as $fieldKey) {
			$fieldParam = $prestaProduct->fields[$fieldKey];
			$htmlNameLang = $fieldKey.'_'.$langId;
			$pattern = isset($fieldParam['pattern']) ? ' pattern="'.dol_htmlentities($fieldParam['pattern']).'" ' : '';

			$value = $prestaProduct->$fieldKey;
			if (!empty($prestaProduct->fields[$fieldKey]['langs'])) {
				$value = $prestaProduct->getTradValue($value, $langId, false);
				if ($value === false) {
					// TODO : MANAGE ERROR
				}
			}


			print '	<div class="presta-input-box">';
			print '		<div class="presta-input-box__label">';
			print '			<label>';

			if($permissiontoadd) {
				print '			<input class="update-field" type="checkbox" name="update-field[]" data-lang="' . $langId . '"  value="' . $htmlNameLang . '" data-lang="' . $langId . '" />';
			}

			print				'<span id="label_' . $htmlNameLang . '" >'.$fieldParam['label'].'</span>';
			print '			</label>';
			print '			<div class="loading-bar --disabled" data-lang="' . $langId . '" data-field="'.$fieldKey.'" ></div>';
			print '			<div class="presta-input-box__options">';



			$titleBtn = $langs->trans('Compare');

			print ' 	<button class="generate-diff presta-input-box__button" '
				. ' title="' . dol_htmlentities($titleBtn) . '" '
				. ' data-field-key="' . $fieldKey . '" '
				. ' data-editor="' . $editor . '" '
				. ' data-language-code="' . strtoupper(\prestasync\ApiTranslatorTool::getLangCode($targetLang)) . '" '
				. ' data-language-id="' . $langId . '" '
				. ' ><span class="icon fa fa-code-branch"></span></button>';


			if ($deeplStatus > 0) {

				$titleBtn = $langs->trans('TranslateWithDeepl');
				$titleBtn.= "\r\n".$langs->trans('TranslateFromX', $sourceLangName);

				print ' 	<button class="generate-translation-btn presta-input-box__button" '
					.' title="'.dol_htmlentities($titleBtn).'" '
					.' data-language-code-src="'.strtoupper(\prestasync\ApiTranslatorTool::getLangCode($sourceLang)).'" '
					.' data-language-id-src="'.$prestaProduct->presta->language.'" '
					.' data-language-code-dest="'.strtoupper(\prestasync\ApiTranslatorTool::getLangCode($targetLang)).'" '
					.' data-language-id-dest="'.$langId.'" '
					.' data-trad-key="'.$fieldKey.'" '
					.' ><span class="icon fa fa-language"></span> ' . $sourceFlag . ' <span class="fa fa-arrow-right"></span> ' . $targetFlag.'</button>';
			}

			if ($AIStatus > 0) {
				$titleBtn = $langs->trans('GenerateByAIAssistant');
				print ' 	<button class="generate-ai-btn presta-input-box__button" '
					.' title="'.dol_htmlentities($titleBtn).'" '
					.' data-field-key="'.$fieldKey.'" '
					.' data-language-id-dest="'.$langId.'" '
					. 'data-presta-product-id="'.(int)$prestaProduct->id.'" '
					. 'data-presta-shop-id="'.(int)$prestaProduct->presta->id.'" '
					.' ><span class="icon fa fa-magic"></span> ' . $langs->trans('AI') . '</button>';
			}


			print '		</div>';
			print '	</div>';

			if (in_array($fieldKey, ['description_short', 'description'])) {

				// TODO : Add in config
				$htmlClassToNotTranslate = [
					'equivalent-en'
				];

				$html = addNotTranslateClass($value, $htmlClassToNotTranslate);



				if($editor === 'textarea') {
					print '<textarea wrap="soft" '.(!empty($permissiontoadd) ? '' : 'readonly' ).' class="prestashop-field" name="'.$htmlNameLang.'" data-field="'.$fieldKey.'" data-lang="'.$langId.'"  >'.dol_htmlentities($value).'</textarea>';
				}
				else{
					$doleditor = new DolEditor($htmlNameLang, $html, '', 0, 'Basic', 'In', true, false, $editor, 0, '99%', !empty($permissiontoadd) ? 0 : 1);
					print $doleditor->Create(1, '', false, '', 'html', 'data-field="'.$fieldKey.'" data-lang="'.$langId.'"', 'prestashop-field');
				}
			} else {

				$required = !in_array($fieldKey, ['meta_keywords']) ? 'required' : '';
				print '<input '.(!empty($permissiontoadd) ? '' : 'readonly' ).' class="prestashop-field" name="'.$htmlNameLang.'" data-field="'.$fieldKey.'" '.$required.' data-lang="'.$langId.'" placeholder="' . ($fieldParam['pattern'] ?? '') . '" ' . $pattern . ' type="text" value="' . dol_htmlentities($value) . '" >';
			}

			print '<input '.(!empty($permissiontoadd) ? '' : 'readonly' ).' class="backup-prestashop-field" name="'.$htmlNameLang.'_backup" data-field="'.$fieldKey.'" data-lang="'.$langId.'"   type="text" value="' . dol_htmlentities($value) . '" >';

			print '</div>';

		}

		print '	</form>';
		print '</div>';
	}
	print '</div>';

	print '
		<div id="diff-field-compare" class="backup-field-dialog" title="'.dol_htmlentities($langs->trans('Compare')).'" >
			<label class="badge badge-light"><input type="checkbox" class="nospace" checked /> '.dol_htmlentities($langs->trans('NoSpace')).'</label>

  			<div class="diff-dialog-row">
   				 <div class="diff-dialog-col">
      				<h2 class="diff-title">'.$langs->trans('Original').'</h2>
  					<div id="diff-field-origin" class="diff-old-document"></div>
  				 </div>
   				 <div class="diff-dialog-col">
      				<h2 class="diff-title">'.$langs->trans('New').'</h2>
  					<div id="diff-field-new"  class="diff-new-document"></div>
  				 </div>
  			</div>
  		</div>';

	print dol_get_fiche_end();
}

// End of page
llxFooter();
$db->close();


window.addEventListener('psLiveEditInit', function (e){
	// when live edit is ready init all events
	let o = e.detail.psLiveEdit;

	$(function() {
		$( ".order-detail-customisation-lazzy-load-wrapper" ).each(function( index ) {

			if($(this).attr('data-customization') === undefined){
				return false;
			}

			if($(this).attr('data-presta') === undefined){
				return false;
			}

			let data = {
				'id': $(this).attr('data-customization'),
				'fk_presta': $(this).attr('data-presta'),
			}

			$(this).addClass('--wrapper-loading-effect');

			return o.callInterface(o.config.interfaceUrl,'getOrderDetailCustomisation', data, (response)=>{
					if(response.result > 0){
						$(this).removeClass('--wrapper-loading-effect');
						if(typeof response.data !== undefined && typeof response.data.html !== undefined){
							$(this).append(response.data.html);
						}
					}
				},
				()=>{
					$(this).removeClass('--wrapper-loading-effect');
				});
		});
	});
});

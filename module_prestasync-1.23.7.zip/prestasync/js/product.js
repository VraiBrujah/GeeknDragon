$(function() {
	$('input[type="checkbox"][data-toggle-check-target]').on('click', function () {
		let targets = $(this).attr('data-toggle-check-target');
		if ($(targets).length > 0) {
			$(targets).prop("checked", this.checked);
			$(targets).trigger("change");
		}
	})

	$(document).on('change', '.toggle-checkbox-for-combination', function () {
		$("#mass-action-block").slideDown();
	});


	$(document).on('blur','.live-edit', function(){
		return SpLiveEdit.sendLiveEditFromElement($(this));
	});

	$(document).on('keydown', '.ps-live-edit-input, .ps-list-input', function(e) {
		if(e.key === 'Enter'){
			e.preventDefault();
			$(this).trigger('change');
		}
	});

	//  class="linked-to-weight-impact" data-weight="'.$prestaProduct->weight.'" data-webservice-resource-id="'.$combination->id.'"
	$(document).on('change', '.linked-to-weight-impact', function () {
		let combinationId = $(this).attr('data-webservice-resource-id');
		let newWeightImpact = parseFloat($(this).val()) - parseFloat($(this).attr('data-weight'));
		newWeightImpact = Math.round((newWeightImpact + Number.EPSILON) * 100) / 100;
		newWeightImpact = newWeightImpact.toFixed(2);
		let targetInput = $('.ps-live-edit-input[data-webservice-resource-id="' + combinationId + '"][data-col="weight"]');
		targetInput.val(newWeightImpact).trigger('change');
	});

	$(document).on('change', '.linked-to-price-impact', function () {
		let combinationId = $(this).attr('data-webservice-resource-id');
		let newPriceImpact = parseFloat($(this).val()) - parseFloat($(this).attr('data-price'));
		newPriceImpact = Math.round((newPriceImpact + Number.EPSILON) * 100) / 100;
		newPriceImpact = newPriceImpact.toFixed(2);
		let targetInput = $('.ps-live-edit-input[data-webservice-resource-id="' + combinationId + '"][data-col="price"]');
		targetInput.val(newPriceImpact).trigger('change');
	});

	let toggleOverAll  = $("#toggle-check-all-mass-action");

	if(toggleOverAll.length > 0){
		let toggleTargets = $("#update-combination-confirmform .toggle-check[type=checkbox]");
		$(document).on('change', '#toggle-check-all-mass-action', function () {
			toggleTargets.prop('checked', $(this).is(':checked'));
		});

		$(document).on('change', '#update-combination-confirmform .toggle-check', function () {
			let checkedCount = 0;
			toggleTargets.each(function() {
				if( $(this).is(':checked') ) {
					checkedCount++;
				}
			});

			if (checkedCount === 0) {
				toggleOverAll.prop('checked', false);
				toggleOverAll.prop('indeterminate', false);
			} else if (checkedCount === toggleTargets.length) {
				toggleOverAll.prop('checked', true);
				toggleOverAll.prop('indeterminate', false);
			} else {
				toggleOverAll.prop('checked', false);
				toggleOverAll.prop('indeterminate', true);
			}
		});
	}
});


window.addEventListener('psLiveEditInit', function (e){
	// when live edit is ready init all events
	let o = e.detail.psLiveEdit;

	$(document).on('change', '.ps-live-edit-input', function () {
		sendLiveEditFromElement($(this));
	});

	/**
	 * send live edit from Jquery element
	 * @param {jQuery} formEl
	 */
	let sendLiveEditFromElement = function (formEl){

		if(formEl.attr('data-webservice-resource') === undefined){
			return false;
		}

		if(formEl.attr('data-webservice-resource-id') === undefined){
			return false;
		}

		// pour eviter d'envoyer plusieurs fois le sdonnées
		if(formEl.attr('data-last-send-value') !== undefined && formEl.attr('data-last-send-value') === formEl.val()){
			return null;
		}

		let data = {
			'id': formEl.attr('data-webservice-resource-id'),
			'fk_presta': formEl.attr('data-presta'),
			'resource': formEl.attr('data-webservice-resource'),
			'fields' : {
				[formEl.attr('data-col')]: formEl.val(),
			}
		}


		formEl.addClass('--input-loading-effect');

		return o.callInterface(o.config.interfaceUrl,'updateCombination', data, (response)=>{
			if(response.result > 0){
				formEl.removeClass('--input-loading-effect');

				formEl.addClass('--success-update');
				setTimeout(() => {
					formEl.removeClass('--success-update');
				}, 1000);

				formEl.attr('data-last-send-value', formEl.val());
			}
		},
		()=>{
			formEl.removeClass('--input-loading-effect');
		});
	}
});

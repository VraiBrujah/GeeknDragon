window.addEventListener('psLiveEditInit', function (e) {

	/**
	 * add an option to a form select jquery object
	 *
	 * @param {jQuery} jqueryObj
	 * @param string value
	 * @param string name
	 */
	let addOption = function (jqueryObj, value, name){
		let opt = document.createElement("option");
		opt.value = value // the index
		opt.innerText = name;
		jqueryObj.append(opt);
	}

	let getFieldsFromPresta = function () {

		let shopUrlEl = $('#shop_url');
		let api_keyEl = $('#api_key');

		if (shopUrlEl.length === 0 || api_keyEl.length === 0 || api_keyEl.val() === '' || shopUrlEl.val() === '') {
			return;
		}

		let shopUrl = shopUrlEl.val();
		let api_key = api_keyEl.val();

		let data = {
			shopUrl: shopUrl,
			api_key: api_key
		};

		let idShopEl = $('#shop_id');
		if (parseInt(idShopEl.val()) > 0) {
			data.id_shop = idShopEl.val();
		}

		o.callInterface(o.config.interfaceUrl, 'getLangs', data, (response) => {
			if (response.result > 0) {
				if (Array.isArray(response.data.langs)) {
					$('#language').find('option').remove();

					response.data.langs.map((lang) => {
						addOption($('#language'), lang.id, lang.name);
					});
					$('#language').trigger('change');
					setVersion(response.data.version);
				}
			}
		});

		o.callInterface(o.config.interfaceUrl, 'getShops', data, (response) => {
			if (response.result > 0) {
				if (Array.isArray(response.data.shops)) {
					idShopEl.find('option').remove();


					response.data.shops.map((shop) => {
						addOption(idShopEl, shop.id, shop.name);
					});
					idShopEl.trigger('change');
					setVersion(response.data.version);
				}
			}
		});
	}

	/**
	 * auto set status in select options according to form data
	 */
	let getStatusFromPresta = function () {

		let shopUrlEl = $('#shop_url');
		let api_keyEl = $('#api_key');

		if (shopUrlEl.length === 0 || api_keyEl.length === 0 || api_keyEl.val() === '' || shopUrlEl.val() === '') {
			return;
		}

		let shopUrl = shopUrlEl.val();
		let api_key = api_keyEl.val();

		let data = {
			shopUrl: shopUrl,
			api_key: api_key
		};

		let idShopEl = $('#shop_id');
		if (parseInt(idShopEl.val()) > 0) {
			data.id_shop = idShopEl.val();
		}

		o.callInterface(o.config.interfaceUrl, 'getStatus', data, (response) => {
			if (response.result > 0) {
				if (Array.isArray(response.data.status)) {

					let order_status_to_sync = $('#order_status_to_sync');
					let order_status_on_sync = $('#order_status_on_sync');
					let order_status_delivered = $('#order_status_delivered');

					// backup selected val
					let backup_order_status_on_sync = order_status_on_sync.val();
					let backup_order_status_to_sync = order_status_to_sync.val();
					let backup_order_status_delivered = order_status_delivered.val();

					order_status_to_sync.find('option').remove();
					order_status_on_sync.find('option').remove();
					order_status_delivered.find('option').remove();

					addOption(order_status_on_sync, 0, '&nbsp;');

					response.data.status.map((status) => {
						addOption(order_status_to_sync, status.id, status.name);
						addOption(order_status_on_sync, status.id, status.name);
						addOption(order_status_delivered, status.id, status.name);
					});

					order_status_to_sync.val(backup_order_status_to_sync);
					order_status_on_sync.val(backup_order_status_on_sync);
					order_status_delivered.val(backup_order_status_delivered);

					order_status_to_sync.trigger('change');
					order_status_on_sync.trigger('change');
					order_status_delivered.trigger('change');
				}
			}
		});
	}

	let setVersion = function(version){
		version = parseFloat(version);
		let versionToSet = version;
		if(version < 1.7){
			versionToSet = 1.6;
		} else if(version < 1.8){
			versionToSet = 1.7;
		} else if(version < 9){
			versionToSet = 8;
		} else if(version < 10){
			versionToSet = 9;
		}else{
			versionToSet = parseInt(version);
		}

		$('#shop_version').val(versionToSet).change();
	}


	/**
	 * STEP 2 : PROCESS
	 */

	// when live edit is ready init all events
	let o = e.detail.psLiveEdit;

	// On page load exec some tests
	$(function() {
		if ($('#prestasync-wizard').length === 0 && $('#shop_url').length > 0 && $('#api_key').length > 0) { // Check we are not in wizard mode
			getFieldsFromPresta();
		}
	});

	$(document).on('change', '#api_key, #shop_url', function () {
		if($('#language').length > 0 && $('#shop_id').length > 0){ // Check we are not in wizard mode
			getFieldsFromPresta();
		}
	});

	$(document).on('change', '#shop_id', function () {
		if($('#language').length > 0 && $('#shop_id').length > 0){ // Check we are not in wizard mode
			getStatusFromPresta();
		}
	});

	$(document).on('click', '#create-wizard', function (e) {
		e.preventDefault();

		let shopUrl = $('#shop_url').val();
		let api_key = $('#api_key').val();

		let data = {
			shopUrl: shopUrl,
			api_key: api_key
		};


		$('#prestasync-loader').addClass('prestasync-loader');

		o.callInterface(o.config.interfaceUrl, 'getShops', data,
			(response) => {
				if (response.result > 0) {
					if(typeof response.data !== undefined && typeof response.data.shops !== undefined && Array.isArray(response.data.shops) && typeof response.data.shops[0] !== undefined){
						$('#label').val(response.data.shops[0].name);
					}

					$('#prestasync-wizard-form').trigger( "submit" );
				}
			},(err) => {

			},() => {
				$('#prestasync-loader').removeClass('prestasync-loader');
			}
		);

	});
});




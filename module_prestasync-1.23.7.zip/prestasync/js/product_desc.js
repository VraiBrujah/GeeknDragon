let prestasyncChangeNotSaved = false;


let getField = function(field, langId) {

	// Check Ace editor
	let aceInstance = getAceInstance(field, langId);
	if(aceInstance){
		return $('#' + field + '_' + langId);
	}

	return $('.prestashop-field[data-field="'+field+'"][data-lang="'+langId+'"]');
}

let getBackupField = function(field, langId) {
	return $('.backup-prestashop-field[data-field="'+field+'"][data-lang="'+langId+'"]');
}


let setLoadingBarrForField = function(field, langId, status = false) {
	let loadingBarr = $('.loading-bar[data-field="'+field+'"][data-lang="'+langId+'"]');
	if(status) {
		loadingBarr.removeClass('--disabled');
	}else{
		loadingBarr.addClass('--disabled');
	}
}

let getValueOfField = function(field, langId){
	let CKEDITORSelector = field + '_' + langId;
	if (typeof CKEDITOR !== undefined && CKEDITOR.instances[CKEDITORSelector] && CKEDITOR.instances[CKEDITORSelector].status === 'ready') {
		return CKEDITOR.instances[CKEDITORSelector].getData();
	}

	let aceInstance = getAceInstance(field, langId);
	if(aceInstance){
		return aceInstance.getValue();
	}

	let target = getField(field, langId);
	return target.val();
}

let getAceInstance = function (field, langId) {
	let fieldName = field + '_' + langId;
	let aceEditorId = fieldName + 'aceeditorid';
	if($('#' + aceEditorId).length === 0)
	{
		return false;
	}

	return ace.edit(aceEditorId);
}

let setValueOfField = function(field, langId, content, triggerChange = true){
	let CKEDITORSelector = field+'_'+langId;
	if (typeof CKEDITOR !== undefined && CKEDITOR.instances[CKEDITORSelector] && CKEDITOR.instances[CKEDITORSelector].status === 'ready') {
		CKEDITOR.instances[CKEDITORSelector].setData(content);
	}

	// Check Ace editor
	let aceInstance = getAceInstance(field, langId);
	if(aceInstance){
		aceInstance.setValue(content);
	}

	let target = getField(field, langId);
	target.val(content);
	if(triggerChange){
		target.trigger('change');
	}
}

let inputTypingEffect = function(JTarget, triggerChange = false){
	JTarget.each(function(){
		let currentInput= $(this);
		let text = $(this).val();
		let typerText = "";
		let contentLength = text.length;
		let count = 0;
		let typingSpeed = 300 / contentLength;

		let typer = setInterval(function() {
			if (count > text.length) {
				if(triggerChange){
					currentInput.trigger('change');
				}
				clearInterval(typer);
			}
			typerText += text.charAt(count);
			currentInput.val(typerText);
			count++;
		}, typingSpeed);
	});
}

let toggleSaveBtn = function (langId) {
	let saveBtn = $('.prestasync-save-desc-fields[data-lang="'+langId+'"]');
	if(atLeastOneInputFieldChecked(langId)) {
		saveBtn.removeClass('refused');
	}
	else{
		saveBtn.addClass('refused');
	}
};

let atLeastOneInputFieldChecked = function(langId) {
	let atLeastOneSelected = false;
	$( '.update-field[data-lang="'+langId+'"]').each(function() {
		if(this.checked) {
			atLeastOneSelected = true;
		}
	});

	return atLeastOneSelected;
};

$(function() {

	/**
	 * Change language to display
	 */
	$(document).on("change", "#presta_language", function() {
		$("#languages-list .prestasync-toggle-display[data-language]").removeClass("--open");
		$("#languages-list .prestasync-toggle-display[data-language=\'" + $(this).val() + "\']").addClass("--open");
	});

	/**
	 * Toggle checkbox
	 */
	$(document).on("click", '.prestasync-toggle', function () {
		let target = $(this).attr('data-target');
		let lang = $(this).attr('data-lang');
		let checkBoxes = $(target + '[data-lang="' + lang + '"]');
		checkBoxes.prop("checked", this.checked);
		checkBoxes.trigger('change');
	});

	/**
	 * Toggle save BTN
	 */
	$(document).on("change", '.update-field', function () {
		let languageSection = $(this).closest('.prestasync-toggle-display');
		if (languageSection) {
			toggleSaveBtn(languageSection.attr('data-language'));
		}
	});

	/**
	 * Field link_rewrite
	 */
	$(document).on("keydown keyup change", '.prestashop-field[data-field="link_rewrite"]', function () {
		let newString = $(this).val();
		newString = newString.replace(/[^a-zA-Z0-9\-_]/g, "-");
		newString = newString.replace(/-{2,}/g, "-");
		$(this).val(newString);
	});

	/**
	 * On field change check ready to update
	 * change also : on leave not save alert
	 */
	$(document).on("change keyup", '.prestashop-field', function () {
		prestasyncChangeNotSaved = true;
		let box = $(this).closest('.presta-input-box');
		if (box) {
			box.find('.update-field').prop("checked", true).trigger('change');
		}
	})
});


/**
 * Alert user on page leave if data not saved
 */
$(window).on('beforeunload', function(e){
 	if(prestasyncChangeNotSaved){
 		let confirmationMessage = 'The changes you have made may not be saved.'
		e.returnValue = confirmationMessage; // Gecko, Trident, Chrome 34+
		return confirmationMessage; // Gecko, WebKit, Chrome <34
	}
});



window.addEventListener('psLiveEditInit', function (e){
	// when live edit is ready init all events
	let o = e.detail.psLiveEdit;


	/**
	 * DEEPL
	 */
	$(document).on("click", '.prestasync-translate-all-fields', function (event) {
		event.preventDefault();

		if($(this).hasClass('refused')){
			return;
		}

		let targetLangId = $(this).attr('data-language-id-dest');
		$('.generate-translation-btn[data-language-id-dest='+parseInt(targetLangId)+']').trigger('click');
	});

	$(document).on("click", '.generate-translation-btn', function (event) {
		event.preventDefault();

		let field = $(this).attr('data-trad-key');
		let targetLangId = $(this).attr('data-language-id-dest');
		let targetField = getField(field, targetLangId) ;
		let sourceLangId = $(this).attr('data-language-id-src');

		let data = {
			langSrc  : $(this).attr('data-language-code-src'),
			langDest : $(this).attr('data-language-code-dest'),
			langKey  : $(this).attr('data-trad-key'),
			tag_handling : 'html',
			sourceTxt : [
				getValueOfField(field, sourceLangId)
			]
		}

		// to do ajouter le context
		//context :: ajouter le test description courte et longue

		targetField.addClass('--input-loading-effect');
		if(targetField.is( "textarea" )) {
			setLoadingBarrForField(field, targetLangId, true);
		}

		o.callInterface(o.config.interfaceUrl,'getTrad', data, (response)=>{
			if(response.result > 0){
				let newTrad = response.data.translations[0].text;
				if(newTrad.length > 0) {
					setValueOfField(field, targetLangId, newTrad, targetField.is( "textarea" ));
					if(!targetField.is( "textarea" )) {
						inputTypingEffect(targetField, true);
					}
				}
			}

			targetField.removeClass('--input-loading-effect');
			if(targetField.is( "textarea" )) {
				setLoadingBarrForField(field, targetLangId, false);
			}
		},(error)=>{
			console.error(error);
			targetField.removeClass('--input-loading-effect');
			if(targetField.is( "textarea" )) {
				setLoadingBarrForField(field, targetLangId, false);
			}
		});

	});


	/**
	 * Diff
	 */

	$( function() {
		let dialogDiff = $('#diff-field-compare');
		dialogDiff.dialog({
			autoOpen: false,
			width: "90%",
			modal: true
		});

		$(document).on("click", '.generate-diff', function (event) {
			event.preventDefault();

			let field = $(this).attr('data-field-key');
			let lang = $(this).attr('data-language-id');
			let editor = $(this).attr('data-editor');

			let originalHTML = getBackupField(field, lang).val();
			let newHTML = getValueOfField(field, lang);


			let original = originalHTML;
			let newInput = newHTML;


			let targetField = getField(field, lang) ;
			if(editor === 'textarea' || !targetField.is( "textarea" )) {
				originalHTML = htmlentities (originalHTML, 'ENT_QUOTES' , null, null, 'HTML_CHARS' ) ;
				newHTML = htmlentities (newHTML, 'ENT_QUOTES' , null, null, 'HTML_CHARS' ) ;

				// Diff HTML strings
				newInput = htmldiff(originalHTML, newHTML);
				original = htmldiff(newHTML, originalHTML);
			}

			// Show HTML diff output as HTML!
			document.getElementById("diff-field-origin").innerHTML = original; // + '<hr/>' + originalHTML;
			// document.getElementById("outputOriginal").innerHTML = originalHTML;
			document.getElementById("diff-field-new").innerHTML = newInput;

			dialogDiff.dialog('option', 'title', $('#label_'+ field +'_'+lang).text());
			dialogDiff.dialog('open');
		});
	});





	/**
	 * AI Assistant
	 */
	$(document).on("click", '.prestasync-ai-all-fields', function (event) {
		event.preventDefault();

		if($(this).hasClass('refused')){
			return;
		}

		let targetLangId = $(this).attr('data-language-id-dest');
		let targetLang = $('.prestasync-toggle-display[data-language="'+targetLangId+'"]').find('input[name="language_name"]').val();
		let interactivePromptMode = parseInt($(this).attr('data-interactive-prompt-mode')) > 0;

		/**
		 * Traitement API en mode UN APPEL PAR CHAMP
		 * En cliquant sur chaque bouton ...
		 */
		if(o.config.PRESTASYNC_AI_PRODUCT_GLOBAL_GENERATE_MODE === 'eachItemCall'){
			$('.generate-ai-btn[data-language-id-dest='+parseInt(targetLangId)+']').trigger('click');
			return;
		}

		/**
		 * Traitement API en mode UN SEUL APPEL
		 * @type {{fk_presta: *, field: string, language: (*|jQuery|string|number|string[]), id: *, langId: (*|jQuery|string), fieldsVal: {meta_description: (*|string|number|string[]), description_short: (*|string|number|string[]), meta_title: (*|string|number|string[]), name: (*|string|number|string[]), description: (*|string|number|string[]), meta_keywords: (*|string|number|string[]), link_rewrite: (*|string|number|string[])}}}
		 */
		let data = {
			langId : targetLangId,
			fk_presta : $(this).attr('data-presta-shop-id'),
			id : $(this).attr('data-presta-product-id'),
			language : targetLang,
			field : 'all',
			fieldsVal : {
				name : getValueOfField('name', targetLangId),
				meta_title : getValueOfField('meta_title', targetLangId),
				meta_description : getValueOfField('meta_description', targetLangId),
				meta_keywords : getValueOfField('meta_keywords', targetLangId),
				description_short : getValueOfField('description_short', targetLangId),
				description : getValueOfField('description', targetLangId),
				link_rewrite : getValueOfField('link_rewrite', targetLangId),
			}
		}

		let fields = ['name', 'meta_title', 'meta_description', 'meta_keywords', 'link_rewrite', 'description_short','description'];

		// Create a quick reusable function to activate /disable processing effect
		let toggleLoading = function (status = false) {
			fields.forEach((field) => {
				let targetField = getField(field, targetLangId) ;

				if(status) {
					targetField.addClass('--input-loading-effect');
				}else{
					targetField.removeClass('--input-loading-effect');
				}

				if(targetField.is( "textarea" )) {
					setLoadingBarrForField(field, targetLangId, status);
				}
			});
		}

		// Activate input processing effect
		toggleLoading(true);

		o.callInterface(o.config.interfaceUrl,'getPromptForField', data, (response)=>{
			if(response.result > 0){
				let prompt = response.data.prompt;
				if(prompt.length > 0) {

					if(interactivePromptMode) {
						// Mode interactif affiche in popup avec le prompt avant d'envoyer les info
						toggleLoading(false);
					} else{
						// Mode automatique applique directement le prompt

						o.callInterface(o.config.interfaceUrl,'getAiResponse', {
							prompt: prompt,
							field  : 'all'
						}, (response)=>{
							console.log(response.result);

							if(response.result > 0 && typeof response.data !== undefined && typeof response.data.AnswerFromAI !== undefined){

								// si tout est ok normalement l'IA à répondu un JSON avec ce format
								// $jsonEx->Keywords = '';
								// $jsonEx->ShortDescription = '';
								// $jsonEx->FullDescription = '';
								// $jsonEx->URLRewrite = '';

								// 				meta_keywords : getValueOfField('meta_keywords', targetLangId),
								// 				 : getValueOfField('description_short', targetLangId),
								// 				description : getValueOfField('description', targetLangId),
								// 				link_rewrite : getValueOfField('link_rewrite', targetLangId),

								let setField = function (field, value) {
									let targetField = getField(field, targetLangId);
									setValueOfField(field, targetLangId, value, targetField.is( "textarea" ));
									if(!targetField.is( "textarea" )) {
										inputTypingEffect(targetField, true);
									}
								}


								let jsonString = response.data.AnswerFromAI;
								jsonString = jsonString.replace(/(\r\n|\n|\r)/gm, "");
								let matches = jsonString.match(/({.*})/g);

								try {
									let obj = JSON.parse(matches[0]);

									if(typeof obj === "object" ){

										if(typeof obj.ProductName === undefined ){
											console.error('Missing ProductName value returned by AI ');
										}else{
											setField('name', obj.ProductName);
										}

										if(typeof obj.MetaTitle === undefined ){
											console.error('Missing MetaTitle value returned by AI ');
										}else{
											setField('meta_title', obj.MetaTitle);
										}

										if(typeof obj.MetaDescription === undefined ){
											console.error('Missing MetaDescription value returned by AI ');
										}else{
											setField('meta_description', obj.MetaDescription);
										}

										if(typeof obj.Keywords === undefined ){
											console.error('Missing Keywords value returned by AI ');
										}else{
											setField('meta_keywords', obj.Keywords);
										}

										if(typeof obj.ShortDescription === undefined ){
											console.error('Missing ShortDescription value returned by AI ');
										}else{
											setField('description_short', obj.ShortDescription);
										}

										if(typeof obj.FullDescription === undefined ){
											console.error('Missing ShortDescription value returned by AI ');
										}else{
											setField('description', obj.FullDescription);
										}

										if(typeof obj.URLRewrite === undefined ){
											console.error('Missing URLRewrite value returned by AI ');
										}else{
											setField('link_rewrite', obj.URLRewrite);
										}

									}
									else{
										console.error('Invalid data returned by AI');
										console.error(obj);
										o.setEventMessage('Invalid data returned by AI', false)
									}

								} catch (error) {
									console.error(error);
									o.setEventMessage('Invalid data returned by AI', false)
								}
							}

							toggleLoading(false);
						},(error)=>{
							console.error(error);
							toggleLoading(false);
						});
					}
				}else{
					toggleLoading(true);
				}
			}
		},(error)=>{
			console.error(error);
			toggleLoading(true);
		});

	});

	$(document).on("click", '.generate-ai-btn', function (event) {
		event.preventDefault();

		let field = $(this).attr('data-field-key');
		let targetLangId = $(this).attr('data-language-id-dest');
		let targetLang = $('.prestasync-toggle-display[data-language="'+targetLangId+'"]').find('input[name="language_name"]').val();
		let interactivePromptMode = parseInt($(this).attr('data-interactive-prompt-mode')) > 0;

		let targetField = getField(field, targetLangId) ;

		let data = {
			langId : targetLangId,
			fk_presta : $(this).attr('data-presta-shop-id'),
			id : $(this).attr('data-presta-product-id'),
			language : targetLang,
			field : field,
			fieldsVal : {
				name : getValueOfField('name', targetLangId),
				meta_title : getValueOfField('meta_title', targetLangId),
				meta_description : getValueOfField('meta_description', targetLangId),
				meta_keywords : getValueOfField('meta_keywords', targetLangId),
				description_short : getValueOfField('description_short', targetLangId),
				description : getValueOfField('description', targetLangId),
				link_rewrite : getValueOfField('link_rewrite', targetLangId),
			}
		}

		// to do ajouter le context
		//context :: ajouter le test description courte et longue

		targetField.addClass('--input-loading-effect');
		if(targetField.is( "textarea" )) {
			setLoadingBarrForField(field, targetLangId, true);
		}

		o.callInterface(o.config.interfaceUrl,'getPromptForField', data, (response)=>{
			if(response.result > 0){
				let prompt = response.data.prompt;
				if(prompt.length > 0) {

					if(interactivePromptMode) {
						// Mode interactif affiche in popup avec le prompt avant d'envoyer les info
						targetField.removeClass('--input-loading-effect');
						if(targetField.is( "textarea" )) {
							setLoadingBarrForField(field, targetLangId, false);
						}
					} else{
						// Mode automatique applique directement le prompt

						o.callInterface(o.config.interfaceUrl,'getAiResponse', {
							prompt: prompt,
							field  : field
						}, (response)=>{

							if(response.result > 0 && typeof response.data !== undefined && typeof response.data.AnswerFromAI !== undefined){
								setValueOfField(field, targetLangId, response.data.AnswerFromAI, targetField.is( "textarea" ));
								if(!targetField.is( "textarea" )) {
									inputTypingEffect(targetField, true);
								}
							}

							targetField.removeClass('--input-loading-effect');
							if(targetField.is( "textarea" )) {
								setLoadingBarrForField(field, targetLangId, false);
							}
						},(error)=>{
							console.error(error);
							targetField.removeClass('--input-loading-effect');
							if(targetField.is( "textarea" )) {
								setLoadingBarrForField(field, targetLangId, false);
							}
						});
					}
				}else{
					targetField.removeClass('--input-loading-effect');
					if(targetField.is( "textarea" )) {
						setLoadingBarrForField(field, targetLangId, false);
					}
				}
			}
		},(error)=>{
			console.error(error);
			targetField.removeClass('--input-loading-effect');
			if(targetField.is( "textarea" )) {
				setLoadingBarrForField(field, targetLangId, false);
			}
		});

	});

	/**
	 * SAVE
	 */
	$(document).on("click", '.prestasync-save-desc-fields', function (event) {
		event.preventDefault();

		if($(this).hasClass('refused')) {
			return;
		}

		let lang = $(this).attr('data-lang');
		let checkBoxes = $('.update-field[data-lang="' + lang + '"]:checked'); // permet de déterminer la liste des chanmps cochés

		let data = {
			'id': $(this).attr('data-presta-product-id'),
			'fk_presta': $(this).attr('data-presta-shop-id'),
			'language': lang,
			'fields' : {}
		}

		if(!atLeastOneInputFieldChecked(lang)){
			o.setEventMessage('Need at least one field selected', 0);
			return;
		}

		let allSelector = '';
		checkBoxes.each(function(){
			let targetFieldSelector = '.prestashop-field[name="' + $( this ).val() + '"]';
			let targetBackupFieldSelector = '.prestashop-field[name="' + $( this ).val() + '_backup"]';
			allSelector+= (allSelector.length>0 ? ', ' : '' ) + targetFieldSelector;
			let targetField = $(targetFieldSelector);
			if (targetField.length <= 0) {
				o.setEventMessage('missing field name', 0);
				return;
			}

			let targetFieldName = targetField.attr('data-field');
			if(!targetFieldName) {
				o.setEventMessage('missing field name', 0);
				return;
			}

			data.fields[targetFieldName] = targetField.val();

			$(targetBackupFieldSelector).val(targetField.val()); // Update backup because we will save
		});



		o.callInterface(o.config.interfaceUrl,'updateProductFields', data, (response)=>{
			if(response.result > 0){
				$(allSelector).addClass('--success-update');
				setTimeout(() => {
					$(allSelector).removeClass('--success-update');
				}, 1000);

				// AFTER SAVE SUCCESS, remove checked
				prestasyncChangeNotSaved = false;
				$('.prestasync-toggle[data-lang="'+lang+'"]').prop("checked",false);
				checkBoxes.prop("checked",false);
				toggleSaveBtn(lang);

				o.setEventMessage(o.langs.Saved, 1);
			}
		});

	});
});

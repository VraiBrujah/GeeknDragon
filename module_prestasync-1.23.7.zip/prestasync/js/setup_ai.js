
$(function() {


	/**
	 * Modal for available variables
	 */
	let dialogVariableSelector = "#modal-prestasync-available-variables-list";
	$(dialogVariableSelector).dialog({
		dialogClass: "prestasync-modal",
		autoOpen: false,
		modal: true,
		minWidth: 400,
		maxWidth: window.innerWidth * 0.9,
		maxHeight: window.innerHeight * 0.9,
		width: window.innerWidth * 0.7,
		buttons: [
			{
				text: "Close",
				click: function () {
					$(this).dialog("close");
				}
			}
		]
	});

	$("#open-modal-prestasync-available-variables-list").on("click", function (e) {
		e.preventDefault();
		$(dialogVariableSelector).dialog("open");
	});

});

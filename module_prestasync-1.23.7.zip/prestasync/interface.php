<?php
/* Copyright (C) 2024 John BOTELLA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

//if (! defined('NOREQUIREDB'))              define('NOREQUIREDB', '1');				// Do not create database handler $db
//if (! defined('NOREQUIREUSER'))            define('NOREQUIREUSER', '1');				// Do not load object $user
//if (! defined('NOREQUIRESOC'))             define('NOREQUIRESOC', '1');				// Do not load object $mysoc
//if (! defined('NOREQUIRETRAN'))            define('NOREQUIRETRAN', '1');				// Do not load object $langs
//if (! defined('NOSCANGETFORINJECTION'))    define('NOSCANGETFORINJECTION', '1');		// Do not check injection attack on GET parameters
//if (! defined('NOSCANPOSTFORINJECTION'))   define('NOSCANPOSTFORINJECTION', '1');		// Do not check injection attack on POST parameters
//if (! defined('NOCSRFCHECK'))              define('NOCSRFCHECK', '1');				// Do not check CSRF attack (test on referer + on token if option MAIN_SECURITY_CSRF_WITH_TOKEN is on).
if (!defined('NOTOKENRENEWAL')) define('NOTOKENRENEWAL', '1');                // Do not roll the Anti CSRF token (used if MAIN_SECURITY_CSRF_WITH_TOKEN is on)
//if (! defined('NOSTYLECHECK'))             define('NOSTYLECHECK', '1');				// Do not check style html tag into posted data
if (!defined('NOREQUIREMENU')) define('NOREQUIREMENU', '1');                // If there is no need to load and show top and left menu
if (!defined('NOREQUIREHTML')) define('NOREQUIREHTML', '1');                // If we don't need to load the html.form.class.php
//if (! defined('NOREQUIREAJAX')) define('NOREQUIREAJAX', '1');       	  	// Do not load ajax.lib.php library
//if (! defined("NOLOGIN"))                  define("NOLOGIN", '1');					// If this page is public (can be called outside logged session). This include the NOIPCHECK too.
//if (! defined('NOIPCHECK'))                define('NOIPCHECK', '1');					// Do not check IP defined into conf $dolibarr_main_restrict_ip
//if (! defined("MAIN_LANG_DEFAULT"))        define('MAIN_LANG_DEFAULT', 'auto');					// Force lang to a particular value
//if (! defined("MAIN_AUTHENTICATION_MODE")) define('MAIN_AUTHENTICATION_MODE', 'aloginmodule');	// Force authentication handler
//if (! defined("NOREDIRECTBYMAINTOLOGIN"))  define('NOREDIRECTBYMAINTOLOGIN', 1);		// The main.inc.php does not make a redirect if not logged, instead show simple error message
//if (! defined("FORCECSP"))                 define('FORCECSP', 'none');				// Disable all Content Security Policies
//if (! defined('CSRFCHECK_WITH_TOKEN'))     define('CSRFCHECK_WITH_TOKEN', '1');		// Force use of CSRF protection with tokens even for GET
//if (! defined('NOBROWSERNOTIF'))     		 define('NOBROWSERNOTIF', '1');				// Disable browser notification

$sapi_type = php_sapi_name();
$script_file = basename(__FILE__);
$path = dirname(__FILE__) . '/';

// Include and load Dolibarr environment variables
$res = 0;
if (!$res && file_exists($path . "main.inc.php")) $res = @include($path . "main.inc.php");
if (!$res && file_exists($path . "../main.inc.php")) $res = @include($path . "../main.inc.php");
if (!$res && file_exists($path . "../../main.inc.php")) $res = @include($path . "../../main.inc.php");
if (!$res && file_exists($path . "../../../main.inc.php")) $res = @include($path . "../../../main.inc.php");
if (!$res) die("Include of master fails");

require_once __DIR__ . '/class/jsonResponse.class.php';
require_once __DIR__ . '/lib/prestasync.lib.php';

require_once __DIR__ . '/class/presta.class.php';
if (!class_exists('Validate')) {
	require_once DOL_DOCUMENT_ROOT . '/core/class/validate.class.php';
}

global $langs, $db, $hookmanager, $user, $mysoc;
/**
 * @var DoliDB $db
 */
$hookmanager->initHooks('prestasynclivewebserviceinterface');

// Load traductions files requiredby by page
$langs->loadLangs(["prestasync@prestasync", "other", 'main']);

$action = GETPOST('action');

// Security check
if (!isModEnabled('prestasync')) accessforbidden('Module not enabled');

$jsonResponse = new prestasync\JsonResponse();

if (!$user->hasRight('prestasync', 'presta', 'read')) {
	$jsonResponse->msg = $langs->trans('NotEnoughRights');
	$jsonResponse->result = 0;
	print $jsonResponse->getResponse();
	$db->close();    // Close $db database opened handler
	exit;
}

$reshook = $hookmanager->executeHooks('prestasyncInterface', [], $jsonResponse, $action);
if ($reshook < 0) {
	$jsonResponse->msg = $hookmanager->error;
	if (!empty($hookmanager->errors)) {
		$jsonResponse->msg = (!empty($hookmanager->error) ? '<br>' : '') . implode('<br>', $hookmanager->errors);
	}
	$jsonResponse->result = 0;
	print $jsonResponse->getResponse();
	$db->close();    // Close $db database opened handler
	exit;
}

if ($reshook > 0) {
	// Nothing to do all is done in hook
} elseif ($action === 'updateCombination') {
	__actionUpdateCombination($jsonResponse);
} elseif ($action === 'updateProductFields') {
	__actionUpdateProductFields($jsonResponse);
} elseif ($action === 'getLangs') {
	__getLangs($jsonResponse);
} elseif ($action === 'getPromptForField') {
	__getPromptForField($jsonResponse);
} elseif ($action === 'getAiResponse') {
	__getAiResponseForProductFields($jsonResponse);
} elseif ($action === 'getShops') {
	__getShops($jsonResponse);
} elseif ($action === 'getOrderDetailCustomisation') {
	__getOrderDetailCustomisation($jsonResponse);
} elseif ($action === 'getStatus') {
	__getStatus($jsonResponse);
} elseif ($action === 'getTrad') {
	__getTranslationFromDeeplAPI($jsonResponse);
} else {
	$jsonResponse->msg = 'Action not found';
}

print $jsonResponse->getResponse();

$db->close();    // Close $db database opened handler

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __actionUpdateCombination($jsonResponse)
{
	global $user, $langs, $db;

	require_once __DIR__ . '/class/prestaCombination.class.php';

	if (!$user->hasRight('prestasync', 'presta', 'write')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
//	$validate = new Validate($db, $langs);

	if (empty($data['id']) && !is_numeric($data['id'])) {
		$jsonResponse->msg = 'Need combination Id';
		return false;
	}

	if (empty($data['fk_presta']) && !is_numeric($data['fk_presta'])) {
		$jsonResponse->msg = 'Need presta Id';
		return false;
	}

	if (empty($data['fields']) || !is_array($data['fields'])) {
		$jsonResponse->msg = 'Need fields values';
		return false;
	}

	$presta = new Presta($db);
	if ($presta->fetch(intval($data['fk_presta'])) <= 0) {
		$jsonResponse->msg = 'Prestashop not found';
		return false;
	}

	$combination = new PrestaCombination($presta);
	if (!$combination->fetch(intval($data['id']))) {
		$jsonResponse->msg = 'Prestashop Combination not found : ' . $combination->getLastError();
		return false;
	}

	if (!$combination->updateFields($data['fields'])) {
		$jsonResponse->result = 0;
		$jsonResponse->msg = $langs->trans('UpdateError') . ' : ' . $combination->getLastError();
		return false;
	} else {
		$jsonResponse->result = 1;
		$jsonResponse->data = null;
		return true;
	}
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __actionUpdateProductFields($jsonResponse)
{
	global $user, $langs, $db;

	require_once __DIR__ . '/class/prestaProduct.class.php';

	if (!$user->hasRight('prestasync', 'presta', 'write')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
//	$validate = new Validate($db, $langs);

	if (empty($data['id']) && !is_numeric($data['id'])) {
		$jsonResponse->msg = 'Need product Id';
		return false;
	}

	if (empty($data['fk_presta']) && !is_numeric($data['fk_presta'])) {
		$jsonResponse->msg = 'Need presta Id';
		return false;
	}

	if (empty($data['fields']) || !is_array($data['fields'])) {
		$jsonResponse->msg = 'Need fields values';
		return false;
	}

	$presta = new Presta($db);
	if ($presta->fetch(intval($data['fk_presta'])) <= 0) {
		$jsonResponse->msg = 'Prestashop not found';
		return false;
	}

	$prestaProduct = new PrestaProduct($presta);
	if (!$prestaProduct->fetch(intval($data['id']))) {
		$jsonResponse->msg = 'Prestashop Product not found : ' . $prestaProduct->getLastError();
		return false;
	}

	if (empty($data['language']) && !is_int($data['language'])) {
		$jsonResponse->msg = 'Need language Id';
		return false;
	}

	// TODO check if field manage lang
	$fieldsData = [];

	foreach ($data['fields'] as $fieldK => $fieldV) {
		$fieldsData[$fieldK] = [
			'language' => [
				(int) $data['language'] => $fieldV,
			],
		];

		// Ajoute les traductions connu du produits manquantes car prestashop ne sais pas mettre à jour une seule langue
		if (!empty($fieldsData[$fieldK] && is_array($fieldsData[$fieldK]))) {
			foreach ($prestaProduct->$fieldK as $currentValue) {
				if (!isset($fieldsData[$fieldK]['language'][$currentValue->id])) {
					$fieldsData[$fieldK]['language'][$currentValue->id] = $currentValue->value;
				}
			}
		}
	}

	if (!$prestaProduct->updateFields($fieldsData, $data['language'])) {
		$jsonResponse->result = 0;
		$jsonResponse->msg = $langs->trans('UpdateError') . ' : ' . $prestaProduct->getLastError();
		return false;
	} else {
		$jsonResponse->result = 1;
		$jsonResponse->data = null;
		$prestaProduct->fetch((int) $data['id'], false);
		return true;
	}
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __getPromptForField($jsonResponse)
{
	global $user, $langs, $db;

	if (!$user->hasRight('prestasync', 'presta', 'read')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
//	$validate = new Validate($db, $langs);

	if (empty($data['id']) && !is_numeric($data['id'])) {
		$jsonResponse->msg = 'Need product Id';
		return false;
	}

	if (empty($data['fk_presta']) && !is_numeric($data['fk_presta'])) {
		$jsonResponse->msg = 'Need presta Id';
		return false;
	}

	if (empty($data['field'])) {
		$jsonResponse->msg = 'Need field code';
		return false;
	}

	if (empty($data['fieldsVal']) || !is_array($data['fieldsVal'])) {
		$jsonResponse->msg = 'Need fields values';
		return false;
	}

	$presta = new Presta($db);
	if ($presta->fetch(intval($data['fk_presta'])) <= 0) {
		$jsonResponse->msg = 'Prestashop not found';
		return false;
	}

	require_once __DIR__ . '/class/prestaProduct.class.php';
	$prestaProduct = new PrestaProduct($presta);
	if (!$prestaProduct->fetch(intval($data['id']))) {
		$jsonResponse->msg = 'Prestashop Product not found : ' . $prestaProduct->getLastError();
		return false;
	}

	if (empty($data['language']) && !is_int($data['language'])) {
		$jsonResponse->msg = 'Need language Id';
		return false;
	}

	$jsonResponse->data = new stdClass();
	$jsonResponse->data->prompt = prestaSyncMakeSubstitutionProductPromptTxt($prestaProduct, $data['field'], $data['language'], $data['fieldsVal']);

	$jsonResponse->result = 1;
	return true;
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __getAiResponseForProductFields($jsonResponse)
{
	global $user, $langs, $db;

	if (!isModEnabled('ai')) {
		$jsonResponse->msg = $langs->trans('AiModuleNotActive');
		$jsonResponse->result = 0;
		return false;
	}

	if (!$user->hasRight('prestasync', 'presta', 'read')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");

	if (empty($data['prompt'])) {
		$jsonResponse->msg = 'prompt empty';
		return false;
	}

	if (empty($data['field'])) {
		$jsonResponse->msg = 'Need field code';
		return false;
	}

	require_once DOL_DOCUMENT_ROOT . '/ai/class/ai.class.php';
	$ai = new Ai($db);
	$generatedContent = $ai->generateContent($data['prompt'], getDolGlobalString('PRESTASYNC_AI_TXT_MODEL', 'auto'), 'textgeneration', in_array($data['field'], ['description', 'description_short']) ? 'html' : '');
	if (is_array($generatedContent) && $generatedContent['error']) {
		$jsonResponse->result = 0;
		if (!empty($generatedContent['code']) && $generatedContent['code'] == 429) {
			$jsonResponse->msg = "Quota or allowed period exceeded. Retry Later !";
		} elseif ($generatedContent['code'] >= 400) {
			$jsonResponse->msg = "Error : " . $generatedContent['message'] . '<br><a href="' . DOL_MAIN_URL_ROOT . '/ai/admin/setup.php">' . $langs->trans('ErrorGoToModuleSetup') . '</a>';
		} else {
			$jsonResponse->msg = "Error returned by API call: " . $generatedContent['message'];
		}
		return false;
	}

	$jsonResponse->result = 1;
	$jsonResponse->data = new stdClass();
	$jsonResponse->data->AnswerFromAI = $generatedContent;
	return true;
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __getLangs($jsonResponse)
{
	global $user, $langs, $db;

	if (!$user->hasRight('prestasync', 'presta', 'read')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
	if (empty($data['api_key']) || empty($data['shopUrl'])) {
		return false;
	}

	$presta = new Presta($db);
	$presta->api_key = $data['api_key'];
	$presta->shop_url = $data['shopUrl'];

	$psLangs = $presta->getAllPrestaLanguages();
	if (!$psLangs) {
		$jsonResponse->msg = $presta->errorsToString();
		$jsonResponse->result = 0;
		return false;
	}

	$jsonResponse->data = new stdClass();
	$jsonResponse->data->langs = [];
	if (!empty($psLangs)) {
		foreach ($psLangs as $psLang) {
			$jsonResponse->data->langs[] = $psLang;
		}
	}

	$jsonResponse->data->version = _convertVersion($presta->shop_version);
	$jsonResponse->data->langs = array_values($jsonResponse->data->langs);
	$jsonResponse->result = 1;
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __getShops($jsonResponse)
{
	global $user, $langs, $db;

	if (!$user->hasRight('prestasync', 'presta', 'read')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
	if (empty($data['api_key']) || empty($data['shopUrl'])) {
		return false;
	}

	$presta = new Presta($db);
	$presta->api_key = $data['api_key'];
	$presta->shop_url = $data['shopUrl'];

	$psShops = $presta->getAllPrestaShops();
	if (!$psShops) {
		$jsonResponse->msg = $presta->errorsToString();
		$jsonResponse->result = 0;
		return false;
	}

	$jsonResponse->data = new stdClass();
	$jsonResponse->data->shops = [];
	if (!empty($psShops)) {
		foreach ($psShops as $shops) {
			$jsonResponse->data->shops[] = $shops;
		}
	}

	$jsonResponse->data->version = _convertVersion($presta->shop_version);
	$jsonResponse->data->shops = array_values($jsonResponse->data->shops);

	$jsonResponse->result = 1;
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __getOrderDetailCustomisation($jsonResponse)
{
	global $user, $langs, $db;

	require_once __DIR__ . '/class/prestaCustomization.class.php';
	require_once __DIR__ . '/class/prestaProductCustomizationFields.class.php';

	if (!$user->hasRight('prestasync', 'presta', 'write')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
//	$validate = new Validate($db, $langs);

	if (empty($data['id']) && !is_numeric($data['id'])) {
		$jsonResponse->msg = 'Need customisation Id';
		return false;
	}

	if (empty($data['fk_presta']) && !is_numeric($data['fk_presta'])) {
		$jsonResponse->msg = 'Need presta Id';
		return false;
	}

	$presta = new Presta($db);
	if ($presta->fetch(intval($data['fk_presta'])) <= 0) {
		$jsonResponse->msg = 'Prestashop not found';
		return false;
	}

	$customization = new PrestaCustomization($presta);
	if (!$customization->fetch(intval($data['id']))) {
		$jsonResponse->msg = 'Prestashop Customization not found : ' . $customization->getLastError();
		return false;
	}

	$idsOfCustomizationField = [];
	if (!empty($customization->associations->customized_data_text_fields)) {
		foreach ($customization->associations->customized_data_text_fields as $customizedDataTextFields) {
			$idsOfCustomizationField[] = $customizedDataTextFields->id_customization_field;
//			$customizedDataTextFields->value;
		}
	}

	if (!empty($customization->associations->customized_data_images)) {
		foreach ($customization->associations->customized_data_images as $customizedDataImages) {
			$idsOfCustomizationField[] = $customizedDataImages->id_customization_field;
			// $customizedDataImages->value;
		}
	}

	$idsOfCustomizationField = array_unique($idsOfCustomizationField);
	$filters = [
		'id' => [
			'operator' => 'or',
			'search' => $idsOfCustomizationField,
		],
	];

	$customizationFields = new PrestaProductCustomizationField($presta);
	$allCustomizationFields = $customizationFields->fetchAll([], [], $filters, 999, 0, [], false);
	if (!$allCustomizationFields) {
		$jsonResponse->msg = 'Prestashop Customization field not found : ' . $customizationFields->getLastError() . ' ' . implode(',', $idsOfCustomizationField);
		return false;
	}

	$jsonResponse->data = new stdClass();
	$jsonResponse->data->html = '';
	$jsonResponse->data->customisationData = [];

	// Pour respecter l'ordre de Prestashop on se base sur les résultats de $allCustomizationFields
	foreach ($allCustomizationFields as $customizationFieldId => $customizationField) {
		$customizationItem = new stdClass();
		$customizationName = $customizationField->getTradValue($customizationField->name);

		$customizationItem->name = $customizationName;
		$customizationItem->type = (int) $customizationField->type;
		$customizationItem->value = ''; // see below will be populate

		$jsonResponse->data->html .= '<details class="prestasync-order-details presta-sync-details">';
		$jsonResponse->data->html .= '<summary>' . dol_htmlentities($customizationItem->name) . '</summary>';

		if ((int) $customizationField->type === 0) {
			// IMAGE
			if (!empty($customization->associations->customized_data_images)) {
				foreach ($customization->associations->customized_data_images as $customizedDataImageFields) {
					if ((int) $customizedDataImageFields->id_customization_field != (int) $customizationFieldId) {
						continue;
					}

					$customizationItem->value = dol_buildpath('prestasync/interface-image.php', 1)
						. '?imageid=' . $customizedDataImageFields->id_customization_field
						. '&customizationId=' . $customization->id
						. '&cartid=' . $customization->id_cart
						. '&resource=customizations'
						. '&presta-id=' . $presta->id;
					$jsonResponse->data->html .= '<img class="img-customization" src="' . $customizationItem->value . '" />';
					break;
				}
			}
		} else {
			// TEXT
			if (!empty($customization->associations->customized_data_text_fields)) {
				foreach ($customization->associations->customized_data_text_fields as $customizedDataTextFields) {
					if ((int) $customizedDataTextFields->id_customization_field != (int) $customizationFieldId) {
						continue;
					}
					$customizationItem->value = $customizedDataTextFields->value;
					$jsonResponse->data->html .= $customizationItem->value;
					break;
				}
			}
		}
		$jsonResponse->data->html .= '</details>';

		$jsonResponse->data->customisationData[] = $customizationItem;
	}

	$jsonResponse->result = 1;
	return true;
}

/**
 * @param prestasync\JsonResponse $jsonResponse
 *
 * @return bool|void
 */
function __getStatus($jsonResponse)
{
	global $user, $langs, $db;

	if (!$user->hasRight('prestasync', 'presta', 'read')) {
		$jsonResponse->msg = $langs->trans('NotEnoughRights');
		$jsonResponse->result = 0;
		return false;
	}

	$data = GETPOST("data", "array");
	if (empty($data['api_key']) || empty($data['shopUrl'])) {
		return false;
	}

	$presta = new Presta($db);
	$presta->api_key = $data['api_key'];
	$presta->shop_url = $data['shopUrl'];
	$presta->shop_id = isset($data['shopId']) ? (int) $data['shopId'] : 0;

	require_once __DIR__ . '/class/prestaOrder.class.php';
	$prestaOrder = new PrestaOrder($presta);

	$psStatus = $prestaOrder->getAllPrestaOrderStatus();
	if (!$psStatus) {
		$jsonResponse->msg = $presta->errorsToString();
		$jsonResponse->result = 0;
		return false;
	}

	$jsonResponse->data = new stdClass();
	$jsonResponse->data->status = [];
	if (is_array($psStatus)) {
		foreach ($psStatus as $status) {
			$statusObj = new stdClass();
			$statusObj->id = $status->id;
			$statusObj->name = $prestaOrder->getTradValue($status->name);
			$jsonResponse->data->status[] = $statusObj;
		}
	}

	$jsonResponse->data->status = array_values($jsonResponse->data->status);
	$jsonResponse->result = 1;
}

function _convertVersion($version)
{
	if (empty($version)) {
		return '';
	}
	$version = explode('.', $version);

	return (int) $version[0] . (isset($version[1]) ? '.' . (int) $version[1] : '');
}

function __getTranslationFromDeeplAPI()
{
	global $conf, $jsonResponse;

	if (!prestaSyncIsDeeplInstalled()) {
		$jsonResponse->msg = 'DeepL API Key missing';
		return false;
	}

	$data = GETPOST('data', 'array');

	if (empty($data['sourceTxt'])) {
		$jsonResponse->msg = 'Source text empty';
		return false;
	}

	if (empty($data['langDest'])) {
		$jsonResponse->msg = 'Target lang missing';
		return false;
	}

	$url = 'https://api-free.deepl.com';
	if (!empty($conf->global->PRESTASYNC_DEEPL_USE_PRO)) {
		$url = 'https://api.deepl.com';
	}

	$postRequest = new stdClass();
	$postRequest->text = is_array($data['sourceTxt']) ? $data['sourceTxt'] : [$data['sourceTxt']];
	$postRequest->target_lang = $data['langDest'];
	$postRequest->preserve_formatting = true;
	if (!empty($data['langSrc'])) {
		$postRequest->source_lang = $data['langSrc'];
	}

	// See https://developers.deepl.com/docs/xml-and-html-handling/html
	if (!empty($data['tag_handling'])) {
		$postRequest->tag_handling = $data['tag_handling'];
	}

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		'Content-Type: application/json',
		'Authorization: DeepL-Auth-Key ' . getPrestaSyncIsDeeplKey(),
	]);

	curl_setopt($ch, CURLOPT_URL, $url . '/v2/translate');
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postRequest));
//	$jsonResponse->debug = $postRequest;

	// Receive server response ...
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$server_output = curl_exec($ch);
	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	// Further processing ...
	if ((int) $httpCode == 200) {
		$jsonResponse->data = json_decode($server_output);
		$jsonResponse->result = 1;
		return true;
	} elseif ((int) $httpCode === 400) {
		$jsonResponse->msg = 'Server response error code ' . $httpCode;
		$jsonResponse->data = json_decode($server_output);
		if (json_last_error() === JSON_ERROR_NONE && !empty($jsonResponse->data->message)) {
			$jsonResponse->msg .= '<br><b>' . $jsonResponse->data->message . '</b>';
		}
		return false;
	} else {
		$jsonResponse->msg = 'Server response error code ' . $httpCode;
		$jsonResponse->data = $server_output;
		return false;
	}
}

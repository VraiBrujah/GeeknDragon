<?php
/* Copyright (C) 2004-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2024 THERSANE www.thersane.fr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    prestasync/admin/setup.php
 * \ingroup prestasync
 * \brief   Prestasync setup page.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

global $langs, $user;

// Libraries
require_once DOL_DOCUMENT_ROOT."/core/lib/admin.lib.php";
require_once '../lib/prestasync.lib.php';
//require_once "../class/myclass.class.php";
require_once DOL_DOCUMENT_ROOT.'/product/class/html.formproduct.class.php';
require_once DOL_DOCUMENT_ROOT."/cron/class/cronjob.class.php";

// Translations
$langs->loadLangs(array("admin", "prestasync@prestasync"));

// Initialize technical object to manage hooks of page. Note that conf->hooks_modules contains array of hook context
$hookmanager->initHooks(array('prestasyncsetup', 'globalsetup'));

// Access control
if (!$user->admin) {
	accessforbidden();
}

// Parameters
$action = GETPOST('action', 'aZ09');
$backtopage = GETPOST('backtopage', 'alpha');
$modulepart = GETPOST('modulepart', 'aZ09');	// Used by actions_setmoduleoptions.inc.php

$value = GETPOST('value', 'alpha');
$label = GETPOST('label', 'alpha');
$scandir = GETPOST('scan_dir', 'alpha');
$type = 'myobject';


$error = 0;
$setupnotempty = 0;

// Set this to 1 to use the factory to manage constants. Warning, the generated module will be compatible with version v15+ only
$useFormSetup = 1;

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formsetup.class.php';

$formSetup = new FormSetup($db);

$langs->load('prestasyncAI@prestasync');

$listOfSubstitutions = [
	'__(AnyTranslationKey)__' => $langs->trans('Translation'),
	'__PrestaShopURL__' => $langs->trans('SubstitutionExampleForPrestaShopURL'),
	'__PrestaProductName__' => $langs->trans('SubstitutionExampleForPrestaProductName'),
	'__PrestaProductMetaTitle__' => $langs->trans('SubstitutionExampleForPrestaProductMetaTitle'),
	'__PrestaProductMetaDescription__' => $langs->trans('SubstitutionExampleForPrestaProductMetaDescription'),
	'__PrestaProductKeywords__' => $langs->trans('SubstitutionExampleForPrestaProductKeywords'),
	'__PrestaProductShortDescription__' => $langs->trans('SubstitutionExampleForPrestaProductShortDescription'),
	'__PrestaProductFullDescription__' => $langs->trans('SubstitutionExampleForPrestaProductFullDescription'),
	'__PrestaProductURLRewrite__' => $langs->trans('SubstitutionExampleForPrestaProductURLRewrite'),
	'__PrestaGoalCurrentField__' => $langs->trans('SubstitutionExampleForPrestaGoalCurrentField'),
	'__PrestaCurrentField__' => $langs->trans('SubstitutionExampleForPrestaCurrentField'),
	'__PrestaOutputLang__' => $langs->trans('SubstitutionExampleForPrestaOutputLang'),
];

$item = $formSetup->newItem('PRESTASYNC_AI_PRODUCT_PROMPT')->setAsTextarea();
$item->defaultFieldValue = prestaSyncDefaultProductPromptTxt();

$item = $formSetup->newItem('PRESTASYNC_AI_PRODUCT_GOAL_FIELD')->setAsTextarea();
$item->defaultFieldValue = $langs->trans('ps_SEOPrePromptGoalField');

$item = $formSetup->newItem('PRESTASYNC_AI_PRODUCT_GOAL_FIELD_SHORT_DESC')->setAsTextarea();
$item->defaultFieldValue = $langs->trans('ps_SEOPrePromptGoalFieldShortDescription');

$item = $formSetup->newItem('PRESTASYNC_AI_PRODUCT_GOAL_FIELD_FULL_DESC')->setAsTextarea();
$item->defaultFieldValue = $langs->trans('ps_SEOPrePromptGoalFieldFullDescription');

$item = $formSetup->newItem('PRESTASYNC_AI_PRODUCT_GOAL_ALL_FIELD')->setAsTextarea();

/**
 * EXPERIMENTAL AI
 */
$item = $formSetup->newItem('PRESTASYNC_AI_TXT_MODEL');
$item->defaultFieldValue = 'auto';
$item->fieldInputOverride = '<input list="PRESTASYNC_AI_TXT_MODEL"  name="PRESTASYNC_AI_TXT_MODEL" id="setup-PRESTASYNC_AI_TXT_MODEL" value="'.dol_htmlentities(getDolGlobalString('PRESTASYNC_AI_TXT_MODEL', $item->defaultFieldValue)).'" class="flat minwidth200">';
$item->fieldInputOverride.= '<datalist id="PRESTASYNC_AI_TXT_MODEL" >
    <option value="auto" >
    <option value="gpt-4o-mini" >
    <option value="gpt-4o" >
</datalist>';

$item = $formSetup->newItem('PRESTASYNC_AI_PRODUCT_GLOBAL_GENERATE_MODE')->setAsSelect([
	'onceCall' => $langs->trans('InOneCallAllFields'),
	'eachItemCall' => $langs->trans('MakeACallForEachField'),
]);
$item->defaultFieldValue = 'onceCall';

$setupnotempty =+ count($formSetup->items);


$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);


/*
 * Actions
 */

include DOL_DOCUMENT_ROOT.'/core/actions_setmoduleoptions.inc.php';



/*
 * View
 */

$form = new Form($db);

$help_url = '';
$page_name = "PrestasyncSetup";

llxHeader('', $langs->trans($page_name), $help_url, '', 0, 0, ['prestasync/js/setup_ai.js'], array('prestasync/css/prestasync.css'));

// Subheader
$linkback = '<a href="'.($backtopage ? $backtopage : DOL_URL_ROOT.'/admin/modules.php?restore_lastsearch_values=1').'">'.$langs->trans("BackToModuleList").'</a>';

print load_fiche_titre($langs->trans($page_name), $linkback, 'title_setup');

// Configuration header
$head = prestasyncAdminPrepareHead();
print dol_get_fiche_head($head, 'settings_ai', $langs->trans($page_name), -1, "prestasync@prestasync");

// Setup page goes here
echo '<span class="opacitymedium">'.$langs->trans("PrestasyncSetupPage").'</span><br><br>';


if (!isModEnabled('ai')) {
	print '<div class="warning" >'.$langs->trans('AiModuleNotActive').'</div>';
}

if ($action == 'edit') {

	$helpsubstit= '<table class="prestasync_table-substitution" >';
	foreach ($listOfSubstitutions as $tmpKey => $tmpVal){
		$helpsubstit .= '<tr >';
		$helpsubstit .= '<td class="prestasync_table-substitution__key">';
		$helpsubstit .= $tmpKey;
		$helpsubstit .= '</td>';
		$helpsubstit .= '<td class="prestasync_table-substitution__content">';
		$helpsubstit .= $tmpVal;
		$helpsubstit .= '</td>';
		$helpsubstit .= '</tr>';
	};
	$helpsubstit .= '</table>';


	$help = ' <button id="open-modal-prestasync-available-variables-list" class="btn-low-emphasis" >'.$langs->trans('AvailableVariables').'</button>';
	$help.= '<div title="'.dol_htmlentities($langs->trans("AvailableVariables")).'" id="modal-prestasync-available-variables-list" class="prestasync-tpl-list">'.$helpsubstit.'</div>';
	print $help;


	print '<div class="prestasync-setup-ai"  >';
	print $formSetup->generateOutput(true);
	print '</div>';
} else {
	if (!empty($formSetup->items)) {
		print $formSetup->generateOutput();
		print '<div class="tabsAction">';
		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?action=edit&token='.newToken().'">'.$langs->trans("Modify").'</a>';
		print '</div>';
	} else {
		print '<br>'.$langs->trans("NothingToSetup");
	}
}

// Page end
print dol_get_fiche_end();

llxFooter();
$db->close();

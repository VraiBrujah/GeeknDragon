<?php
/* Copyright (C) 2004-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2024 THERSANE www.thersane.fr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    prestasync/admin/setup.php
 * \ingroup prestasync
 * \brief   Prestasync setup page.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

global $langs, $user;

// Libraries
require_once DOL_DOCUMENT_ROOT."/core/lib/admin.lib.php";
require_once '../lib/prestasync.lib.php';
//require_once "../class/myclass.class.php";
require_once DOL_DOCUMENT_ROOT.'/product/class/html.formproduct.class.php';
require_once DOL_DOCUMENT_ROOT."/cron/class/cronjob.class.php";

// Translations
$langs->loadLangs(array("admin", "prestasync@prestasync", 'errors'));

// Initialize technical object to manage hooks of page. Note that conf->hooks_modules contains array of hook context
$hookmanager->initHooks(array('prestasyncsetup', 'globalsetup'));

// Access control
if (!$user->admin) {
	accessforbidden();
}

// Parameters
$action = GETPOST('action', 'aZ09');
$backtopage = GETPOST('backtopage', 'alpha');
$modulepart = GETPOST('modulepart', 'aZ09');	// Used by actions_setmoduleoptions.inc.php

$value = GETPOST('value', 'alpha');
$label = GETPOST('label', 'alpha');
$scandir = GETPOST('scan_dir', 'alpha');
$type = 'myobject';


$error = 0;
$setupnotempty = 0;

// Set this to 1 to use the factory to manage constants. Warning, the generated module will be compatible with version v15+ only
$useFormSetup = 1;

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formsetup.class.php';

$formSetup = new FormSetup($db);



// Setup conf Order contact sync
$res = $db->query('SELECT code, libelle FROM '.$db->prefix().'c_type_contact WHERE source =\'external\' AND element = \'commande\' ');
$selectTypeContact = array();
if ($res) {
	if ($db->num_rows($res) > 0) {
		while ($obj = $db->fetch_object($res)) {
			$selectTypeContact[$obj->code] = $obj->libelle;
		}
	}
}



$formSetup->newItem('PRESTASYNC_ALLOW_IMPORT_FREE_LINE')->setAsYesNo()->helpText = $langs->trans('PRESTASYNC_ALLOW_IMPORT_FREE_LINE_HELP');

if(empty($conf->global->PRESTASYNC_ORDER_CONTACT_ORDER) && isset($selectTypeContact['CUSTOMER'])){
	dolibarr_set_const($db, 'PRESTASYNC_ORDER_CONTACT_ORDER', 'CUSTOMER', 'chaine', 0, '', $conf->entity);
}
$item = $formSetup->newItem('PRESTASYNC_ORDER_CONTACT_ORDER')->setAsSelect($selectTypeContact);

$formSetup->newItem('PRESTASYNC_ORDER_CONTACT_ORDER_SOURCE')->setAsSelect(['' => $langs->trans('Disable'), 'INVOICE' => $langs->trans('InvoiceAddress'), 'SHIPPING' => $langs->trans('ShippingAddress')]);

$formSetup->newItem('PRESTASYNC_UPDATE_THIRDPARTY_ADDRESS')->setAsSelect(['' => $langs->trans('Disable'), 'INVOICE' => $langs->trans('UseInvoiceAddress'), 'SHIPPING' => $langs->trans('UseShippingAddress')]);


// Setup conf Order contact sync
$res = $db->query('SELECT rowid id, libelle FROM '.$db->prefix().'c_barcode_type');
$selectBareCodeType = array();
if ($res) {
	if ($db->num_rows($res) > 0) {
		while ($obj = $db->fetch_object($res)) {
			$selectBareCodeType[$obj->id] = $obj->libelle;
		}
	}
}

$item = $formSetup->newItem('PRESTASYNC_EAN13')->setAsSelect($selectBareCodeType);
$defaultEan = $db->getRow('SELECT rowid id FROM '.$db->prefix().'c_barcode_type WHERE code = \'EAN13\' ');
if($defaultEan){
	$item->defaultFieldValue = $defaultEan->id;
}


$formSetup->newItem('PRESTASYNC_WRAPPING_SERVICE')->setAsProduct();
$formSetup->newItem('PRESTASYNC_DISCOUNT_SERVICE')->setAsProduct();

/**
 * PRODUCTS
 */
$formSetup->newItem('PRESTASYNC_PRODUCT_CONF_TITLE')->setAsTitle();

require_once DOL_DOCUMENT_ROOT . '/core/class/cunits.class.php';
$cunits = new CUnits($db);
$cunits = $cunits->fetchAll('', '', 0, 0, array('active' => 1));
$selectArray = array();
if($cunits){
	foreach ($cunits as $cunit){
		$selectArray[$cunit->id] = $cunit->label;
	}
}
$formSetup->newItem('PRESTASYNC_DEFAULT_UNIT')->setAsSelect($selectArray);


$sql = "SELECT DISTINCT t.rowid as id,  t.taux as vat, t.code ";
$sql .= " FROM ".$db->prefix()."c_tva as t, ".$db->prefix()."c_country as c";
$sql .= " WHERE t.fk_pays = c.rowid";
$sql .= " AND t.active > 0";
$sql .= " AND t.fk_pays = ".intval($mysoc->country_id);
$sql .= " ORDER BY t.code ASC, t.taux ASC";
$res = $db->query($sql);
$selectArray = array();
if ($res) {
	if ($db->num_rows($res) > 0) {
		while ($obj = $db->fetch_object($res)) {
			$selectArray[$obj->id] = $obj->vat.'%';
		}
	}
}

$formSetup->newItem('PRESTASYNC_DEFAULT_VAT')->setAsSelect($selectArray);

$formSetup->newItem('PRESTASYNC_PRODUCT_FORCE_ACTIVE_ON_CREATE')->setAsYesNo();

$formSetup->newItem('PRESTASYNC_PRODUCT_NO_DESC')->setAsYesNo();

$item = $formSetup->newItem('PRESTASYNC_HTML_EDITOR', 'textarea');

$TField = array(
	'textarea' => $langs->trans('TextArea'). ' <small><em>(' .$langs->trans('Recommended').')</em></small>',
	'ace' => $langs->trans('HTMLEditor'),
	'simple-wysiwyg' => $langs->trans('TextEditor'),
);
$item->setAsSelect($TField);

$formSetup->newItem('PRESTASYNC_DEFAULT_PRICE_IMPORT')->setAsTitle();
$formSetup->newItem('PRESTASYNC_PRODUCT_NO_UPD_SELL_PRICE')->setAsYesNo();
$formSetup->newItem('PRESTASYNC_PRODUCT_NO_UPD_BUY_PRICE')->setAsYesNo();

/**
 * SHIPPING
 */
$formSetup->newItem('PRESTASYNC_SHIPPING_TITLE')->setAsTitle();

if(empty($conf->global->PRESTASYNC_ORDER_CONTACT_SHIPPING) && isset($selectTypeContact['SHIPPING'])){
	dolibarr_set_const($db, 'PRESTASYNC_ORDER_CONTACT_SHIPPING', 'SHIPPING', 'chaine', 0, '', $conf->entity);
}
$formSetup->newItem('PRESTASYNC_ORDER_CONTACT_SHIPPING')->setAsSelect($selectTypeContact);

$formSetup->newItem('PRESTASYNC_SHIPPING_SERVICE')->setAsProduct();

// Setup conf Order contact sync
$res = $db->query('SELECT rowid id, libelle FROM '.$db->prefix().'c_shipment_mode WHERE active = 1 ');
$selectDefaultShippingMode = array();
if ($res) {
	if ($db->num_rows($res) > 0) {
		while ($obj = $db->fetch_object($res)) {
			$selectDefaultShippingMode[$obj->id] = $obj->libelle;
		}
	}
}

$formSetup->newItem('PRESTASYNC_SHIPPING_DEFAULT_MODE')->setAsSelect($selectDefaultShippingMode);

/**
 * WEBHOOKS
 */
$formSetup->newItem('PRESTASYNC_WEBHOOKS_TITLE')->setAsTitle();

$formSetup->newItem('PRESTASYNC_USER')->setAsSelectUser();

if(!getDolGlobalInt('PRESTASYNC_USER') && $action !== 'edit'){
	setEventMessage($langs->trans('MissingWebHookUser'), 'errors');
}

include_once DOL_DOCUMENT_ROOT.'/core/lib/security2.lib.php';
if(!getDolGlobalString('PRESTASYNC_GLOBAL_TOKEN')){
	dolibarr_set_const($db, 'PRESTASYNC_GLOBAL_TOKEN', getRandomPassword(1));
}
$item = $formSetup->newItem('PRESTASYNC_GLOBAL_TOKEN');
$item->fieldInputOverride.= $item->generateInputField() . img_picto($langs->trans('Generate'), 'refresh', 'id="prestasync-generate_api_key" class="linkobject paddingleft"');
$item->fieldInputOverride.= dolJSToSetRandomPassword('setup-PRESTASYNC_GLOBAL_TOKEN', 'prestasync-generate_api_key', 1);

/**
 * MARGIN
 */
$formSetup->newItem('PRESTASYNC_MARGIN_CALCS_TITLE')->setAsTitle();
$item = $formSetup->newItem('PRESTASYNC_BUY_PRICE_DAYS_OFFSET');
$item->helpText = $langs->trans('PRESTASYNC_BUY_PRICE_DAYS_OFFSET_HELP');
$item->fieldAttr['type'] = 'number';
$item->fieldAttr['step'] = '1';
$item->fieldAttr['min'] = '0';

$item = $formSetup->newItem('PRESTASYNC_BUY_PRICE_CALC_MODE');
$TField = array(
	'avg' => $langs->trans('Average'),
	'max' => $langs->trans('Max'),
	'min' => $langs->trans('Min'),
	'percent' => $langs->trans('UseDefaultPricePercent'),
);
$item->setAsSelect($TField);

$item = $formSetup->newItem('PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT');
$item->fieldAttr['type'] = 'number';
$item->fieldAttr['step'] = 'any';
$item->fieldAttr['min'] = '0';
$item->fieldAttr['max'] = '100';
$percent = !empty($conf->global->PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT) ? floatval($conf->global->PRESTASYNC_DEFAULT_BUY_PRICE_PERCENT) : 0;
$item->fieldOutputOverride = price($percent).'&nbsp;%';


$defaultWarehouse = getDolGlobalInt('MAIN_DEFAULT_WAREHOUSE');
$defaultWarehouseSelected = getDolGlobalInt('PRESTASYNC_DEFAULT_PRODUCT_WAREHOUSE');
$item = $formSetup->newItem('PRESTASYNC_DEFAULT_PRODUCT_WAREHOUSE');
$item->helpText = $langs->trans('PRESTASYNC_DEFAULT_PRODUCT_WAREHOUSE_HELP');

$formproduct = new FormProduct($db);
$item->fieldInputOverride = $formproduct->selectWarehouses($defaultWarehouseSelected, 'PRESTASYNC_DEFAULT_PRODUCT_WAREHOUSE', '', 1, 0, 0, '', 0, 0, array(), 'left reposition');

if(!empty($defaultWarehouseSelected)){
	$warehouse = new Entrepot($db);
	if($warehouse->fetch($defaultWarehouseSelected)>0){
		$item->fieldOutputOverride =$warehouse->getNomUrl();
	}
}

/**
 * INVOICES
 */
$formSetup->newItem('PRESTASYNC_INVOICE_TITLE')->setAsTitle();

if(empty($conf->global->PRESTASYNC_ORDER_CONTACT_BILLING) && isset($selectTypeContact['BILLING'])){
	dolibarr_set_const($db, 'PRESTASYNC_ORDER_CONTACT_BILLING', 'BILLING', 'chaine', 0, '', $conf->entity);
}
$formSetup->newItem('PRESTASYNC_ORDER_CONTACT_BILLING')->setAsSelect($selectTypeContact);

$item = $formSetup->newItem('PRESTASYNC_INVOICE_GENERATE');
$item->setAsYesNo();
if($mysoc->country_code == 'FR' && !isModEnabled('blockedlog')){
	$item->fieldOverride = $langs->trans('ToActivateInvoiceGenerationNeedBlockLog');
}


$item = $formSetup->newItem('PRESTASYNC_INVOICE_BANK_ACCOUNT');
if(method_exists($item, 'setAsSelectBankAccount')) {
	$item->setAsSelectBankAccount();
}
else{
	// Compatibility V18-19
	$form = new Form($db);
	$item->fieldInputOverride = $form->select_comptes(getDolGlobalInt('PRESTASYNC_INVOICE_BANK_ACCOUNT'), 'PRESTASYNC_INVOICE_BANK_ACCOUNT', 0, '', 0, '', 0, '', 1);

	if(getDolGlobalInt('PRESTASYNC_INVOICE_BANK_ACCOUNT')) {
		require_once DOL_DOCUMENT_ROOT . '/compta/bank/class/account.class.php';
		$account = new Account($db);
		$account->fetch(getDolGlobalInt('PRESTASYNC_INVOICE_BANK_ACCOUNT'));
		$item->fieldOutputOverride = $account->getNomUrl(1);
	}
}


$formSetup->newItem('PRESTASYNC_INVOICE_VALIDATE')->setAsYesNo();
$formSetup->newItem('PRESTASYNC_INVOICE_CHECK_FOR_PAIEMENTS')->setAsYesNo();

/**
 * TRANSLATE
 */
$formSetup->newItem('DeepLApiParameters')->setAsTitle();
// Setup conf PRESTASYNC_MYPARAM1 as a simple string input
$formSetup->newItem('PRESTASYNC_DEEPL_API_KEY');
$formSetup->newItem('PRESTASYNC_DEEPL_USE_PRO')->setAsYesNo();


/**
 * EXPERIMENTAL
 */
$formSetup->newItem('PRESTASYNC_EXPERIMENTAL')->setAsTitle();
if(isModEnabled('categorie')) {
	$formSetup->newItem('PRESTASYNC_ALLOW_IMPORT_PRODUCT_CATS')->setAsYesNo();
}

$formSetup->newItem('PRESTASYNC_PRODUCT_AUTO_LINK')->setAsYesNo();

$formSetup->newItem('PRESTASYNC_FOR_DEV_OR_TEST_ONLY')->setAsTitle();
$formSetup->newItem('PRESTASYNC_SSL_NO_CHECK')->setAsYesNo();

$formSetup->newItem('PRESTASYNC_ALLOW_IMPORT_MISSING_PRODUCT')->setAsYesNo();



$requiredConfs = [
	'PRESTASYNC_ORDER_CONTACT_ORDER',
	'PRESTASYNC_EAN13',
	'PRESTASYNC_WRAPPING_SERVICE',
	'PRESTASYNC_DISCOUNT_SERVICE',
	'PRESTASYNC_DEFAULT_UNIT',
	'PRESTASYNC_DEFAULT_VAT',
	'PRESTASYNC_SHIPPING_SERVICE',
	'PRESTASYNC_ORDER_CONTACT_SHIPPING',
	'PRESTASYNC_SHIPPING_DEFAULT_MODE',
	'PRESTASYNC_USER',
	'PRESTASYNC_GLOBAL_TOKEN',
	'PRESTASYNC_DEFAULT_PRODUCT_WAREHOUSE',
	];

$configurationMissing = false;
if($action != 'edit'){
	foreach ($requiredConfs as $confKey) {
		if (isset($formSetup->items[$confKey]) && (!isset($conf->global->$confKey) || empty($conf->global->$confKey))) {
			$formSetup->items[$confKey]->nameText = $formSetup->items[$confKey]->getNameText() . '<br/><small class="error">'.$langs->trans('ErrorMandatoryParametersNotProvided').'</small>';
			$configurationMissing = true;
		}
	}
}

$setupnotempty =+ count($formSetup->items);


$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);


/*
 * Actions
 */


include DOL_DOCUMENT_ROOT.'/core/actions_setmoduleoptions.inc.php';

if ($action == 'updateMask') {
	$maskconst = GETPOST('maskconst', 'alpha');
	$maskvalue = GETPOST('maskvalue', 'alpha');

	if ($maskconst) {
		$res = dolibarr_set_const($db, $maskconst, $maskvalue, 'chaine', 0, '', $conf->entity);
		if (!($res > 0)) {
			$error++;
		}
	}

	if (!$error) {
		setEventMessages($langs->trans("SetupSaved"), null, 'mesgs');
	} else {
		setEventMessages($langs->trans("Error"), null, 'errors');
	}
} elseif ($action == 'specimen') {
	$modele = GETPOST('module', 'alpha');
	$tmpobjectkey = GETPOST('object');

	$tmpobject = new $tmpobjectkey($db);
	$tmpobject->initAsSpecimen();

	// Search template files
	$file = ''; $classname = ''; $filefound = 0;
	$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);
	foreach ($dirmodels as $reldir) {
		$file = dol_buildpath($reldir."core/modules/prestasync/doc/pdf_".$modele."_".strtolower($tmpobjectkey).".modules.php", 0);
		if (file_exists($file)) {
			$filefound = 1;
			$classname = "pdf_".$modele."_".strtolower($tmpobjectkey);
			break;
		}
	}

	if ($filefound) {
		require_once $file;

		$module = new $classname($db);

		if ($module->write_file($tmpobject, $langs) > 0) {
			header("Location: ".DOL_URL_ROOT."/document.php?modulepart=prestasync-".strtolower($tmpobjectkey)."&file=SPECIMEN.pdf");
			return;
		} else {
			setEventMessages($module->error, null, 'errors');
			dol_syslog($module->error, LOG_ERR);
		}
	} else {
		setEventMessages($langs->trans("ErrorModuleNotFound"), null, 'errors');
		dol_syslog($langs->trans("ErrorModuleNotFound"), LOG_ERR);
	}
} elseif ($action == 'setmod') {
	// TODO Check if numbering module chosen can be activated by calling method canBeActivated
	$tmpobjectkey = GETPOST('object');
	if (!empty($tmpobjectkey)) {
		$constforval = 'PRESTASYNC_'.strtoupper($tmpobjectkey)."_ADDON";
		dolibarr_set_const($db, $constforval, $value, 'chaine', 0, '', $conf->entity);
	}
} elseif ($action == 'set') {
	// Activate a model
	$ret = addDocumentModel($value, $type, $label, $scandir);
} elseif ($action == 'del') {
	$ret = delDocumentModel($value, $type);
	if ($ret > 0) {
		$tmpobjectkey = GETPOST('object');
		if (!empty($tmpobjectkey)) {
			$constforval = 'PRESTASYNC_'.strtoupper($tmpobjectkey).'_ADDON_PDF';
			if ($conf->global->$constforval == "$value") {
				dolibarr_del_const($db, $constforval, $conf->entity);
			}
		}
	}
} elseif ($action == 'setdoc') {
	// Set or unset default model
	$tmpobjectkey = GETPOST('object');
	if (!empty($tmpobjectkey)) {
		$constforval = 'PRESTASYNC_'.strtoupper($tmpobjectkey).'_ADDON_PDF';
		if (dolibarr_set_const($db, $constforval, $value, 'chaine', 0, '', $conf->entity)) {
			// The constant that was read before the new set
			// We therefore requires a variable to have a coherent view
			$conf->global->$constforval = $value;
		}

		// We disable/enable the document template (into llx_document_model table)
		$ret = delDocumentModel($value, $type);
		if ($ret > 0) {
			$ret = addDocumentModel($value, $type, $label, $scandir);
		}
	}
} elseif ($action == 'unsetdoc') {
	$tmpobjectkey = GETPOST('object');
	if (!empty($tmpobjectkey)) {
		$constforval = 'PRESTASYNC_'.strtoupper($tmpobjectkey).'_ADDON_PDF';
		dolibarr_del_const($db, $constforval, $conf->entity);
	}
}



/*
 * View
 */

$form = new Form($db);

$help_url = '';
$page_name = "PrestasyncSetup";

llxHeader('', $langs->trans($page_name), $help_url, '', 0, 0, '', array('prestasync/css/prestasync.css'));

// Subheader
$linkback = '<a href="'.($backtopage ? $backtopage : DOL_URL_ROOT.'/admin/modules.php?restore_lastsearch_values=1').'">'.$langs->trans("BackToModuleList").'</a>';

print load_fiche_titre($langs->trans($page_name), $linkback, 'title_setup');

// Configuration header
$head = prestasyncAdminPrepareHead();
print dol_get_fiche_head($head, 'settings', $langs->trans($page_name), -1, "prestasync@prestasync");

// Setup page goes here
echo '<span class="opacitymedium">'.$langs->trans("PrestasyncSetupPage").'</span><br><br>';


if ($action == 'edit') {
	print $formSetup->generateOutput(true);
	print '<br>';
} else {

	print '<div class="prestasync-admin-grid">';
	print '		<div class="prestasync-admin-grid__child-1">';
	$fileDownloadLink = dol_buildpath('prestasync/download-export-stock-and-prices.php',2).'?dltoken='.getDolGlobalString('PRESTASYNC_GLOBAL_TOKEN');
	if ($conf->entity > 1) {
		$fileDownloadLink.='&entity='. $conf->entity;
	}

	$dlText = '<br/>'.$langs->trans('DownLoadLinkForImportPriceAndStockCsv').' : <a href="'.$fileDownloadLink.'" target="_blank" >'.$fileDownloadLink.'</a>';

	// CHECK CRON TASK
	if(isModEnabled('cron')) {
		$checkCron = $db->getRow('SELECT COUNT(*) nb FROM '.$db->prefix().'cronjob WHERE jobtype = \'method\' AND objectname = \'PrestasCron\' AND methodename = \'exportProductStockAndPrice\' AND status != 0');
		if($checkCron === false){
			print '<div class="error">'.$langs->trans('FailCheckCronTaskForExportProductStockAndPrice') . $dlText .'</div>';
		}
		elseif($checkCron){

			$listCron = $db->getRows('SELECT rowid as id FROM '.$db->prefix().'cronjob WHERE jobtype = \'method\' AND objectname = \'PrestasCron\' AND methodename = \'exportProductStockAndPrice\' LIMIT 100');
			$cronNomUrl = [];

			if($listCron){
				foreach ($listCron as $cronItem){
					$cron = new Cronjob($db);
					$result = $cron->fetch($cronItem->id);
					if ($result > 0) {
						$cronNomUrl[] = $cron->getNomUrl(1);
					}
				}
			}

			if($checkCron->nb == 0){
				print '<div class="warning">'.$langs->trans('CheckCronNoTaskActivatedForPrestasync').' '.implode(',', $cronNomUrl) . $dlText .'</div>';
			}
			else{
				print '<div class="info">'.$langs->trans('CheckCronTaskIsActiveForPrestasync').' '.implode(',', $cronNomUrl) . $dlText .'</div>';
			}
		}
	}
	else {
		print '<div class="error">'.$langs->trans('TheModuleCronTaskIsNotEnabled').'</div>';
	}


	// check if need module restart
	require_once __DIR__ . '/../core/modules/modPrestasync.class.php';
	$modPrestasync = new ModPrestasync($db);
	$infos = $modPrestasync->getLastActivationInfo();
	if(empty($infos['lastactivationversion']) && $infos['lastactivationversion'] != $modPrestasync->version ){
		print '<div class="error">'.$langs->trans('YourModuleNeedARestartToMakeUpdates').'</div>';
	}

	$fileName = 'prestasync.zip';
	$filePath = __DIR__ . '/../prestashop/' . $fileName;
	$open = getDolGlobalInt('PRESTASYNC_HAVE_DL_PRESTASHOP_ZIP') || !file_exists($filePath) ? '' : ' open ';
	print '<details class="prestasyncdetails" style="margin-bottom: 30px;" '.$open.' ><summary style="">'.$langs->trans('TitleInstallPrestaSyncOnPrestashop').'</summary>';
	print '<div>';
	print $langs->trans('InstallPrestaSyncOnPrestashopDesc01').'<br>';
	print $langs->trans('InstallPrestaSyncOnPrestashopDesc02');

	if (file_exists($filePath)) {
		$dlLink = dol_buildpath('prestasync/dlprestashopmodule.php',1).'?dltoken='.getDolGlobalString('PRESTASYNC_GLOBAL_TOKEN');
		print '<p><a class="button" target="_blank" href="'.$dlLink.'"><i class="fa fa-download"></i> '.$langs->trans('DownLoadThePrestashopModule').'</a></p>';
	}

	print '</div>';
	print '</details>';

	print '		</div>';
	print '		<div class="prestasync-admin-grid__child-2">';
	print '			<div class="add-modules-thersane" >';
	print 				'<h4 class="center">';
	print 				'	<a href="https://www.thersane.fr/fr/content/58-nos-modules-dolibarr" target="_blank" >';
	print '						<img src="https://www.thersane.fr/themes/thersane/img/logo-thersane.svg" style="max-width: 100%; width: 150px;" />';
	print '					</a>';
	print '				</h4>';
	print 				'<p class="center" style="margin-top: 15px;"><a class="button" href="https://www.thersane.fr/fr/content/53-module-dolibarr-presta-sync-connecter-prestashop-pour-dolibarr-" target="_blank" >'.$langs->trans("OnlineDoc").' <span class="fa fa-chevron-right"></span></a></p>';
	print 				'<p class="center" style="margin-top: 15px;"><a  href="https://www.thersane.fr/fr/content/58-nos-modules-dolibarr" target="_blank" >'.$langs->trans("DiscoverAllTHERSANEModules").' <span class="fa fa-chevron-right"></span></a></p>';
	print '			</div>';
	print '		</div>';

	print '</div>';

	if (!empty($formSetup->items)) {

		if($configurationMissing) {
			print '<div class="error">'.$langs->trans('PSSomeSetupAreMissing').'</div>';
		}

		print $formSetup->generateOutput();
		print '<div class="tabsAction">';
		print '<a class="butAction" href="'.$_SERVER["PHP_SELF"].'?action=edit&token='.newToken().'">'.$langs->trans("Modify").'</a>';
		print '</div>';
	} else {
		print '<br>'.$langs->trans("NothingToSetup");
	}
}


$moduledir = 'prestasync';
$myTmpObjects = array();
$myTmpObjects['MyObject'] = array('includerefgeneration'=>0, 'includedocgeneration'=>0);


foreach ($myTmpObjects as $myTmpObjectKey => $myTmpObjectArray) {
	if ($myTmpObjectKey == 'MyObject') {
		continue;
	}
	if ($myTmpObjectArray['includerefgeneration']) {
		/*
		 * Orders Numbering model
		 */
		$setupnotempty++;

		print load_fiche_titre($langs->trans("NumberingModules", $myTmpObjectKey), '', '');

		print '<table class="noborder centpercent">';
		print '<tr class="liste_titre">';
		print '<td>'.$langs->trans("Name").'</td>';
		print '<td>'.$langs->trans("Description").'</td>';
		print '<td class="nowrap">'.$langs->trans("Example").'</td>';
		print '<td class="center" width="60">'.$langs->trans("Status").'</td>';
		print '<td class="center" width="16">'.$langs->trans("ShortInfo").'</td>';
		print '</tr>'."\n";

		clearstatcache();

		foreach ($dirmodels as $reldir) {
			$dir = dol_buildpath($reldir."core/modules/".$moduledir);

			if (is_dir($dir)) {
				$handle = opendir($dir);
				if (is_resource($handle)) {
					while (($file = readdir($handle)) !== false) {
						if (strpos($file, 'mod_'.strtolower($myTmpObjectKey).'_') === 0 && substr($file, dol_strlen($file) - 3, 3) == 'php') {
							$file = substr($file, 0, dol_strlen($file) - 4);

							require_once $dir.'/'.$file.'.php';

							$module = new $file($db);

							// Show modules according to features level
							if ($module->version == 'development' && $conf->global->MAIN_FEATURES_LEVEL < 2) {
								continue;
							}
							if ($module->version == 'experimental' && $conf->global->MAIN_FEATURES_LEVEL < 1) {
								continue;
							}

							if ($module->isEnabled()) {
								dol_include_once('/'.$moduledir.'/class/'.strtolower($myTmpObjectKey).'.class.php');

								print '<tr class="oddeven"><td>'.$module->name."</td><td>\n";
								print $module->info();
								print '</td>';

								// Show example of numbering model
								print '<td class="nowrap">';
								$tmp = $module->getExample();
								if (preg_match('/^Error/', $tmp)) {
									$langs->load("errors");
									print '<div class="error">'.$langs->trans($tmp).'</div>';
								} elseif ($tmp == 'NotConfigured') {
									print $langs->trans($tmp);
								} else {
									print $tmp;
								}
								print '</td>'."\n";

								print '<td class="center">';
								$constforvar = 'PRESTASYNC_'.strtoupper($myTmpObjectKey).'_ADDON';
								if (getDolGlobalString($constforvar) == $file) {
									print img_picto($langs->trans("Activated"), 'switch_on');
								} else {
									print '<a href="'.$_SERVER["PHP_SELF"].'?action=setmod&token='.newToken().'&object='.strtolower($myTmpObjectKey).'&value='.urlencode($file).'">';
									print img_picto($langs->trans("Disabled"), 'switch_off');
									print '</a>';
								}
								print '</td>';

								$mytmpinstance = new $myTmpObjectKey($db);
								$mytmpinstance->initAsSpecimen();

								// Info
								$htmltooltip = '';
								$htmltooltip .= ''.$langs->trans("Version").': <b>'.$module->getVersion().'</b><br>';

								$nextval = $module->getNextValue($mytmpinstance);
								if ("$nextval" != $langs->trans("NotAvailable")) {  // Keep " on nextval
									$htmltooltip .= ''.$langs->trans("NextValue").': ';
									if ($nextval) {
										if (preg_match('/^Error/', $nextval) || $nextval == 'NotConfigured') {
											$nextval = $langs->trans($nextval);
										}
										$htmltooltip .= $nextval.'<br>';
									} else {
										$htmltooltip .= $langs->trans($module->error).'<br>';
									}
								}

								print '<td class="center">';
								print $form->textwithpicto('', $htmltooltip, 1, 0);
								print '</td>';

								print "</tr>\n";
							}
						}
					}
					closedir($handle);
				}
			}
		}
		print "</table><br>\n";
	}

	if ($myTmpObjectArray['includedocgeneration']) {
		/*
		 * Document templates generators
		 */
		$setupnotempty++;
		$type = strtolower($myTmpObjectKey);

		print load_fiche_titre($langs->trans("DocumentModules", $myTmpObjectKey), '', '');

		// Load array def with activated templates
		$def = array();
		$sql = "SELECT nom";
		$sql .= " FROM ".MAIN_DB_PREFIX."document_model";
		$sql .= " WHERE type = '".$db->escape($type)."'";
		$sql .= " AND entity = ".$conf->entity;
		$resql = $db->query($sql);
		if ($resql) {
			$i = 0;
			$num_rows = $db->num_rows($resql);
			while ($i < $num_rows) {
				$array = $db->fetch_array($resql);
				array_push($def, $array[0]);
				$i++;
			}
		} else {
			dol_print_error($db);
		}

		print "<table class=\"noborder\" width=\"100%\">\n";
		print "<tr class=\"liste_titre\">\n";
		print '<td>'.$langs->trans("Name").'</td>';
		print '<td>'.$langs->trans("Description").'</td>';
		print '<td class="center" width="60">'.$langs->trans("Status")."</td>\n";
		print '<td class="center" width="60">'.$langs->trans("Default")."</td>\n";
		print '<td class="center" width="38">'.$langs->trans("ShortInfo").'</td>';
		print '<td class="center" width="38">'.$langs->trans("Preview").'</td>';
		print "</tr>\n";

		clearstatcache();

		foreach ($dirmodels as $reldir) {
			foreach (array('', '/doc') as $valdir) {
				$realpath = $reldir."core/modules/".$moduledir.$valdir;
				$dir = dol_buildpath($realpath);

				if (is_dir($dir)) {
					$handle = opendir($dir);
					if (is_resource($handle)) {
						while (($file = readdir($handle)) !== false) {
							$filelist[] = $file;
						}
						closedir($handle);
						arsort($filelist);

						foreach ($filelist as $file) {
							if (preg_match('/\.modules\.php$/i', $file) && preg_match('/^(pdf_|doc_)/', $file)) {
								if (file_exists($dir.'/'.$file)) {
									$name = substr($file, 4, dol_strlen($file) - 16);
									$classname = substr($file, 0, dol_strlen($file) - 12);

									require_once $dir.'/'.$file;
									$module = new $classname($db);

									$modulequalified = 1;
									if ($module->version == 'development' && $conf->global->MAIN_FEATURES_LEVEL < 2) {
										$modulequalified = 0;
									}
									if ($module->version == 'experimental' && $conf->global->MAIN_FEATURES_LEVEL < 1) {
										$modulequalified = 0;
									}

									if ($modulequalified) {
										print '<tr class="oddeven"><td width="100">';
										print (empty($module->name) ? $name : $module->name);
										print "</td><td>\n";
										if (method_exists($module, 'info')) {
											print $module->info($langs);
										} else {
											print $module->description;
										}
										print '</td>';

										// Active
										if (in_array($name, $def)) {
											print '<td class="center">'."\n";
											print '<a href="'.$_SERVER["PHP_SELF"].'?action=del&token='.newToken().'&value='.urlencode($name).'">';
											print img_picto($langs->trans("Enabled"), 'switch_on');
											print '</a>';
											print '</td>';
										} else {
											print '<td class="center">'."\n";
											print '<a href="'.$_SERVER["PHP_SELF"].'?action=set&token='.newToken().'&value='.urlencode($name).'&scan_dir='.urlencode($module->scandir).'&label='.urlencode($module->name).'">'.img_picto($langs->trans("Disabled"), 'switch_off').'</a>';
											print "</td>";
										}

										// Default
										print '<td class="center">';
										$constforvar = 'PRESTASYNC_'.strtoupper($myTmpObjectKey).'_ADDON';
										if (getDolGlobalString($constforvar) == $name) {
											//print img_picto($langs->trans("Default"), 'on');
											// Even if choice is the default value, we allow to disable it. Replace this with previous line if you need to disable unset
											print '<a href="'.$_SERVER["PHP_SELF"].'?action=unsetdoc&token='.newToken().'&object='.urlencode(strtolower($myTmpObjectKey)).'&value='.urlencode($name).'&scan_dir='.urlencode($module->scandir).'&label='.urlencode($module->name).'&amp;type='.urlencode($type).'" alt="'.$langs->trans("Disable").'">'.img_picto($langs->trans("Enabled"), 'on').'</a>';
										} else {
											print '<a href="'.$_SERVER["PHP_SELF"].'?action=setdoc&token='.newToken().'&object='.urlencode(strtolower($myTmpObjectKey)).'&value='.urlencode($name).'&scan_dir='.urlencode($module->scandir).'&label='.urlencode($module->name).'" alt="'.$langs->trans("Default").'">'.img_picto($langs->trans("Disabled"), 'off').'</a>';
										}
										print '</td>';

										// Info
										$htmltooltip = ''.$langs->trans("Name").': '.$module->name;
										$htmltooltip .= '<br>'.$langs->trans("Type").': '.($module->type ? $module->type : $langs->trans("Unknown"));
										if ($module->type == 'pdf') {
											$htmltooltip .= '<br>'.$langs->trans("Width").'/'.$langs->trans("Height").': '.$module->page_largeur.'/'.$module->page_hauteur;
										}
										$htmltooltip .= '<br>'.$langs->trans("Path").': '.preg_replace('/^\//', '', $realpath).'/'.$file;

										$htmltooltip .= '<br><br><u>'.$langs->trans("FeaturesSupported").':</u>';
										$htmltooltip .= '<br>'.$langs->trans("Logo").': '.yn($module->option_logo, 1, 1);
										$htmltooltip .= '<br>'.$langs->trans("MultiLanguage").': '.yn($module->option_multilang, 1, 1);

										print '<td class="center">';
										print $form->textwithpicto('', $htmltooltip, 1, 0);
										print '</td>';

										// Preview
										print '<td class="center">';
										if ($module->type == 'pdf') {
											$newname = preg_replace('/_'.preg_quote(strtolower($myTmpObjectKey), '/').'/', '', $name);
											print '<a href="'.$_SERVER["PHP_SELF"].'?action=specimen&module='.urlencode($newname).'&object='.urlencode($myTmpObjectKey).'">'.img_object($langs->trans("Preview"), 'pdf').'</a>';
										} else {
											print img_object($langs->trans("PreviewNotAvailable"), 'generic');
										}
										print '</td>';

										print "</tr>\n";
									}
								}
							}
						}
					}
				}
			}
		}

		print '</table>';
	}
}

if (empty($setupnotempty)) {
	print '<br>'.$langs->trans("NothingToSetup");
}

// Page end
print dol_get_fiche_end();

llxFooter();
$db->close();

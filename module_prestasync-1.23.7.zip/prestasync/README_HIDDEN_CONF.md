- PRESTASYNC_SSL_NO_CHECK : [0]|1 Set to 1 to disable SSL check on Prestashop connections
- PRESTASYNC_AUTH_MODE USE_HEADER : [BASIC] | USE_HEADER | WS_KEY  
  using another authentication mode can be a good way of testing the connection to Prestashop, or getting around server limitations
  Warning: using WS_KEY will add the API key directly from the url called
- PRESTASYNC_CURLOPT_CONNECTTIMEOUT : int [10] to change the CURLOPT_CONNECTTIMEOUT of API calls
- PRESTASYNC_CURLOPT_TIMEOUT : int [10] to change the CURLOPT_TIMEOUT of API calls

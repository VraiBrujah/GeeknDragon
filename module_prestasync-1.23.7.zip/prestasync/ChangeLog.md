# CHANGELOG PRESTASYNC FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

- Fix : multicompany compatibility  - V1.23.7
- Fix : Remove sort order for cols  - V1.23.6
- Fix : Missing API write info about order_states - V1.23.5
- Fix : Missing lang trans - V1.23.4
- Fix : V18 compatibility with dictionary fields - V1.23.3
- Fix : V18 compatibility with multiselect fields - V1.23.2
- Fix : variable missing after code moved - V1.23.1
- New : Add experimental option to auto create product on order import - V1.23.0
- Fix : Some retro compatibility for V18 - V1.22.1
- NEW : Add option for order contacts and thirdparty update - V1.22.0
- Fix : Some retro compatibility for V18 - V1.21.2
- Fix : Decrease stock on order with STOCK_CALCULATE_ON_VALIDATE_ORDER - V1.21.1
- NEW : Desc change comparator - V1.21.0
- Fix : Prestashop Save desc compatibility under 8.0 and PATCH Webservice - V1.20.2
- Fix : Compatibility version to 9.0 and add help link - V1.20.1
- NEW : Presta card informations check - V1.20.0
- NEW : Carts list & Import as Dolibarr Propal object - V1.19.0
- NEW : Customer list & Import - V1.18.0
- NEW : Import order customization - V1.17.0

- Fix : Empty langs in some cases - V1.16.7
- Fix : js remove test - V1.16.6
- Fix : js dom change disable save btn - V1.16.5
- Fix : js calc for weight and price impact- V1.16.4
- Fix : Wrong translation for success message - V1.16.3
- FIX : Image link - V1.16.2
- FIX : Defined key missing - V1.16.1
- NEW : AI assistant - V1.16.0
  
- NEW : Save product desc and translation, add Deepl Api for auto translate - V1.15.0
  
- Fix : NOCSRFCHECK - V1.14.3
- Fix : PostgreSQL - V1.14.2 
- Fix : No tax group value - V1.14.1
- New : Add description product tab - V1.14.0
  
- New : Langs it es de - V1.13.0
  
- New : UX help on shop creation - V1.12.0
  
- Fix : shop id for api call - V1.11.1
- New : Invoices API rest - V1.11.0
  
- New : Experimental auto link products by ref - V1.10.0
  
- New : Experimental import of categories - V1.9.0
  
- New : Option to create payments - V1.8.0
  
- Fix : presta parameters shop filter - V1.7.2
- Fix : langs - V1.7.1
- New : Add web export for export price and stock csv - V1.7
  Warning : with this version all token are changed
  
- New : Invoice generation option on import - V1.6
  
- Fix : Presta object delete cascade - V1.5.5
- Fix : Prestashop lib - V1.5.4
- New : Readme description - V1.5.3
- Fix : lang us error - V1.5.2
- Fix : V1.7 compatibility - V1.5.1
- New : Mass import supplier - V1.5.0
  
- New : link display on product page - V1.4.0
  
- Fix : Supplier mapping info display - V1.3.2
- Fix : Stock override condition - V1.3.1
- New : prestashop languages simple support - V1.3
Initial version
